"use strict";
var x , [ x = await , , ... x ] = `` ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:SingleNameBinding[0,1].IteratorBindingInitialization) but got transpile-failure */
