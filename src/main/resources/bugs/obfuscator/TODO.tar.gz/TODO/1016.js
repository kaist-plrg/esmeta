"use strict";
{ x = ~ await ; } ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:UnaryExpression[6,0].Evaluation) but got transpile-failure */
