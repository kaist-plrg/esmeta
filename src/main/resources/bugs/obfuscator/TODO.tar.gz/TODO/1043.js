"use strict";
{ while ( await ) var await = 0 ; } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
