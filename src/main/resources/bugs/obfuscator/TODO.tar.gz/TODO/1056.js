"use strict";
0 ?. x [ { [ Symbol . toPrimitive ] : await => { } } < 0 ] ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:ExpressionStatement[0,0].Evaluation) but got transpile-failure */
