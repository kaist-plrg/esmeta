"use strict";
let x , await = ~ { [ await | 0 . x . x === 0 ^ 0 | 0 ] : true } ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:BitwiseORExpression[1,0].Evaluation) but got transpile-failure */
