"use strict";
x : switch ( await ) { } class await { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:SwitchStatement[0,0].Evaluation) but got transpile-failure */
