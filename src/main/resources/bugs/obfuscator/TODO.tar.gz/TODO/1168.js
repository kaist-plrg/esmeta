"use strict";
class x { static { function * x ( ) { } function x ( ) { } } } 

/* TAG: NEW-STATIC-SAME-NAME-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
