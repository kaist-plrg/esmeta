"use strict";
var [ x = { [ Symbol . toPrimitive ] : await => 0 } == 0 ** 0 ] = `` ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
