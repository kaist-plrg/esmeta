"use strict";
async function await ( ) { } for ( var x of ~ ! await ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:ForInOfStatement[4,0].ForInOfLoopEvaluation) but got transpile-failure */
