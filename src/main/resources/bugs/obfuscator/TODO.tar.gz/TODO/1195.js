"use strict";
for ( let x ; typeof await ; 0 ) throw 0 ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-value: 0.0f but got transpile-failure */
