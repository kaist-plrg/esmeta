"use strict";
do await : for ( let x ; 0 ; 0 , 0 , 0 , 0 ) ; while ( ~ ~ 0 ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
