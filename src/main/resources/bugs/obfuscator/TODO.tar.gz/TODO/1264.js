"use strict";
let x = 0 !== 1 <= await ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:RelationalExpression[3,0].Evaluation) but got transpile-failure */
