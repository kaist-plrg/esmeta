"use strict";
Array . prototype . filter . call ( await => 0 , 0 ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(INTRINSICS.Array.prototype.filter ((step 3, 4:54-84))<BUILTIN>:INTRINSICS.Array.prototype.filter) but got transpile-failure */
