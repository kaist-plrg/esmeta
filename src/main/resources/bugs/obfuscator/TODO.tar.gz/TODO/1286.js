"use strict";
class x { ; } if ( `${ await += 0 }` ) ; else ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:AssignmentExpression[5,0].Evaluation) but got transpile-failure */
