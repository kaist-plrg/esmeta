"use strict";
if ( 0 ) ; else while ( await ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:WhileStatement[0,0].WhileLoopEvaluation) but got transpile-failure */
