"use strict";
for ( var x ; { [ Symbol . toPrimitive ] : await => this } >> 0n ; 0 ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:ShiftExpression[2,0].Evaluation) but got transpile-failure */
