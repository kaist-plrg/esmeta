"use strict";
let x = typeof await ; class await { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:UnaryExpression[3,0].Evaluation) but got transpile-failure */
