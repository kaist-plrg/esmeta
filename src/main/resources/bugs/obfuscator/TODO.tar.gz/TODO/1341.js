"use strict";
await >>> 0 - 0 ; class await { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:ShiftExpression[3,0].Evaluation) but got transpile-failure */
