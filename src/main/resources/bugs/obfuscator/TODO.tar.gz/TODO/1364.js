"use strict";
class await { } new Map ( 0 , await ? 1n . x : 0 . x >>= ~ 0 ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<BUILTIN>:INTRINSICS.Map) but got transpile-failure */
