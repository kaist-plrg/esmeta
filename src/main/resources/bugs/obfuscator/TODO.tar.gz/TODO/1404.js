"use strict";
{ var x = await ; } class await { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:VariableDeclaration[0,1].Evaluation) but got transpile-failure */
