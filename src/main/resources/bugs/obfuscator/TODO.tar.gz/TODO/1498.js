"use strict";
var x = 0 . x ||= + await ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:UnaryExpression[4,0].Evaluation) but got transpile-failure */
