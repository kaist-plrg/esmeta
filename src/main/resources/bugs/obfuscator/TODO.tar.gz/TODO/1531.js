"use strict";
while ( 0 & 0 ) await : for ( var x ; ; ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
