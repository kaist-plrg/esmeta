"use strict";
for ( let x ; 1 ? 0 : await ; ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
