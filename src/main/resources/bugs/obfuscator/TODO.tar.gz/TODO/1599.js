"use strict";
class await { } let [ ] = [ 0 , 0 , ] . x = [ 0 , , ] [ 0 ** 0 ] ||= await ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:BindingPattern[1,0].BindingInitialization) but got transpile-failure */
