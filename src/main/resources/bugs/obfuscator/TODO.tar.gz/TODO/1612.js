"use strict";
for ( let x of function * ( ) { } ( ) ?. [ typeof await ] ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:ForInOfStatement[5,0].ForInOfLoopEvaluation) but got transpile-failure */
