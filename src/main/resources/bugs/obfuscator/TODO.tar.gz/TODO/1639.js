"use strict";
for ( function * ( ) { } ( ) . x ??= await ; 0 ; 0 ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:AssignmentExpression[8,0].Evaluation) but got transpile-failure */
