"use strict";
switch ( 0 ) { case null ?? await : default : case 0 : async function * await ( ) { } } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
