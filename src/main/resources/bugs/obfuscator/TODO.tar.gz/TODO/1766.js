"use strict";
if ( 0 + { [ Symbol . toPrimitive ] : await => 0 } ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
