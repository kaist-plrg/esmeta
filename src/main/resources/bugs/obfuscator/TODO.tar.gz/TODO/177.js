"use strict";
let x , await = new '' [ 0 + await % 0 ] ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got transpile-failure */
