"use strict";
var [ x = await in { } ] = `` ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:RelationalExpression[6,0].Evaluation) but got transpile-failure */
