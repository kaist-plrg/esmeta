"use strict";
0 ?. ( true . x = 0 , await ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(PutValue ((step 5.d, 15:72-102))<SYNTAX>:AssignmentExpression[4,0].Evaluation) but got transpile-failure */
