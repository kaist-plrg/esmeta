"use strict";
switch ( 0 ) { case 0 ** await : default : } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:ExponentiationExpression[1,0].Evaluation) but got transpile-failure */
