"use strict";
for ( [ ] of [ `` ] ) try { ; await ; } catch { } finally { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
