"use strict";
for ( await [ 0 ] in 0 <= this . x << 0 - 0 , { get : '' } ) ; 

/* TAG: NEW-YET-REMOVED-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:MemberExpression[1,0].Evaluation) but got transpile-failure */
