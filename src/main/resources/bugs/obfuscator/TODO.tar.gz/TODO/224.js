"use strict";
0 ?. ( { [ Symbol . toPrimitive ] : await => { } } != 0 ) . x ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(EvaluateCall ((step 4, 12:45-75))<SYNTAX>:OptionalChain[0,0].ChainEvaluation) but got transpile-failure */
