"use strict";
if ( class { } ( ... 0 , ) ) ; 

/* TAG: NEW-OBF-OPT-CALL-CHAIN-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:ArgumentList[1,0].ArgumentListEvaluation) but got transpile-failure */
