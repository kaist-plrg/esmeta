"use strict";
for ( ; 0 . x [ { [ Symbol . toPrimitive ] : x => { throw 0 ; } } ] ; ) ; 

/* TAG: NEW-YET
[Exit Tag Mismatch]
 > Expected throw-value: 0.0f but got throw-error: TypeError(unnamed:3: TypeError: Cannot read properties of undefined (reading '#<Object>')) */
