"use strict";
let { } = await , await , x ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:LexicalBinding[1,0].Evaluation) but got transpile-failure */
