"use strict";
var { x = await = 0 } = 0 ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(PutValue ((step 4.a, 6:45-80))<SYNTAX>:AssignmentExpression[4,0].Evaluation) but got transpile-failure */
