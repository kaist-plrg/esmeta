"use strict";
var x = async x => { ; for await ( 0 . x of this . x &&= class x { } ) ; } ; x ( ) ; 

/* TAG: NEW-NAME
[Assertion Fail]
 > descriptor value of "name" should be "x" but "_0x2acba1" */
