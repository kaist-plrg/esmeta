"use strict";
class await { } for ( let x ; 0 [ 0 ] [ 0 ] instanceof await ; 0 ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:RelationalExpression[5,0].Evaluation) but got transpile-failure */
