"use strict";
let x , await = 0 == 0 == await != 0 ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:EqualityExpression[1,0].Evaluation) but got transpile-failure */
