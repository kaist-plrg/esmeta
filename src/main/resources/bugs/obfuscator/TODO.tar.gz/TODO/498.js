"use strict";
async function * await ( ) { } var { 0 : [ ] = await . x } = 0 ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:BindingPattern[1,0].BindingInitialization) but got transpile-failure */
