"use strict";
class await { } 0 ( 0 , ... await ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:ArgumentList[3,0].ArgumentListEvaluation) but got transpile-failure */
