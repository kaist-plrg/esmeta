"use strict";
[ , 0 !== await ] ; function await ( ) { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
