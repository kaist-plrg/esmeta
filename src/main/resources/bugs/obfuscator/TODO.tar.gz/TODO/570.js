"use strict";
for ( var x ; 0 | await ; ) ; class await { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:BitwiseORExpression[1,0].Evaluation) but got transpile-failure */
