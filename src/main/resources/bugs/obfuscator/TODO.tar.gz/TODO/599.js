"use strict";
function await ( ) { } x : switch ( await ) { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
