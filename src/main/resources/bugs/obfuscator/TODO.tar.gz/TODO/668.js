"use strict";
let x = async x => class { } ( ) ; x ( ) ; 

/* TAG: NEW-OBF-OPT-CALL-CHAIN-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
