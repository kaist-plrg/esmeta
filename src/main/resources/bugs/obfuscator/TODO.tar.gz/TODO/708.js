"use strict";
0 ?. x [ await || x ] ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:LogicalORExpression[1,0].Evaluation) but got transpile-failure */
