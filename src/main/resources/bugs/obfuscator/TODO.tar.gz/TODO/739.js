"use strict";
let x , [ ] = 0 [ 0 , await ] -- , await ; { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:Expression[1,0].Evaluation) but got transpile-failure */
