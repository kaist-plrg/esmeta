"use strict";
for ( let x ; '' ? 0 : await ; ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:ConditionalExpression[1,0].Evaluation) but got transpile-failure */
