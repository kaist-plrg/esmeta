"use strict";
var { 0 : x = await } = 0 ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:SingleNameBinding[0,1].KeyedBindingInitialization) but got transpile-failure */
