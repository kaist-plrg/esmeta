"use strict";
0 / await ?. x ; class await { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:OptionalExpression[0,0].Evaluation) but got transpile-failure */
