"use strict";
0 [ { x } = { [ Symbol . toPrimitive ] : await => { } } in new class { } ] ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(PutValue ((step 4.a, 6:45-80))<SYNTAX>:AssignmentProperty[0,0].PropertyDestructuringAssignmentEvaluation) but got transpile-failure */
