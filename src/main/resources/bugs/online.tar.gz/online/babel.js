"use strict";
( ( ) => { x ( ) ; } ) ( ) ; class x { } 
( ( ) => { x ; } ) ( ) ; class x { } 
( async function * ( [ ] ) { } ) ( ) ; 
( x => async function * ( [ ] ) { } ( ) ) ( ) ; 
( x => function * ( [ ] ) { } ) ( ) ( ) ; 
( x => { function * x ( ) { } new x ( ) ; } ) ( ) ; x ; 
( x => { new x ( ) ; async function * x ( ) { } } ) ( ) ; x ; 
( x => { new x ( ) ; async function x ( ) { } } ) ( ) ; x ; 
- class extends function * ( ) { } { } ; 
- { [ Symbol . toPrimitive ] : ( ) => x } ; class x { } 
- { [ Symbol . toPrimitive ] : async x => { for await ( let x of '' ) { class x { } } } } ; 
- { [ Symbol . toPrimitive ] : async x => { for await ( let x of { [ Symbol . iterator ] : async function * ( [ ] ) { } } ) ; } } ; 
- { [ { [ Symbol . toPrimitive ] : '' } ] : { x } } ; 
0 ?. [ x ] ; class x { } 
0 ?. x [ x ] ; class x { } 
0 || x ; class x { } 
1 && x ; class x { } 
1 ? x : 0 ; class x { } 
Array . from . call ( x => 0 , 0 ) ; 
Array . from . call ( x => 0 , [ ] ) ; 
Array . from . call ( x => 0 , `` ) ; 
Array . from . call ( x => 0 , x => { } , x => await ) ; 
Array . of . call ( x => 0 ) ; 
Array . prototype . every . call ( `${ 0 }` , x => class extends async function ( ) { } { } ) ; 
Array . prototype . every . call ( `${ 0 }` , x => class x extends { x , } { } ) ; 
Array . prototype . filter . call ( [ 0 ] , x => await ) ; class await { } 
Array . prototype . find . call ( x => 0 , x => await ) ; class await { } 
Array . prototype . flatMap . call ( [ 0 ] , x => await ) ; class await { } 
Function . apply . call ( async function * ( [ ] ) { } ) ; 
Function . apply . call ( function * ( [ ] ) { } ) ; 
Map ( function * ( ) { await : x : ; } ) ; 
[ , ] = { [ Symbol . iterator ] : async function * ( [ ] ) { } } ; 
[ , ] = { [ Symbol . iterator ] : async function * ( [ x , ] ) { } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { 0 ( ) [ yield ] ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { class x { } yield * x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { function * x ( ) { } yield * x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { throw yield * async x => { } ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * 0 ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * [ ] . x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * new . target ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * this . x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * { [ Symbol . iterator ] : async x => 0 } ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * { [ Symbol . iterator ] : async x => [ ] } ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * { [ Symbol . iterator ] : async x => this } ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * { [ Symbol . iterator ] : async x => x } ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * { [ Symbol . iterator ] : await => 0 } ; } } ; 
[ 0 , ] instanceof async function ( ) { } ; 
[ 0 . x = x ] = `` ; class x { } 
[ 0 ] instanceof async function ( ) { } ; 
[ ] = function * ( ) { [ 0 , , yield * 0 ] ; } ; 
[ ] = { [ Symbol . iterator ] : async function ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function ( ... [ ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { [ , yield ] ; } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... x ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( x ) { } } ; 
[ ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ ] = { [ Symbol . iterator ] : async x => { } } ; 
[ ] = { [ Symbol . iterator ] : function * ( ) { class x extends 0 { } } } ; 
[ ] = { [ Symbol . iterator ] : function * ( ) { x ; } } ; 
[ ] = { [ Symbol . iterator ] : function * x ( ) { yield * x ( ) ; } } ; 
[ ] = { [ Symbol . iterator ] : x => [ 0 , ] } ; 
[ ] = { [ Symbol . iterator ] : x => [ 0 ] } ; 
[ ] = { [ Symbol . iterator ] : x => [ ] } ; 
[ ] = { [ Symbol . iterator ] : x => async function * ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : x => class { } } ; 
[ ] = { [ Symbol . iterator ] : x => function ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : x => this } ; 
[ ] = { [ Symbol . iterator ] : x => x => 0 } ; 
[ ] = { [ Symbol . iterator ] : x } ; async function * x ( ) { } 
[ ] instanceof async function ( ) { } ; 
[ await . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ class extends async function * ( ) { } { } ] ; 
[ function * ( [ ] ) { } ( ) ] ; 
[ x . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ x ] = 0 ; let x ; 
[ { x , } . x ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
[ { x , } . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ { x , } = null ] ; let x ; 
[ { x } . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ { x } = null ] ; let x ; 
async function * await ( ) { } 
async function * x ( ) { } 
async function * x ( ) { } new x ; 
async function * x ( ) { } switch ( 0 ) { case 0 : new x ( ) ; default : case 0 : throw 0 ; } 
async function * x ( ... x ) { } 
async function * x ( x ) { } 
async function * x ( x , ... [ ] ) { } 
async function await ( ) { } 
async function x ( ) { } 
async function x ( ) { } new x ; 
async function x ( ... x ) { } 
async function x ( x ) { } 
async function x ( x , ... [ ] ) { } 
async x => { for await ( let x of '' ) { async function x ( ) { } } } ; 
class await { } 
class await { } ; 
class x extends '' { [ x ] ; } 
class x extends 0 ( ) { [ x ] ; } 
class x extends 0 . x { [ x ] ; } 
class x extends 0 { [ x ] ; } 
class x extends Symbol . match { [ x ] ; } 
class x extends [ ] { [ x ] ; } 
class x extends `` { [ x ] ; } 
class x extends async function ( ) { } { [ x ] ; } 
class x extends async function ( ) { } { } 
class x extends async function * ( ) { } { [ x ] ; } 
class x extends async function * ( ) { } { } 
class x extends await { [ 0 ( ) ] ; } 
class x extends class { } { } 
class x extends false { [ x ] ; } 
class x extends function * ( ) { } { [ x ] ; } 
class x extends function * ( ) { } { } 
class x extends function await ( ) { } { } 
class x extends null { static { var x ; } } new x ( ) ; 
class x extends this ( ) { [ x ] ; } 
class x extends this { [ x ] ; } 
class x extends true { [ x ] ; } 
class x extends x { [ 0 ( ) ] ; } 
class x extends { 0 ( ) { } , } { [ x ] ; } 
class x extends { 1 : null } { [ x ] ; } 
class x extends { get 0 ( ) { } , } { [ x ] ; } 
class x extends { x , } { [ 0 ( ) ] ; } 
class x extends { x } { [ 0 ( ) ] ; } 
class x extends { } { [ x ] ; } 
class x { '' ( ) { } } 
class x { * '' ( ) { } } 
class x { * 0 ( ) { } } 
class x { * 0 ( ... x ) { } } 
class x { * 0 ( x ) { } } 
class x { * 0 ( x , ... [ ] ) { } } 
class x { * 0n ( ) { } } 
class x { * [ 0 ] ( ) { } } 
class x { * x ( ) { } } 
class x { 0 ( ) { } } 
class x { 0 ( ... x ) { } } 
class x { 0 ( x ) { } } 
class x { 0 ( x , ... [ ] ) { } } 
class x { 1n ( ) { } } 
class x { [ '' ] ( ) { } } 
class x { [ 0 ] ( ) { } } 
class x { [ 0 in 0 ] ; } 
class x { [ 0 instanceof 0 ] ; } 
class x { [ 0n ] ( ) { } } 
class x { [ Symbol . split ] ( ) { } } 
class x { [ [ ] ] ( ) { } } 
class x { [ `` ] ( ) { } } 
class x { [ false ] ( ) { } } 
class x { [ null ] ( ) { } } 
class x { [ this ] ( ) { } } 
class x { [ true ] ( ) { } } 
class x { [ x = 0 ( ) . x -- ] ; } 
class x { [ x = 0 . x ++ ] ; } 
class x { [ x = 0 . x . x ] ; } 
class x { [ x = class extends 0 { } ] ; } 
class x { [ x = new 0 ] ; } 
class x { [ x = new new class { } ( ) ( ) ] ; } 
class x { [ x = new true ] ; } 
class x { [ x = null . x ] ; } 
class x { [ { [ Symbol . toPrimitive ] : '' } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : 0 } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : [ ] } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : `` } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function ( ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function ( x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function * ( ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function * ( x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async x => { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : class { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : false } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : function * ( ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : function * ( ... x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : function * ( x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : this } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : true } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : { * 0 ( ) { } , } } ] ; } 
class x { [ { x } = 0 ( ) ] ; } 
class x { [ { x } = 0 . x ] ; } 
class x { [ { x } = null ] ; } 
class x { [ { x } = void 0 ] ; } 
class x { [ { } ] ( ) { } } 
class x { async '' ( ) { } } 
class x { async * '' ( ) { } } 
class x { async * 0 ( ) { } } 
class x { async * 0 ( ... x ) { } } 
class x { async * 0 ( x ) { } } 
class x { async * 0 ( x , ... [ ] ) { } } 
class x { async * 1n ( ) { } } 
class x { async * [ 0 ] ( ) { } } 
class x { async * x ( ) { } } 
class x { async 0 ( ) { } } 
class x { async 0 ( ... x ) { } } 
class x { async 0 ( [ ] , ... x ) { } } 
class x { async 0 ( x ) { } } 
class x { async 0n ( ) { } } 
class x { async [ 0 ] ( ) { } } 
class x { async x ( ) { } } 
class x { get '' ( ) { } } 
class x { get 0 ( ) { } } 
class x { get 0n ( ) { } } 
class x { get [ '' ] ( ) { } } 
class x { get [ 0 ] ( ) { } } 
class x { get [ async function ( ) { } . x ] ( ) { } } 
class x { get [ class { } . x ] ( ) { } } 
class x { get [ false ] ( ) { } } 
class x { get [ function ( ) { } . x ] ( ) { } } 
class x { get [ function * ( ) { } . x ] ( ) { } } 
class x { get [ null ] ( ) { } } 
class x { get [ true ] ( ) { } } 
class x { get [ { } ] ( ) { } } 
class x { get x ( ) { } } 
class x { set '' ( x ) { } } 
class x { set 0 ( [ ] ) { } } 
class x { set 0 ( x ) { } } 
class x { set 0n ( x ) { } } 
class x { set [ 0 ] ( x ) { } } 
class x { set x ( x ) { } } 
class x { static * 0 ( ) { } } 
class x { static 0 ( ) { } } 
class x { static 0 = async function ( ) { } ; } 
class x { static 0 = async function * ( ) { } ; } 
class x { static 0 = async x => 0 ; } 
class x { static 0 = class extends { x , } { } ; } 
class x { static 0 = class extends { x } { } ; } 
class x { static 0 = class { } ; } 
class x { static 0 = function ( ) { } ; } 
class x { static 0 = function * ( ) { } ; } 
class x { static 0 = new function * ( ) { } ( ) ; } 
class x { static 0 = new x . x ; } 
class x { static 0 = new { x , } ; } 
class x { static 0 = new { x } ; } 
class x { static 0 = super [ { [ Symbol . toPrimitive ] : x } ] ; } 
class x { static 0 = super [ { [ Symbol . toPrimitive ] : { x } } ] ; } 
class x { static 0 = x ; } 
class x { static 0 = x = 0 ; } 
class x { static 0 = x => 0 ; } 
class x { static 0 = { x , } ; } 
class x { static 0 = { x , } = 0 ; } 
class x { static 0 = { x } ; } 
class x { static 0 = { x } = 0 ; } 
class x { static 0 = { x } [ 0 ] . x ; } 
class x { static 0n = x => 0 ; } 
class x { static [ class { } . x ] ( ) { } } 
class x { static [ this . x = 0 ] ; } 
class x { static async * 0 ( ) { } } 
class x { static async 0 ( ) { } } 
class x { static get 0 ( ) { } } 
class x { static set 0 ( x ) { } } 
class x { static { async function * x ( ) { } } } 
class x { static { async function x ( ) { } } } 
class x { static { async function x ( ) { } } } for ( let x of 0 ) ; 
class x { static { const x = super [ 0 ] ; } } 
class x { static { const x = this ; } } 
class x { static { for ( var [ ] = 0 , x ; ; ) ; } } 
class x { static { for ( var [ x , ] in 0 ) ; } } 
class x { static { for ( var [ x , ] of 0 ) ; } } 
class x { static { for ( var x ; ; ) throw 0 ; } } 
class x { static { for ( var x in 0 ) ; } } 
class x { static { for ( var x of 0 ) ; } } 
class x { static { for ( var { ... x } of 0 ( ) ) ; } } 
class x { static { for ( var { x } of 0 ) ; } } 
class x { static { function * x ( ) { } } } 
class x { static { function x ( ) { } } } 
class x { static { if ( 0 ) for ( var x ; ; ) ; } } 
class x { static { if ( 0 ) for ( var x of 0 ) ; } } 
class x { static { new 0 ; var x ; } } 
class x { static { var [ ] = 0 , x ; } } 
class x { static { var [ x ] = 0 ; } } 
class x { static { var x , [ ] = 0 ; } } 
class x { static { var x ; x ( ) ; } } 
class x { static { var x ; } } 
class x { static { var x ; } } class await extends 0 { } 
class x { static { var x ; } } let [ ] = 0 ; 
class x { static { var x ; } } var [ ] = 0 ; 
class x { static { var x = 0 ( ) ; } } 
class x { static { var x = 0 in 0 ; } } 
class x { static { var x = 0 instanceof 0 ; } } 
class x { static { var x = new 0 ( ) ; } } 
class x { static { var x = new 0 ; } } 
class x { static { var { ... x } = 0 ; } } 
class x { static { x ( ) ; function x ( ) { throw 0 ; } } } 
class x { static { x ( ) ; var x ; } } 
class x { x ( ) { x ; } } x ( ) ; 
class x { x ( ) { x ; } } x ; 
class x { x ( ) { } } 
class x { } x = new class { } ; 
const await = 0 ; 
const x = '' ; x = 0 ; 
const x = 0 ; this . x -- ; 
const x = 0 ; x = '' ; 
const x = 0 ; x = 0 ; 
const x = 0 ; x = 0 ; throw 0 ; 
const x = 0 ; x = Symbol ; 
const x = 0 ; x = [ ] ; 
const x = 0 ; x = `` ; 
const x = 0 ; x = class { } ; 
const x = 0 ; x = false ; 
const x = 0 ; x = null ; 
const x = 0 ; x = this ; 
const x = 0 ; x = true ; 
const x = 0 ; x = x ; 
const x = 0 ; x = { x , } ; 
const x = 0 ; x = { x } ; 
const x = 0 ; x = { } ; 
const x = Symbol ; x = 0 ; 
const x = [ ] ; x = 0 ; 
const x = `` ; x = 0 ; 
const x = class { } ; x = 0 ; 
const x = false ; x = 0 ; 
const x = function ( ) { } ; x = 0 ; 
const x = null ; x = 0 ; 
const x = this ; x = 0 ; 
const x = true ; x = 0 ; 
const x = { } ; x = 0 ; 
const { ... x } = 0 ; x = 0 ; 
do ; while ( new async function * ( ) { } ( ) ) ; 
do ; while ( new function * ( ) { } ) ; 
do x ; while ( 0 ) ; class x { } 
eval ( typeof new function * ( ) { } ( ) ) ; 
eval ( typeof new function * ( ) { } ) ; 
for ( 0 ( ) . x in function * ( ) { } ) ; 
for ( 0 . x in function * ( ) { } ) ; 
for ( 0 [ 0 ] in function * ( ) { } ) ; 
for ( ; new async function ( x , ) { } ( ) ; ) ; 
for ( ; new function * ( ) { } ; ) ; 
for ( await ( ) . x of '' ) ; 
for ( await of '' ) ; 
for ( await of 0 ) ; 
for ( await of [ , ] ) ; 
for ( await of `` ) ; 
for ( const [ x ] = { x , } ; ; ) ; 
for ( const [ x ] = { x } ; ; ) ; 
for ( const x = x ; 0 ; ) ; 
for ( const x = x ; ; ) break ; 
for ( const x = x = 0 ; ; ) ; 
for ( const x = { x , } ; 0 ; ) ; 
for ( const x = { x } ; 0 ; ) ; 
for ( const { x , } = x ; ; ) ; 
for ( let [ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 0 ; ) ; 
for ( let x ; new async function * ( x ) { } ( ) ; ) ; 
for ( let x ; new function * ( ) { } ; ) ; 
for ( let x in 0 ) ; for ( { x , } in [ 0 ] ) ; 
for ( let x in x ) ; 
for ( let x in x ** 0 ) ; 
for ( let x in { x , } ) ; 
for ( let x in { x , } ** 0 ) ; 
for ( let x in { x } ) ; 
for ( let x in { x } ** 0 ) ; 
for ( let x of x ) ; 
for ( let x of { x , } ) ; 
for ( let x of { x } ) ; 
for ( let { x : [ ] } in function * ( ) { } ) ; 
for ( var [ ] = class { async #x ( ) { } } ; ; ) ; 
for ( var await = 0 ; 0 ; ) ; 
for ( var await = 0 ; ; ) break ; 
for ( var x ; 0 ; ) ; x = x => 0 ; 
for ( var x ; new function * ( ) { } ; ) ; 
for ( var x = x => 0 ; 0 ; ) ; 
for ( var x = x => 0 ; ; ) break ; 
for ( var x in 0 ) ; x = x => 0 ; 
for ( var x in function * ( ) { } ) ; 
for ( var x of [ x => 0 , ] ) ; 
for ( var { ... await } = 0 ; ; ) break ; 
for ( x ; ; ) ; let x ; 
for ( x in [ 0 ] ) ; const x = 0 ; 
for ( x in [ 0 ] ) ; let [ ] = 0 , x ; 
for ( x in [ 0 ] ) ; let x ; 
for ( x in [ 0 ] ) try { } catch ( [ x ] ) { } 
for ( x in async function * ( ) { } ( ) ) ; 
for ( x in function * ( ) { } ) ; 
for ( x in new function * ( ) { } ( ) ) ; 
for ( x in new function * ( ) { } ) ; 
for ( x of [ , ] ) ; let x ; 
for ( { x , } in [ 0 ] ) ; let x ; 
for ( { x = 0 } in [ 0 ] ) ; let x ; 
for ( { x = async function * ( x ) { } } in [ 0 ] ) var x ; 
for ( { x = async x => 0 } in [ 0 ] ) var x ; 
for ( { x = class extends async function ( ) { } { } } in [ 0 ] ) ; 
for ( { x = function * ( ) { } } in [ 0 ] ) var x ; 
for ( { x = x => 0 } in [ 0 ] ) for ( var x in 0 ) ; 
for ( { x = x => 0 } in [ 0 ] ) var x ; 
for ( { x } in [ 0 ] ) ; let x ; 
for ( { x } in [ 0 ] ) { function x ( ) { } } 
for ( { } in [ 0 ] ) x ; class x { } 
for ( { } in [ new async function ( ) { } ] ) x ; 
function * await ( ) { } 
function * x ( ) { } 
function * x ( ) { } new x ; 
function * x ( ... x ) { } 
function * x ( [ ] ) { } 
function * x ( [ ] ) { } x ( ) ; 
function * x ( x ) { } 
function * x ( x , ... [ ] ) { } 
function * x ( { x , } ) { } x ( ) ; 
function * x ( { } ) { } x ( ) ; 
function await ( ) { } 
function await ( ) { } ; 
function await ( ... x ) { } 
function await ( [ ] , ... x ) { } 
function await ( x ) { } 
function x ( ) { } x = x => 0 ; 
if ( 0 ) for ( var x ; ; ) ; else ; x = x => 0 ; 
let [ , ] = { [ Symbol . iterator ] : async function * ( [ ] ) { } } ; 
let [ , { ... x } ] = [ 0 ] ; 
let [ ... await ] = `` ; 
let [ ... x ] = [ , 0 , ] ; 
let [ ... x ] = [ , 0 ] ; 
let [ ... x ] = [ , ] ; 
let [ ... x ] = [ 0 , , 0 ] ; 
let [ ... x ] = [ 0 , , ] ; 
let [ ... x ] = [ function await ( ) { } ] ; 
let [ ... x ] = [ { 0 : function ( x ) { } } ] ; 
let [ ... x ] = [ { async * 0 ( ) { } , } ] ; 
let [ ... { ... await } ] = `` ; 
let [ [ ] , ... x ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let [ [ ] = x ] = `` ; class x { } 
let [ [ x ] = function * ( ) { x ; } ] = await ; 
let [ [ x ] = function * ( ) { x ; } ] = x ; 
let [ [ x ] = function * ( ) { x ; } ] = { [ Symbol . iterator ] : ( ) => { throw 0 ; } } ; 
let [ [ x ] = function * ( ) { x ; } ] = { x , } ; 
let [ [ x ] = function * ( ) { x ; } ] = { x } ; 
let [ ] = function * ( ) { for ( ; ; ) ; } ( ) ; 
let [ ] = function * ( ) { let [ ] = 0 ; } ( ) ; 
let [ ] = function * ( ) { x ; } ( ) ; 
let [ ] = new function * ( ) { } ( ) ; 
let [ ] = new function * ( ) { } ; 
let [ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
let [ ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let [ x , ... await ] = `` ; 
let [ x , ... { ... await } ] = `` ; 
let [ x = class { } ] = [ ] ; 
let [ x = class { } ] = `` ; 
let [ x = function ( ) { } ] = `` ; 
let [ x ] = [ async function ( ) { } ] ; 
let [ x ] = [ async function * ( ) { } ] ; 
let [ x ] = [ async x => 0 ] ; 
let [ x ] = [ class { } ] ; 
let [ x ] = [ function ( ) { } ] ; 
let [ x ] = [ function * ( ) { } ] ; 
let [ x ] = [ x => 0 , ] ; 
let [ x ] = [ x => 0 ] ; 
let [ x ] = function * ( ) { 0 ( ) . x = yield ; } ( ) ; 
let [ x ] = function * ( ) { do ; while ( { x , } ) ; } ( ) ; 
let [ x ] = function * ( ) { throw yield * 0 ; } ( ) ; 
let [ x ] = function * ( ) { throw { x , } ( ) ; } ( ) ; 
let [ x ] = function * ( ) { throw { x , } ; } ( ) ; 
let [ x ] = function * ( ) { x : await : ; } ( ) ; 
let [ x ] = function * ( ) { x ; } ( ) ; 
let [ x ] = function * ( ) { yield * 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield * 1n ; } ( ) ; 
let [ x ] = function * ( ) { yield * Symbol ; } ( ) ; 
let [ x ] = function * ( ) { yield * [ , ] ; x ; } ( ) ; 
let [ x ] = function * ( ) { yield * async function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * async function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * async x => { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * class { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * false ; } ( ) ; 
let [ x ] = function * ( ) { yield * function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * null ; } ( ) ; 
let [ x ] = function * ( ) { yield * this ; } ( ) ; 
let [ x ] = function * ( ) { yield * true ; } ( ) ; 
let [ x ] = function * ( ) { yield * x => { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { 1 : '' } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { [ Symbol . iterator ] : ( ... [ ] ) => 0 } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { [ Symbol . iterator ] : async function ( ) { } } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { [ Symbol . iterator ] : async x => { } } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { [ Symbol . iterator ] : x => 0 } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { set 0 ( x ) { } , } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { x , } ; } ( ) ; 
let [ x ] = function * ( ) { yield * { } ; } ( ) ; 
let [ x ] = function * ( ) { yield 0 ; x ; } ( ) ; 
let [ x ] = function * ( ) { yield ; x ; } ( ) ; 
let [ x ] = function * ( ) { yield async function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield async function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield async x => 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield class { } ; } ( ) ; 
let [ x ] = function * ( ) { yield function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield x => 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield { [ Symbol . species ] : function ( x ) { } } ; } ( ) ; 
let [ x ] = function * ( ) { yield { x , } ; } ( ) ; 
let [ x ] = function * ( ) { { x } ; } ( ) ; 
let [ { ... await } ] = `` ; 
let [ { ... x } , ] = `` ; 
let [ { ... x } ] = `` ; 
let [ { ... x } ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let await ; 
let x ; [ { x = class { } } = 0 ] ; 
let x ; [ { x = function ( ) { } } = 0 ] ; 
let x ; x = function ( ) { x ; } ; 
let x ; x = function * ( ) { } ; 
let x ; x = x => 0 ; 
let x = ( ) => 0 ; 
let x = async function ( ) { } ; 
let x = async function * ( ) { } ; 
let x = async function * ( [ ] ) { } ( ) ; 
let x = async x => 0 ; 
let x = class await { } ; 
let x = class extends function * ( ) { } { } ; 
let x = function * ( ) { } ; 
let x = function await ( ) { } ; 
let x = function await ( ... x ) { } ; 
let x = function await ( x , ) { } ; 
let x = new class { } ; 
let x = new function * ( ) { } ( ) ; 
let x = new function * ( ) { } ; 
let x = x => 0 ; 
let x = { 0 ( ) { } , } ; 
let x = { 0 ( ) { } } ; 
let { ... await } = 0 ; 
let { ... await } = Symbol ; 
let { ... await } = [ ] ; 
let { ... await } = function * ( ) { } ; 
let { ... x } = 0 . x ; 
let { ... x } = 0 [ 0 ] ; 
let { ... x } = [ x => 0 , ] ; 
let { ... x } = async function * ( ) { } . x ; 
let { ... x } = function * ( ) { } ( ) ; 
let { ... x } = function * ( x , ) { } ( ) ; 
let { ... x } = null ; 
let { ... x } = { * '' ( ) { } , } ; 
let { ... x } = { 1 : ( ) => { } } ; 
let { 0 : x , ... await } = function * ( ) { } ; 
let { x , ... await } = 0 ; 
let { x = class { } } = 0 ; 
new ( async x => 0 ) ( ) ; 
new ( async x => 0 ) ; 
new async function ( ) { } ( ) ; 
new async function ( ) { } ; 
new async function ( ... x ) { } ; 
new async function ( x ) { } ; 
new async function ( x , ... [ ] ) { } ; 
new async function * ( ) { } ( ) ; 
new async function * ( ) { } ; 
new async function * ( ... x ) { } ; 
new async function * ( x ) { } ; 
new async function * ( x , ... [ ] ) { } ; 
new function ( ) { new x ( ) ; } ; class x { } 
new function ( ) { x ; } ; class x { } 
new function ( ... [ { ... x } , ] ) { } ; 
new function ( ... x ) { async function x ( ) { } x ( ) ; } ; 
new function ( ... x ) { function * x ( ) { } x ( ) ; throw 0 ; } ; 
new function ( ... x ) { function * x ( ) { } x ( ) ; } ; 
new function ( ... x ) { function x ( ) { } new x ( ) ; } ; 
new function ( ... x ) { function x ( ) { } x ( ) ; } ; 
new function ( ... x ) { function x ( x ) { } x ( ) ; } ; 
new function ( ... x ) { x ( ) ; async function x ( ... x ) { } } ; 
new function ( ... x ) { x ( ) ; await ; function x ( ) { } } ; 
new function ( ... x ) { x ( ) ; function x ( ) { } } ; 
new function ( ... x ) { x ( ) ; throw 0 ; function x ( ) { } } ; 
new function ( { ... x } ) { } ; 
new function ( { ... x } , ... [ ] ) { } ; 
new function ( { [ x ] : x } ) { } ; 
new function * ( ) { } ( ) ; 
new function * ( ) { } ; 
new function * ( ... x ) { } ; 
new function * ( x ) { } ; 
new function * ( x , ... [ ] ) { } ; 
new x ( ) ; function * x ( ) { } 
new x ; function * x ( ) { } 
null ( ... x ) ; 
null ( 0 , ... x ) ; 
null ( x , ... 0 ) ; 
null ?? x ; class x { } 
switch ( 0 ) { case 0 : async function * x ( ) { } case 0 : new x ( ) ; } 
switch ( 0 ) { case 0 : async function x ( ) { } default : new x ( ) ; } 
switch ( 0 ) { case 0 : await : x : ; } 
switch ( 0 ) { case 0 : default : x ( ) ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : default : x ( ) ; throw 0 ; case 0 : function * x ( ) { } } 
switch ( 0 ) { case 0 : function * x ( ) { } default : new x ( ) ; } 
switch ( 0 ) { case 0 : x ( ) ; async function * x ( ) { } default : throw 0 ; } 
switch ( 0 ) { case 0 : x ( ) ; async function * x ( ) { } default : } 
switch ( 0 ) { case 0 : x ( ) ; default : async function * x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : async function x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : function * x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : function * x ( ... x ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : function x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : throw 0 ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : throw function ( ) { } ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; default : throw this ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : x ( ) ; } class x { } 
switch ( 0 ) { case 0 : x ; default : throw 0 ; } class x { } 
switch ( 0 ) { case 0 : x ; default : } class x { } 
switch ( 0 ) { case 0 : x ; throw 0 ; } class x { } 
switch ( 0 ) { case 0 : x ; } class x { } 
switch ( 0 ) { case 1 : let x ; default : case 0 : x ; } 
switch ( 0 ) { case new function * ( ) { } : default : case 0 : x ; } 
switch ( 0 ) { case x : default : } class x { } 
switch ( 0 ) { case x : function * x ( ) { } default : x ( ) ; } 
switch ( 0 ) { case x : function * x ( ) { } default : x ( ) ; } x ; 
switch ( 0 ) { default : case 0 : x ( ) ; case 0 : function * x ( ) { } } 
switch ( 0 ) { default : case 0 : x ; } class x { } 
switch ( 0 ) { default : function x ( ) { } case 0 : x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : new x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : x ; throw 0 ; } 
switch ( 0 ) { default : let x ; case 0 : x ; } 
switch ( 0 ) { default : let x ; case x : } 
switch ( 0 ) { default : x ( ) ; case 1 : async function * x ( ) { } } 
switch ( 0 ) { default : x ( ) ; case 1 : function * x ( x , ) { } } 
switch ( 0 ) { default : x ( ) ; case x : async function * x ( ) { } } 
switch ( 0 ) { default : x ( ) ; } class x { } 
switch ( 0 ) { default : x : await : ; } 
switch ( 0 ) { default : x ; case 1 : throw 0 ; } class x { } 
switch ( 0 ) { default : x ; throw 0 ; } class x { } 
switch ( 0 ) { default : x ; } class x { } 
switch ( 1 ) { case 0 : let x ; default : case 0 : new x ( ) ; } 
switch ( 1 ) { case 0 : let x ; default : x ( ) ; } 
switch ( 1 ) { default : case 0 : x ; } class x { } 
switch ( 1 ) { default : case new async function ( ) { } : x ; } 
switch ( 1 ) { default : class x { } case x : } 
this . x = async function ( ) { } ; 
this . x = async function * ( ) { } ; 
this . x = async x => 0 ; 
this . x = class { } ; 
this . x = function * ( ) { } ; 
this . x = x => 0 ; 
this [ 0 ] = x => 0 ; 
this instanceof async function ( ) { } ; 
throw 0 ; x = async x => 0 ; 
throw async function * ( [ x ] ) { } ( ) ; 
try { throw 0 ; } finally { new x ( ) ; } function * x ( ) { } 
try { } catch ( [ ... x ] ) { } x `` ; 
try { } catch ( [ x ] ) { } x ( ) ; 
try { } catch ( { x } ) { } finally { } x ; 
try { } catch ( { x } ) { } x ; 
var [ ... await ] = '' ; 
var [ ... await ] = `` ; 
var [ ... x ] = [ , 0 ] ; 
var [ ... x ] = [ , ] ; 
var [ ... x ] = [ 0 , , 0 , ] ; 
var [ ... x ] = [ 0 , , ] ; 
var [ [ ] , ... x ] = { [ Symbol . iterator ] : async function * ( x ) { } } ; 
var [ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
var [ ] = { [ Symbol . iterator ] : async function * ( x ) { } } ; 
var [ x , ... await ] = '' ; 
var [ x , ... x ] = [ , , ] ; 
var [ x , ... x ] = [ 0 , , 0 , ] ; 
var [ x , ] = [ x => 0 , ] ; 
var [ x , x ] = [ 0 , , ] ; 
var [ x = class { } ] = '' ; 
var [ { ... x } , ] = '' ; 
var [ { ... x } ] = '' ; 
var await = 0 ; 
var x ; for ( { x = x => 0 } in [ 0 ] ) ; 
var x ; x = async function ( ) { } ; 
var x ; x = async function * ( ) { } ; 
var x ; x = x => 0 ; 
var x = ( ... x ) => 0 ; 
var x = async function ( ) { } ; 
var x = async function * ( ) { } ; 
var x = async x => 0 ; 
var x = class extends class { } { } ; 
var x = class extends function * ( ) { } { } ; 
var x = class { * 0 ( x , ) { } } ; 
var x = class { static 0 ( ) { } } ; 
var x = function * ( ) { } ; 
var x = new class { } ( ) ; 
var x = new class { } ; 
var x = x => 0 ; 
var x = x => new async function ( ) { } ( ) ; x ( ) ; 
var x = { * 0 ( ) { } } ; 
var x = { 0 ( ) { } , } ; 
var x = { 0 ( ) { } } ; 
var x = { 0 : function ( x ) { } } ; 
var x = { [ Symbol . split ] : function ( x ) { } } ; 
var x = { async * 0 ( ) { } } ; 
var x = { async 0 ( ) { } } ; 
var x = { set [ 0 ] ( x ) { } , } ; 
var x = { } ; Object . setPrototypeOf ( x , async function ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , async function ( ) { } . prototype ) ; 
var x = { } ; Object . setPrototypeOf ( x , async function * ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , async x => 0 ) ; 
var x = { } ; Object . setPrototypeOf ( x , class { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , function * ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , x => 0 ) ; 
var { ... await } = 0 ; 
var { ... await } = 0n ; 
var { ... await } = [ ] ; 
var { ... x } = 0 . x ; 
var { ... x } = 0 [ 0 ] ; 
var { ... x } = null ; 
var { ... x } = x ; 
var { ... x } = { 0 ( ) { } } ; 
var { ... x } = { 0 : x => 0 } ; 
var { ... x } = { [ Symbol . split ] : ( ) => { } } ; 
var { 0 : x } = { * 0 ( x ) { } } ; 
var { 0 : { ... x } , } = 0 ; 
var { 0 : { ... x } } = 0 ; 
var { x , ... await } = 0 ; 
var { x , ... await } = 0n ; 
var { x , ... await } = [ ] ; 
var { x , ... x } = { 0 : x => { } } ; 
var { x , ... x } = { [ Symbol . split ] : ( ) => { } } ; 
var { x = class { } } = 0 ; 
var { x = function ( ) { } } = 0 ; 
var { x = function ( ... x ) { } } = 0 ; 
var { x } = { x : async function ( ) { } , } ; 
var { x } = { x : async function * ( ) { } , } ; 
var { x } = { x : async x => 0 , } ; 
var { x } = { x : function * ( ) { } , } ; 
var { x } = { x : x => 0 , } ; 
var { x } = { x : { 1 : function ( x ) { } } , } ; 
var { } = new function * ( ) { } ; 
x . x ; try { } catch ( { ... x } ) { } finally { } 
x ; class x { static { var x ; } } 
x ; try { } catch ( { x } ) { } 
x ; try { } catch ( { x } ) { } finally { } 
x = 0 ( ) ** 0 ; let x ; 
x = 0 ( ) ; let x ; 
x = 0 . x ( ) ; let x ; 
x = 0 . x -- ; let x ; 
x = 0 . x . x ; let x ; 
x = 0 . x = 0 ; let x ; 
x = 0 . x [ 0 ] ; let x ; 
x = 0 [ 0 ] -- ; let x ; 
x = 0 [ 0 ] [ 0 ] ; let x ; 
x = 0 in 0 ; let x ; 
x = 0 instanceof 0 ; let x ; 
x = Symbol . toPrimitive & 0 ; let x ; 
x = Symbol . toPrimitive < 0 ; let x ; 
x = Symbol . toPrimitive <= 0 ; let x ; 
x = [ ... 0 , ] ; let x ; 
x = [ ... 0 ] ; let x ; 
x = [ 0 , ... 0 , ] ; let x ; 
x = [ 0 , ... 0 ] ; let x ; 
x = async x => 0 ; 
x = class extends 0 { } ; let x ; 
x = class extends function * ( ) { } { } ; 
x = function * ( [ x , ] , ) { } ( ) ; 
x = new 0 ( ) ; let x ; 
x = new 0 ; let x ; 
x = new function * ( ) { } ( ) ; 
x = new { } ; let x ; 
x = this . x -- ; 
x = this . x = 0 ; 
x = { [ Symbol . toPrimitive ] : `` } != 0 ; let x ; 
x = { [ Symbol . toPrimitive ] : async function ( x ) { } } != 0 ; class x { } 
{ x } ; try { } catch ( { x } ) { } finally { } 
~ async function ( ) { for await ( let x of '' ) { class x { } } } ( ) ; 
~ async function * ( [ ] ) { } ( ) ; 
~ async function * ( [ ] , ... x ) { } ( ) ; 
~ async function * ( [ x ] ) { } ( ) ; 
~ function * ( [ ] ) { } ( ) ; 
~ function * ( [ ] , ... [ ] ) { } ( ) ; 
~ function * ( [ ] , ... x ) { } ( ) ; 
