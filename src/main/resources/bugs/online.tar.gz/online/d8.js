"use strict";
class x extends '' { [ x ] ; } 
class x extends 0 . x { [ x ] ; } 
class x extends 0 { [ x ] ; } 
class x extends Symbol . match { [ x ] ; } 
class x extends [ ] { [ x ] ; } 
class x extends `` { [ x ] ; } 
class x extends async function ( ) { } { [ x ] ; } 
class x extends async function ( ... x ) { } { [ x ] ; } 
class x extends async function ( x ) { } { [ x ] ; } 
class x extends async function * ( ) { } { [ x ] ; } 
class x extends async function * ( ... x ) { } { [ x ] ; } 
class x extends async function * ( x ) { } { [ x ] ; } 
class x extends false { [ x ] ; } 
class x extends function * ( ) { } { [ x ] ; } 
class x extends function * ( ... x ) { } { [ x ] ; } 
class x extends function * ( [ ] ) { } { [ x ] ; } 
class x extends function * ( x ) { } { [ x ] ; } 
class x extends this { [ x ] ; } 
class x extends true { [ x ] ; } 
class x extends { 0 ( ) { } , } { [ x ] ; } 
class x extends { 0 ( ) { } } { [ x ] ; } 
class x extends { 0 : ( ) => { } } { [ x ] ; } 
class x extends { 0 : function ( x ) { } } { [ x ] ; } 
class x extends { 1 : null } { [ x ] ; } 
class x extends { async 0 ( ) { } , } { [ x ] ; } 
class x extends { get 0 ( ) { } , } { [ x ] ; } 
class x extends { get : null } { [ x ] ; } 
class x extends { set 0 ( x ) { } , } { [ x ] ; } 
class x extends { } { [ x ] ; } 
new function ( ... x ) { async function * x ( ) { } x ( ) ; var x ; } ; 
new function ( ... x ) { function x ( ) { } x ( ) ; for ( var x ; 0 ; ) ; } ; 
new function ( ... x ) { function x ( x ) { } for ( var x in 0 ) ; x ( ) ; } ; 
new function ( ... x ) { var x ; function x ( ) { } new x ( ) ; } ; 
new function ( ... x ) { var x ; function x ( ) { } x ( ) ; } ; 
new function ( ... x ) { var x ; x ( ) ; async function x ( ... [ ] ) { } } ; 
new function ( ... x ) { var x ; x ( ) ; function * x ( ) { } } ; 
new function ( ... x ) { var x ; x ( ) ; function * x ( ) { } } ; throw 0 ; 
new function ( ... x ) { var x ; x ( ) ; function x ( ) { } } ; 
new function ( ... x ) { var x ; x ( ) ; function x ( ) { } } ; x ; 
new function ( ... x ) { x ( ) ; var x ; async function x ( ) { } } ; 
new function ( ... x ) { x ( ) ; var x ; function x ( ) { } } ; 
x = this . x -- ; 
x = this . x = 0 ; 
