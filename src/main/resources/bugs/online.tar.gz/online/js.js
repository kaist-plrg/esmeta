"use strict";
0 ? delete { await , } : 0 ( ) ; 
Object . setPrototypeOf ( '' ) ; 
Object . setPrototypeOf ( 0 ) ; 
Object . setPrototypeOf ( 0 ) ; throw 0 ; 
Object . setPrototypeOf ( 1n ) ; 
Object . setPrototypeOf ( `` ) ; 
Object . setPrototypeOf ( false ) ; 
Object . setPrototypeOf ( true ) ; 
Object . setPrototypeOf . call ( ( ) => { } , 0 ) ; 
Object . setPrototypeOf . call ( ( ... [ ] ) => { } , 0 ) ; 
Object . setPrototypeOf . call ( Symbol , 0 ) ; 
Object . setPrototypeOf . call ( async function ( ) { } , 0 ) ; 
Object . setPrototypeOf . call ( async function ( x ) { } , 0 ) ; 
Object . setPrototypeOf . call ( async function * ( ) { } , 0 ) ; 
Object . setPrototypeOf . call ( async function * ( x ) { } , 0 ) ; 
Object . setPrototypeOf . call ( async x => { } , 0 ) ; 
Object . setPrototypeOf . call ( class { } , 0 ) ; 
Object . setPrototypeOf . call ( function ( ) { } , 0 ) ; 
Object . setPrototypeOf . call ( function ( ... [ ] ) { } , 0 ) ; 
Object . setPrototypeOf . call ( function ( x ) { } , 0 ) ; 
Object . setPrototypeOf . call ( function * ( ) { } , 0 ) ; 
Object . setPrototypeOf . call ( function * ( x ) { } , 0 ) ; 
Object . setPrototypeOf . call ( null , 0 ) ; 
Object . setPrototypeOf . call ( this , 0 ) ; 
Object . setPrototypeOf . call ( x => { } , 0 ) ; 
Object . setPrototypeOf . call ( { * 0 ( ) { } } , 0 ) ; 
Object . setPrototypeOf . call ( { } , 0 ) ; 
String . prototype . normalize ( [ ] ) ; 
String . prototype . normalize ( `` ) ; 
String . prototype . normalize . call ( 0 , '' ) ; 
String . prototype . normalize . call ( 0 , [ ] ) ; 
String . prototype . normalize . call ( 0 , `` ) ; 
class x { [ x = delete 0 ( ) ] ; } 
class x { static 0 = delete 0 ( ) ; } 
class x { static 0 = x &&= 0 ; } 
const { ... x } = 0 ; x &&= 0 ; 
do ; while ( delete 0 ( ) ) ; 
for ( ; ; delete 0 ( ) ) break ; 
for ( var x ; ; delete 0 ( ) ) break ; 
new function ( { [ x ] : x } ) { } ; 
switch ( 0 ) { default : case delete 0 ( ) : } 
switch ( delete new 0 ) { } 

class x { [ x = 0 === 0 in 0 ] ; } 
x = 0 === 0 in 0 ; let x ; 
x = 0 === 0 instanceof 0 ; let x ; 
x = 0 in 0 === 0 ; let x ; 
