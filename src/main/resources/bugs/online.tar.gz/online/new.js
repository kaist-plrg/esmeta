// d8
class x extends '' { [ x ] ; }
new function ( ... x ) { x ( ) ; var x ; function x ( ) { } } ;

//js
x = 0 === 0 in 0 ; let x ;

//obf
Array . prototype . every . call ( `${ 0 }` , x => class x extends { x , } { } ) ; //(x => class x extends { x , } { })() ;

// terser
if ( 0 ) var [ ] = 0 ;
do continue ; while ( delete 0 ( ) ) ;
