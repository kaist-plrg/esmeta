! async function ( ) { } / 0 ; 
! async function ( ... x ) { } / 0 ; 
! async function ( [ ] ) { } / 0 ; 
! async function ( x , ) { } / 0 ; 
! class { } ( ) ; 
"use strict";
'' ( await => 0 ) ; 
( ... x ) => class { } ( ) ; 
( 0 ? await => 0 : 0 ) ( ) ; 
( await => 0 ( ) ) ( ) ; 
( await => 0 ) ( ) ( ) ; 
( await => 0 , 0 ) * 1n ; 
( await => 0 , 0 ) . x ++ ; 
( await => 0 . x = 0 ) ( ) ; 
( await => 0 in 0 ) ( ) ; 
( await => [ ... 0 , ] ) ( ) ; 
( await => [ ... 0 ] ) ( ) ; 
( await => await ( ) ) ( ) ; 
( await => function ( ) { } ( ) . x ) ( ) ; 
( await => this ( ) ) ( ) ; 
( await => x ( ) ) ( ) ; 
( await => x ) ( ) ; 
( await => { [ ... 0 ] ; } ) ( ) ; 
( await => { for ( let x of 0 ) ; } ) ( ) ; 
( await => { throw 0 ; } ) ( ) ; 
( await => { x ; } ) ( ) ; 
( class { } ( ) ) ; 
( class { } ( ) ** 0 ) ; 
( class { } ) ( ) ; 
+ 1n ; await : ; 
+ Symbol . toPrimitive ; await : ; 
+ { 0 : await => 0 , x } ; 
++ 0 [ 0 ] ; await : ; 
- Symbol . toPrimitive ; await : ; 
- class extends true { } ; 
- class { } ( ) ; 
- { ... await => 0 , x } ; 
- { [ Symbol . toPrimitive ] : 0 ? await => 0 : 0 } ; 
- { [ Symbol . toPrimitive ] : await => [ 0 , ] } ; 
- { [ Symbol . toPrimitive ] : await => [ 0 ] } ; 
- { [ Symbol . toPrimitive ] : await => async function * ( ) { } } ; 
- { [ Symbol . toPrimitive ] : await => async x => 0 } ; 
- { [ Symbol . toPrimitive ] : await => class { } } ; 
- { [ Symbol . toPrimitive ] : await => function * ( ) { } } ; 
- { [ Symbol . toPrimitive ] : await => this } ; 
- { [ Symbol . toPrimitive ] : await => x => 0 } ; 
- { [ Symbol . toPrimitive ] : await => x } ; 
- { [ Symbol . toPrimitive ] : await => { x ; } } ; 
- { [ null . toPrimitive ] : await => 0 } ; 
- { [ x ] : await => 0 } ; 
- { [ { [ Symbol . toPrimitive ] : '' } ] : await } ; 
-- 0 . x ; await : ; 
0 && await ; 
0 ( ) . x = await ; 
0 ( ) ; await ; 
0 ( ) [ 0 ] = await ; 
0 ( ) [ await ] ; 
0 ( ) `${ await => 0 }` ; 
0 ( ... await => 0 ) ; 
0 ( 0 ?? await ) ; 
0 ( await => 0 ) ; 
0 ( x , ... await => 0 ) ; 
0 , 0 ( ) [ await => 0 ] ; 
0 . x &&= await ; 
0 . x ( ) ; await : ; 
0 . x ( ) [ await ] ; 
0 . x -- ; await : ; 
0 . x . x [ await ] ; 
0 . x = 0 && await ; 
0 . x = 0 ?? await ; 
0 . x [ 0 ] [ await ] ; 
0 <= Symbol . toPrimitive ; await : ; 
0 == 0 ^ 1 ? await : 0 ; 
0 == 0 ^ true ? await : 0 ; 
0 ? await : 0 ; 
0 ? await => 0 : x ; 
0 ?? await ; 
0 [ 0 ] = await => 0 ; 
0 [ 0 ] [ 0 ] [ await => 0 ] ; 
0 ^ 1n ? await : 0 ; 
0 ^ Symbol . toPrimitive ? await : 0 ; 
0 instanceof 0 || await ; 
0 instanceof [ ] ; await : ; 
1 ** class { } ( ) ; 
1 ? 0 : await ; 
1 ? x : await => 0 ; 
1 || await ; 
1n * `${ await => { } , 0 }` ; 
1n * class { } ( ) . x -- ; 
1n * class { } ( ) ; 
1n * { [ 0 ] : await => 0 } ; 
AggregateError ( await => 0 ) ; 
Array ( 0 , class { } ( ) ) ; 
Array . from ( ) ; await : ; 
Array . from ( await => 0 , 0 ) ; 
Array . from ( { [ Symbol . iterator ] : await => 0 } ) ; 
Array . from . call ( await => 0 ) ; 
Array . prototype . every . call ( `${ 0 }` , x => class x extends { x , } { } ) ; 
BigInt ( ) ; await : ; 
BigInt . asUintN ( { [ Symbol . toPrimitive ] : await => 0 } ) ; 
BigInt . call ( await => 0 ) ; 
Function . apply . call ( ) ; await : ; 
Map ( await => 0 ) ; 
Map . prototype . size ; await : ; 
Number ( { [ Symbol . toPrimitive ] : 0 ? await : 0 } ) ; 
Object . create ( ) ; await : ; 
Object . create ( 0 , await => 0 ) ; 
Object . create ( await => 0 , [ 0 ] ) ; 
Object . defineProperties ( ) ; await : ; 
Object . defineProperties ( await => 0 ) ; 
Object . defineProperty ( ) ; await : ; 
Object . defineProperty ( await => 0 ) ; 
Object . entries . call ( await => 0 ) ; 
Object . fromEntries ( await => 0 ) ; 
Object . getOwnPropertyDescriptor ( await => 0 , { [ Symbol . toPrimitive ] : 0 } ) ; 
Object . getOwnPropertyDescriptor . call ( await => 0 ) ; 
Object . getOwnPropertyDescriptors ( ) ; await : ; 
Object . getOwnPropertyDescriptors . call ( await => 0 ) ; 
Object . getOwnPropertySymbols ( ) ; await : ; 
Object . getOwnPropertySymbols . call ( await => 0 ) ; 
Object . getPrototypeOf . call ( await => 0 ) ; 
Object . hasOwn . call ( await => 0 ) ; 
Object . isPrototypeOf . call ( null , await => 0 ) ; 
Object . keys . call ( await => 0 ) ; 
Object . setPrototypeOf ( await => 0 ) ; 
Object . values ( ) ; await : ; 
Object . values . call ( await => 0 ) ; 
Promise ( await => 0 ) ; 
Set ( await => 0 ) ; 
String ( { [ Symbol . toPrimitive ] : 0 ?? await } ) ; 
String . prototype . normalize ( { [ Symbol . toPrimitive ] : await => 0 } ) ; 
String . raw ( await => 0 ) ; 
Symbol ( { [ Symbol . toPrimitive ] : 0 ?? await } ) ; 
Symbol . keyFor ( await => 0 ) ; 
Symbol . toPrimitive & 0 ; await : ; 
Symbol . toPrimitive + 0 ; await : ; 
Symbol . toPrimitive + typeof await ; 
Symbol . toPrimitive < 0 ; await : ; 
WeakMap ( await => 0 ) ; 
WeakSet ( await => 0 ) ; 
[ , ] = { [ Symbol . iterator ] : async function * ( ) { for await ( x of { next : function * ( x ) { } } ) ; } } ; 
[ ... 0 , ... await ] ; 
[ ... 0 , await => 0 , ] ; 
[ ... 0 , await => 0 ] ; 
[ ... await => 0 , ] ; 
[ ... await => 0 ] ; 
[ 0 , ... await => 0 ] ; 
[ 0 ] [ 0 ] ??= await ; 
[ ] = await => 0 ; 
[ ] = class { } ( ) ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { for await ( class { } ( ) . x of 0 ) ; } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { yield * class { } ( ) ; } } ; 
[ await => 0 , ... 0 , ] ; 
[ await => 0 , x ] ; 
[ await => 0 , { x } ] ; 
[ await => 0 ] ( ) ; 
[ await ] = ( ) => { } ; 
[ await ] = 0 ; 
[ await ] = Symbol ; 
[ await ] = class { } ; 
[ await ] = function ( ) { } ; 
[ await ] = function * ( ) { } ; 
[ await ] = this ; 
[ class extends true { } ] ; 
[ class { } ( ) ] ; 
[ x , await => 0 ] ; 
[ { x , } = await => 0 ] ; 
[ { x = 0 } = await => 0 ] ; 
[ { x } = await => 0 ] ; 
[ { } = await ] = [ 0 ] ; 
`${ 0 }${ x }${ await => 0 }` ; 
`` ( await => 0 ) ; 
async function * await ( ) { } await ; 
async function * await ( x , ) { } await ; 
async x => class { } ( ) ; 
await ( ) ; 
await ** 0 ; 
await ++ ; 
await . x ; 
await : 0 . x = 0 ; 
await : ; 
await : ; ( x => { x ( ) ; } ) ( ) ; 
await : ; ++ 0 . x ; 
await : ; 0 . x ++ ; 
await : ; 0 . x . x ; 
await : ; 0 . x = `` ; 
await : ; 0 . x [ 0 ] ; 
await : ; 0 instanceof 0 ; 
await : ; Array . pop ( ) ; 
await : ; BigInt ( { } ) ; 
await : ; Function . apply ( 0 , 0 ) ; 
await : ; Map ( ) ; 
await : ; Object . assign ( ) ; 
await : ; Object . fromEntries ( ) ; 
await : ; Object . getOwnPropertyDescriptor ( ) ; 
await : ; Object . getOwnPropertyNames ( ) ; 
await : ; Object . hasOwn ( ) ; 
await : ; Object . setPrototypeOf ( ) ; 
await : ; Promise ( ) ; 
await : ; Set ( ) ; 
await : ; WeakMap ( ) ; 
await : ; [ ] = 0 ; 
await : ; [ { x , } = null ] ; 
await : ; [ { x , } ] ; 
await : ; class x { [ 0 [ 0 ] = 0 ] ; } 
await : ; class x { [ x ] ; } 
await : ; class x { static 0 = new 0 ; } 
await : ; eval ( typeof 0 ) ; 
await : ; for ( x of 0 ) ; 
await : ; let [ [ ] ] = `` ; 
await : ; let [ ] = x ; 
await : ; let x ; new x ( ) ; 
await : ; new 0 ; 
await : ; new Function ( Symbol . toPrimitive ) ; 
await : ; new function ( ... x ) { x ( ) ; } ; 
await : ; new function ( x , ... [ ] ) { x ( ) ; } ; 
await : ; var x ; x ( ) ; 
await : ; x ; 
await : ; { x } ; 
await : for ( let x of 0 ) ; 
await : for ( var x of 0 ) ; 
await : throw 0 ; 
await : var [ ] = 0 ; 
await : var x ; x ( ) ; 
await ; 
await ; async function await ( ) { } 
await ; function await ( ) { } 
await ; function await ( ... [ ] ) { } 
await = 0 ( ) ; 
await = 0 . x -- ; 
await = 0 . x = 0 ; 
await = 0 [ 0 ] -- ; 
await = 0 in 0 ; 
await = 0 instanceof 0 ; 
await = Symbol . toPrimitive & 0 ; 
await = Symbol . toPrimitive < 0 ; 
await = Symbol . toPrimitive <= 0 ; 
await = [ ... 0 , ] ; 
await = [ ... 0 ] ; 
await = [ 0 , ... 0 ] ; 
await = class extends 0 { } ; 
await = new '' ( ) ; 
await = new 0 ( ) ; 
await = new 0 ; 
await = new `` ( ) ; 
await = new async function ( ) { } ( ) ; 
await = new async function * ( ) { } ( ) ; 
await = new async function * ( ... x ) { } ( ) ; 
await = new function * ( ) { } ( ) ; 
await = new this ( ) ; 
await = new true ( ) ; 
await = new { } ( ) ; 
await = { [ Symbol . toPrimitive ] : 0 } != 0 ; 
await = { [ Symbol . toPrimitive ] : `` } != 0 ; 
await => 0 , x ; 
await => 0 ; 
await => 0 ; [ ] ( ) ; 
await => 0 ; for ( var { } of 0 ) ; 
await => 0 ; new x ( ) ; function * x ( ) { } 
await => 0 ; null ( ) ; 
await => 0 ; this ( ) ; 
await => 0 ; true ( ) ; 
await => 0 ; x ; 
await => { } , 0 ( ) ; 
await `` ; 
class await { } await ; 
class x extends '' { [ x ] ; } 
class x extends ( await => 0 ) { } 
class x extends 0 ( ) [ await => 0 ] { } 
class x extends 0 ( ) `${ await => 0 }` { } 
class x extends 0 . x { [ x ] ; } 
class x extends 0 { [ x ] ; } 
class x extends Symbol . match { [ x ] ; } 
class x extends [ 0 , ... await => 0 ] { } 
class x extends [ ] { [ x ] ; } 
class x extends [ await => 0 , ] { } 
class x extends [ await => 0 ] { } 
class x extends `` { [ x ] ; } 
class x extends async function ( ) { } { [ x ] ; } 
class x extends async function * ( ) { } { [ x ] ; } 
class x extends async function * ( x ) { } { [ x ] ; } 
class x extends class { } ( ) { } 
class x extends function * ( ) { } { [ x ] ; } 
class x extends function * ( ... x ) { } { [ x ] ; } 
class x extends function * ( x ) { } { [ x ] ; } 
class x extends new 0 ( ) [ await => 0 ] { } 
class x extends this { [ x ] ; } 
class x extends true { } 
class x extends { 0 ( ) { } , } { [ x ] ; } 
class x extends { 0 ( ) { } } { [ x ] ; } 
class x extends { 0 : false } { [ x ] ; } 
class x extends { 0 : function ( x ) { } } { [ x ] ; } 
class x extends { 1 : null } { [ x ] ; } 
class x extends { async 0 ( ) { } , } { [ x ] ; } 
class x extends { get 0 ( ) { } , } { [ x ] ; } 
class x extends { set 0 ( x ) { } , } { [ x ] ; } 
class x extends { } { [ x ] ; } 
class x { * [ 0 ( ) [ await => 0 ] ] ( ) { } } 
class x { * [ await ( ) ] ( ) { } } 
class x { * [ await ] ( ) { } } 
class x { [ 0 ( ) [ 0 ] = await => 0 ] ( ) { } } 
class x { [ 0 ( ) [ 0 ] = await ] ; } 
class x { [ 0 == 0 ? 0 : await => 0 ] ; } 
class x { [ 0 ? await => 0 : 0 ] ; } 
class x { [ await ( ) ] ; } 
class x { [ await ] ( ) { } } 
class x { [ await ] ; } 
class x { [ class { } ( ) ] ; } 
class x { [ x = await => 0 ] ; } 
class x { async * [ 0 ? await : 0 ( ) ] ( ) { } } 
class x { async * [ await ( ) ] ( ) { } } 
class x { async * [ await ] ( ) { } } 
class x { get [ 0 . x = await => 0 ] ( ) { } } 
class x { get [ await ] ( ) { } } 
class x { static 0 = async function * x ( ) { } ; } 
class x { static 0 = async function * x ( x , ) { } ; } 
class x { static 0 = async function x ( ) { } ; } 
class x { static 0 = function * await ( ) { } ; } 
class x { static 0 = function * x ( ) { } ; } 
class x { static 0 = function * x ( ... x ) { } ; } 
class x { static 0 = function * x ( x , ) { } ; } 
class x { static 0 = function await ( ) { } ; } 
class x { static 0 = function x ( ) { } ; } 
class x { static 0 = function x ( ... [ ] ) { } ; } 
class x { static 0 = function x ( [ ] ) { } ; } 
class x { static [ await ] ( ) { } } 
class x { static [ await ] ; } 
class x { static { async function * x ( ) { } var x ; } } 
class x { static { async function x ( ) { } function x ( x ) { } } } 
class x { static { async function x ( ) { } var x ; } } 
class x { static { function * x ( ) { } function * x ( ) { } } } 
class x { static { function * x ( x , ) { } var x ; } } 
class x { static { function x ( ) { } async function x ( [ ] ) { } } } 
class x { static { var x ; function * x ( ) { } } } 
class x { static { var x ; function * x ( ) { } } } x ( ) ; 
class x { static { var x ; function x ( ) { } } } 
class x { static { x ( ) ; } } await : ; 
class x { } x ||= await ; 
const x = 0 ; x -- ; await : ; 
const x = 0 ; x = await => 0 ; 
const x = await ; 
delete `${ 0 }` [ await => 0 , 0 ] ; 
delete class { } ( ) ; 
do ; while ( class { } ( ) ) ; 
do await : ; while ( x ) ; 
do break ; while ( await ) ; 
do x ; while ( await => 0 ) ; 
eval ( 0 + typeof await ) ; 
eval ( 0 , ... await => 0 ) ; 
eval ( await => 0 , ... 0 ) ; 
eval ( class { } ( ) ) ; 
eval . call ( 0 , `${ { } }` ) ; await : ; 
for ( 0 ( ) . x of [ , ] ) await : ; 
for ( 0 . x in [ 0 ] ) await : ; 
for ( ; 0 ; await ) ; 
for ( ; ; await ) break ; 
for ( ; x ; ) await : ; 
for ( ; x ; await => 0 ) ; 
for ( await ( ) . x in 0 ) ; 
for ( await ( ) . x of '' ) ; 
for ( await => 0 ; x ; ) ; 
for ( await in 0 ) ; 
for ( await in 1n ) ; 
for ( await in [ 0 ] ) ; 
for ( await in null ) ; 
for ( await in x ) ; 
for ( await in { has : true } ) ; 
for ( await of '' ) ; 
for ( await of 0 ) ; 
for ( await of [ , ] ) ; 
for ( await of `` ) ; 
for ( const x = 0 ; 0 ; await ) ; 
for ( const x = 0 ; ; await ) break ; 
for ( const { ... x } = 0 ; ; await ) break ; 
for ( let [ ] = 0 ; ; ) await : ; 
for ( let [ ] = 0 ; ; ) await => 0 ; 
for ( let [ ] = 0 ; ; await ) ; 
for ( let [ ] = 0 ; await ; ) ; 
for ( let [ ] = await ; ; ) ; 
for ( let x ; 0 ; await ) ; 
for ( let x ; ; 0 . x = 0 ) await : ; 
for ( let x ; ; [ ] = 0 ) await : ; 
for ( let x ; ; [ ] = 0 ) await => 0 ; 
for ( let x ; ; await ) break ; 
for ( let x ; new 0 ; ) await : ; 
for ( let x ; new 0 ; await ) ; 
for ( let x in x ) await : ; 
for ( let x of 0 ) ; await ; 
for ( let x of 0 ) await : ; 
for ( let x of await => 0 ) ; 
for ( var [ ] = 0 ; ; ) await : ; 
for ( var [ ] = 0 ; ; await ) ; 
for ( var [ ] = 0 ; await ; ) ; 
for ( var [ ] = await => 0 ; ; ) ; 
for ( var x ; 0 ; await ) ; 
for ( var x ; ; await ) break ; 
for ( var x ; new 0 ; ) await : ; 
for ( var x ; new 0 ; await ) ; 
for ( var x of 0 ) await : ; 
for ( var x of await => 0 ) ; 
for ( var x of { x } ) await : ; 
for ( x ; ; ) await : ; 
for ( x ; ; await => 0 ) ; 
for ( x ; await => 0 ; ) ; 
for ( x in class { } ( ) ) ; 
for ( x in x ) await : ; 
for ( x of [ , ] ) await : ; 
for ( x of await ) ; 
for ( x of await => 0 ) ; 
for ( { x , } in [ await => 0 ] ) ; 
for ( { x = 0 } in [ 0 ] ) await : ; 
for ( { x = await => 0 } in [ 0 ] ) ; 
for ( { x = class extends true { } } in [ 0 ] ) ; 
for ( { x } in [ 0 ] ) await : ; 
for ( { } in [ await => 0 ] ) x ; 
function * await ( ) { } await ; 
if ( 0 ( ) ) await : ; 
if ( 0 ) ; else { class x { } } 
if ( 0 ) await : ; else throw 0 ; 
if ( 0 ) { class x { } } 
if ( 0 ) { class x { } } else ; 
if ( 1 ) ; else { class x { } } 
if ( 1 ) { class x { } } 
if ( await => 0 ) throw 0 ; 
if ( x ) ; else await : ; 
if ( x ) await : ; 
isFinite . call ( await => 0 , 1n ) ; 
let [ [ ] ] = [ ] ; await : ; 
let [ ] = 0 ; await ; 
let [ ] = 0 ? await : 0 ; 
let [ ] = [ await => 0 ] ; 
let [ ] = await ; 
let [ ] = await => 0 ; 
let [ ] = class { } ( ) ; 
let [ ] = { 0 : await => 0 , } ; 
let [ x , ] = await ; 
let [ x = await ] = Symbol ; 
let [ x = await ] = [ 0 ] ; 
let [ x ] = [ await => 0 ] ; 
let [ x ] = await ; 
let [ x ] = function * ( ) { async function * x ( ) { } yield x ; } ( ) ; 
let [ x ] = function * ( ) { async function * x ( ... x ) { } yield x ; } ( ) ; 
let [ x ] = function * ( ) { yield async function * x ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield async function x ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield class x { } ; } ( ) ; 
let [ x ] = function * ( ) { yield function * x ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield function x ( ) { } ; } ( ) ; 
let [ { } = await , ] = [ 0 ] ; 
let [ { } ] = await => 0 ; 
let x = 0 ( ) [ 0 ] = await ; 
let x = 0 ( ) [ await ] ; 
let x = await ( ) ; 
let x = await ; 
let x = await => 0 ; 
let x = await `` ; 
let x = class extends true { } ; 
let x = class { } ( ) ; 
let x = function ( ) { throw x => { } ; } ( ) [ await ] ; 
let x = function ( ) { } ( ) [ 0 ] = await => 0 ; 
let x = new 0 ( await => 0 ) ; 
let x = { } ( ) [ await ] ; 
let { ... x } = 0 ( ) [ await => 0 ] ; 
let { ... x } = await ; 
let { ... x } = await => 0 ; 
let { 0 : [ ] , } = `` ; await : ; 
let { x = 0 ( ) } = await => 0 ; 
let { x = class extends 0 { } } = await => 0 ; 
let { x = x } = await => 0 ; 
let { x } = await ; 
let { x } = await => 0 ; 
let { } = await ; 
let { } = await => 0 ; 
new ( await => 0 ) ( ) ; 
new ( await => 0 ) ; 
new 0 ( await => 0 ) ; 
new 0 >> await ; 
new 0 ? 0 : await ; 
new 0 [ 0 ? await => { } : 0 ] ( ) ; 
new AggregateError ( ) ; await : ; 
new AggregateError ( 0 , 0 , await => 0 ) ; 
new AggregateError ( await => 0 ) ; 
new AggregateError ; await : ; 
new Error ( Symbol . toPrimitive , await => 0 ) ; 
new Map ( await => 0 ) ; 
new Set ( await => 0 ) ; 
new WeakSet ( await => 0 ) ; 
new async function ( [ ] , ... x ) { } / 0 ; 
new function ( ) { return class { } ( ) ; } ; 
new function ( ... x ) { async function * x ( ) { } x ( ) ; var x ; } ; 
new function ( ... x ) { function x ( ) { } x ( ) ; for ( var x ; 0 ; ) ; } ; 
new function ( ... x ) { function x ( x ) { } for ( var x in 0 ) ; x ( ) ; } ; 
new function ( ... x ) { var x ; function x ( ) { } new x ( ) ; } ; 
new function ( ... x ) { var x ; function x ( ) { } x ( ) ; } ; 
new function ( ... x ) { var x ; x ( ) ; async function x ( ... [ ] ) { } } ; 
new function ( ... x ) { var x ; x ( ) ; function * x ( ) { } } ; 
new function ( ... x ) { var x ; x ( ) ; function x ( ) { } } ; 
new function ( ... x ) { x ( ) ; var x ; async function x ( ) { } } ; 
new null ( await => 0 , ) ; 
null . x %= await ; 
null . x = await => { } ; 
switch ( 0 ) { case 0 : await : ; default : x ; } 
switch ( 0 ) { case 0 : case await : default : } 
switch ( 0 ) { case 0 : case await : } 
switch ( 0 ) { case 0 : default : case await : new 0 ; } 
switch ( 0 ) { case 0 : default : case await : } 
switch ( 0 ) { case 0 : x ; default : case await => 0 : } 
switch ( 0 ) { case await => 0 : default : case 0 : x ; } 
switch ( 0 ) { case await => 0 : default : x ; } 
switch ( 0 ) { case class { } ( ) : default : } 
switch ( 0 ) { case x : default : case await => 0 : } 
switch ( 0 ) { default : case 0 : case await : } 
switch ( 0 ) { default : case await => 0 : x ; } 
switch ( 0 ) { default : x ; case await => 0 : } 
switch ( 0 ? await => 0 : 0 ) { case 0 : x ; default : } 
switch ( 1 ) { case await => 0 : default : case x : } 
switch ( 1 ) { default : case class { } ( ) : } 
switch ( await => 0 ) { case new 0 : } 
switch ( await => 0 ) { case x : default : } 
switch ( await => 0 ) { default : case 0 : new 0 ; } 
switch ( await => 0 ) { default : case 0 : x ; } 
switch ( await => 0 ) { default : case x : } 
switch ( await => 0 ) { default : x ; } 
switch ( class { } ( ) ) { } 
throw 0 ; await ; 
throw await => 0 ; 
throw class { } ( ) ; 
try { await ( 0 ) ; } catch { } finally { } 
try { await ; } catch { } 
try { await ; } catch { } finally { } 
try { class x extends true { } } catch ( x ) { } 
try { let [ ] = await ; } catch ( [ ] ) { } 
try { let [ ] = await ; } catch ( x ) { throw 0 ; } 
try { let [ ] = await ; } catch ( x ) { } 
try { throw await => 0 ; } catch { x ; } 
typeof await ; 
typeof class { } ( ) ; 
var [ [ ] = await ] = 0 ; 
var [ ] = 0 ; await ; 
var [ ] = await ; 
var [ ] = await => 0 ; 
var [ x , ] = await ; 
var [ x ] = await ++ ; 
var [ x ] = await ; 
var x = await ; 
var x = await => 0 ; new x ( ) ; 
var x = await => class extends 0 { } ; x ( ) ; 
var x = class extends true { } ; 
var x = class { } ( ) ; 
var { ... x } = await ; 
var { 0 : [ ] = x } = await => 0 ; 
var { 0 : { } = await } = [ 0 ] ; 
var { [ await ] : x } = 0 ; 
var { [ class { } ( ) ] : x } = 0 ; 
var { x = await } = { x : 0 , } ; 
var { x } = await ; 
var { } = new 0 ?? await ; 
while ( await => 0 ) throw 0 ; 
x ( await => 0 ) ; 
x , await ; 
x / `${ await => 0 }` ; 
x : for ( ; ; await ) break x ; 
x ; await : ; 
x ; class x { static { var x ; function * x ( ) { } } } 
x = 0 ; await : ; 
x = await => 0 ; 
x = class extends true { } ; 
x = class { } ( ) ; 
x = this . x -- ; 
x = this . x = 0 ; 
x = { [ Symbol . toPrimitive ] : 0 ?? await } <= 0 ; 
x ? 0 : await => 0 ; 
x [ await => 0 ] ; 
x in `${ await => 0 }` ; 
{ x } ; await : ; 
~ class { } ( ) ; 
