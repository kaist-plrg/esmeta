"use strict";
( async function ( [ ] ) { } ) ( ) ; 
( x => async function ( [ ] , ) { } ( ) ) ( ) ; 
0 instanceof { [ Symbol . hasInstance ] : async function ( [ ] ) { } } ; 
0 instanceof { [ Symbol . hasInstance ] : async function ( [ ] , ... x ) { } } ; 
Array . prototype . forEach . call ( [ 0 ] , async function ( [ ] ) { } ) ; 
Function . apply . call ( async function ( [ ] , ) { } ) ; 
Object . setPrototypeOf ( this , Map ) ; 
[ async function ( [ ] ) { } ( ) ] ; 
[ async function ( [ ] , ... [ ] ) { } ( ) ] ; 
[ async function ( [ x ] ) { } ( ) ] ; 
async function * await ( ) { } 
async function * x ( ) { } 
async function * x ( ... x ) { } 
async function * x ( x ) { } 
async function * x ( x , ... [ ] ) { } 
async function x ( ) { } for ( x . x of [ , ] ) ; 
async function x ( [ ] ) { } x ( ) ; 
async function x ( [ ] , ... x ) { } x ( ) ; 
class await { } 
class x { } 
const x = class { } ; 
for ( async function ( [ ] ) { } ( ) ; ; ) throw 0 ; 
for ( { x = async function * ( x ) { } } in [ 0 ] ) var x ; 
for ( { x = class { } } in [ 0 ] ) var x ; 
for ( { x = function ( ) { } } in [ 0 ] ) var x ; 
for ( { x = function * ( ) { } } in [ 0 ] ) var x ; 
function * await ( ) { } 
function * x ( ) { } 
function * x ( ... x ) { } 
function * x ( x ) { } 
function * x ( x , ... [ ] ) { } 
function await ( ) { } 
function x ( ) { } 
function x ( ... x ) { } 
function x ( [ ] ) { } 
function x ( x ) { } 
function x ( x , ... [ ] ) { } 
let [ ... x ] = [ class { } ] ; 
let [ ... x ] = [ { async * 0 ( ) { } , } ] ; 
let [ x ] = [ async function * ( ) { } ] ; 
let [ x ] = [ class { } ] ; 
let [ x ] = [ function ( ) { } ] ; 
let [ x ] = [ function * ( ) { } ] ; 
let [ x ] = function * ( ) { yield async function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield class { } ; } ( ) ; 
let [ x ] = function * ( ) { yield function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield function * ( ) { } ; } ( ) ; 
let x ; x = class { } ; 
let x ; x = function * ( ) { } ; 
let x = async function * ( ) { } ; 
let x = async function * ( ... x ) { } ; 
let x = async function * ( x , ... [ ] ) { } ; 
let x = class { } ; 
let x = function ( ) { } ; 
let x = function * ( ) { } ; 
let x = { * 0 ( ) { } , } ; 
let x = { * 0 ( ) { } } ; 
let { ... await } = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let { ... x } = { * '' ( ) { } , } ; 
let { ... x } = { * 0 ( x , ) { } } ; 
let { x , ... await } = { [ Symbol . iterator ] : async function * ( ) { } } ; 
new function ( ... x ) { return async function ( [ ] ) { } ( ) ; } ; 
this . __proto__ = ( ) => { } ; 
this . __proto__ = ( ... [ ] ) => 0 ; 
this . __proto__ = Symbol ; 
this . __proto__ = [ 0 , ] ; 
this . __proto__ = [ 0 ] ; 
this . __proto__ = [ ] ; 
this . __proto__ = async function ( ) { } ; 
this . __proto__ = async function ( ... [ ] ) { } ; 
this . __proto__ = async x => 0 ; 
this . __proto__ = function * ( ) { } ; 
this . __proto__ = null ; 
this . __proto__ = x => 0 ; 
this . __proto__ = { 0 : 0 , } ; 
this . __proto__ = { 0 : true } ; 
this . __proto__ = { add : '' } ; 
this . __proto__ = { get : 0 } ; 
this . __proto__ = { has : false } ; 
this . __proto__ = { } ; 
this . __proto__ = { } ; throw 0 ; 
this . x = async function * ( ) { } ; 
this . x = class { } ; 
this . x = function ( ) { } ; 
var x ; this . __proto__ = { x , } ; 
var x ; x = async function * ( ) { } ; 
var x ; x = class { } ; 
var x ; x = function ( ) { } ; 
var x = async function * ( ) { } ; 
var x = async function * ( x ) { } ; 
var x = class { } ; 
var x = function ( ) { } ; 
var x = function ( ... x ) { } ; 
var x = function ( x ) { } ; 
var x = function ( x , ... [ ] ) { } ; 
var x = function * ( ) { } ; 
var x = function * ( ... x ) { } ; 
var x = function * ( x ) { } ; 
var x = function * ( x , ... [ ] ) { } ; 
var x = this ; x . __proto__ = x => 0 ; 
var x = x => async function ( { } ) { } ( ) ; x ( ) ; 
var x = { * 0 ( ) { } , } ; 
var x = { * 0 ( ) { } } ; 
var x = { * 0 ( ... x ) { } } ; 
var x = { * 0 ( x ) { } } ; 
var x = { async * 0 ( ) { } } ; 
var x = { async * 0 ( ... x ) { } } ; 
var x = { async * 0 ( x ) { } } ; 
var x = { async * x ( ) { } } ; 
var x = { } ; Object . setPrototypeOf ( x , async function * ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , class { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , function ( ) { } ) ; 
var { ... x } = { * 0 ( ) { } } ; 
var { ... x } = { 0 : function ( x ) { } } ; 
var { ... x } = { [ Symbol . match ] : async function * ( x ) { } } ; 
var { ... x } = { [ Symbol . split ] : function ( x ) { } } ; 
var { ... x } = { [ Symbol . split ] : function * ( x ) { } } ; 
var { 0 : x } = { * 0 ( x ) { } } ; 
var { x , ... x } = { [ Symbol . match ] : function ( x ) { } } ; 
var { x , ... x } = { async * 0 ( ) { } } ; 
var { x , ... x } = { raw : function ( x ) { } } ; 
var { x } = { x : async function * ( ) { } , } ; 
var { x } = { x : class { } , } ; 
var { x } = { x : function ( ) { } , } ; 
var { x } = { x : function * ( ) { } , } ; 
x . x = 0 ; async function x ( ) { } 
x . x = `` ; async function x ( ) { } 
x = class { } ; for ( var x in 0 ) ; 
x = class { } ; var x ; 
x = this . x -- ; 
x = this . x = 0 ; 
~ async function ( [ ] ) { } ( ) ; 
~ async function ( [ ] ) { } ( ) ; x ; 
~ async function ( [ ] , ... x ) { } ( ) ; 
~ async function ( { x } ) { } ( ) ; 
~ async function ( { } , ... x ) { } ( ) ; 
