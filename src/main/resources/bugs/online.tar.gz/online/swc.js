! async function ( ) { } / 0 ; 
! async function * ( ) { } / 0 ; 
! function ( ... { ... x } ) { } ; 
! function * ( ... { ... x } ) { } ; 
! { 0 ( ... { ... x } ) { } } ; 
"use strict";
'' ( x => await ) ; 
( ) => await ; 
( ... x ) => await ; 
( 0 ? await => 0 : 0 ) ( ) ; 
( async function ( ... { ... x } ) { } ) ; 
( async function * ( [ ] ) { } ) ( ) ; 
( async x => 0 ) . prototype . valueOf ; 
( async x => 0 ) . x -- ; 
( await => 0 ( ) ) ( ) ; 
( await => 0 ) ( ) ( ) ; 
( await => 0 , 0 ) * 1n ; 
( await => 0 . x = 0 ) ( ) ; 
( await => 0 in 0 ) ( ) ; 
( await => [ ... 0 , ] ) ( ) ; 
( await => [ ... 0 ] ) ( ) ; 
( await => await ( ) ) ( ) ; 
( await => class extends 0 { } ) ( ) ; 
( await => class { } ( ) ) ( ) ; 
( await => function ( ) { } ( ) . x ) ( ) ; 
( await => this ( ) ) ( ) ; 
( await => x ( ) ) ( ) ; 
( await => x ) ( ) ; 
( await => { [ ... 0 ] ; } ) ( ) ; 
( await => { for ( let x of 0 ) ; } ) ( ) ; 
( await => { throw 0 ; } ) ( ) ; 
( await => { x ; } ) ( ) ; 
( function ( ) { await : ; } ( ) ) ( ) ; 
( function ( ... { ... x } ) { } ) ; 
( function * ( ... { ... x } ) { } ) ; 
( x => 0 ( ) . x = ( ... await ) => 0 ) ( ) ; 
( x => 0 ( ) [ await ] ) ( ) ; 
( x => async function * ( [ ] ) { } ( ) ) ( ) ; 
( x => function * ( ) { } ( ) ( ) [ await ] ) ( ) ; 
( x => function * ( [ ] ) { } ) ( ) ( ) ; 
( x => { await : ; new x ( ) ; } ) ( ) ; 
( x => { function * x ( ) { } new x ( ) ; } ) ( ) ; x ; 
( x => { new x ( ) ; async function * x ( ) { } } ) ( ) ; x ; 
( x => { new x ( ) ; async function x ( ) { } } ) ( ) ; x ; 
( x => { new x ( ) ; await : ; } ) ( ) ; 
( x => { var x ; x ( ) ; switch ( 0 ) { default : function x ( ) { } } } ) ( ) ; 
( x => { x ( ) ; await : ; } ) ( ) ; 
( x => { x ( ) ; await ; } ) ( ) ; 
( x => { x ( ) ; for ( var await of /a/ ) ; } ) ( ) ; 
( x => { x ( ) ; for ( var x ; ; ) { function * x ( ) { } } } ) ( ) ; 
( x => { x ( ) ; var x ; switch ( 0 ) { default : case 0 : function x ( ) { } } } ) ( ) ; 
+ 1n ; await : ; 
+ Symbol . toPrimitive ; await : ; 
+ { ... async function ( ... { ... x } ) { } } ; 
+ { ... function * ( ... { ... x } ) { } } ; 
+ { 0 : await => 0 , x } ; 
+ { set 0 ( x ) { } } ; let x ; 
++ 0 [ 0 ] ; await : ; 
++ async function ( ... { ... x } ) { } . x ; 
- Symbol . toPrimitive ; await : ; 
- await `` ; 
- class extends function * ( ) { } { } ; 
- { ... await => 0 , x } ; 
- { 0 ( [ ] = await , x ) { } } ; 
- { [ Symbol . toPrimitive ] : 0 ? await => 0 : 0 } ; 
- { [ Symbol . toPrimitive ] : async x => { ( ... { ... x } ) => 0 ; } } ; 
- { [ Symbol . toPrimitive ] : async x => { await async function * ( ... { ... x } ) { } ( ) ; } } ; 
- { [ Symbol . toPrimitive ] : async x => { await async function * ( ... { ... x } ) { } ; } } ; 
- { [ Symbol . toPrimitive ] : async x => { for await ( let x of { [ Symbol . iterator ] : async function * ( [ ] ) { } } ) ; } } ; 
- { [ Symbol . toPrimitive ] : async x => { for await ( var x of function ( { ... x } ) { } ) ; } } ; 
- { [ Symbol . toPrimitive ] : await => async x => 0 } ; 
- { [ Symbol . toPrimitive ] : await => this } ; 
- { [ Symbol . toPrimitive ] : await => x } ; 
- { [ Symbol . toPrimitive ] : await => { x ; } } ; 
- { [ x ] : await => 0 } ; 
- { [ { [ Symbol . toPrimitive ] : '' } ] : { x } } ; 
- { get 0 ( ) { var x ; } } ; let x ; 
- { set 0 ( x ) { } } ; let x ; 
- { x , } ; let x ; 
-- 0 . x ; await : ; 
0 != { [ Symbol . toPrimitive ] : function * ( ... { ... x } ) { } } ; 
0 != { [ Symbol . toPrimitive ] : x => await => 0 } ; 
0 && await ; 
0 ( ) & await ; 
0 ( ) ** 0 % await ; 
0 ( ) ** await ; 
0 ( ) . x = await ; 
0 ( ) ; await ; 
0 ( ) [ 0 ] = await ; 
0 ( ) [ await => 0 ] ; 
0 ( ) `${ await => 0 }` ; 
0 ( ... await => 0 ) ; 
0 ( ... x ) ; let x ; 
0 ( 0 ?? await , 0 ) ; 
0 ( async function ( ... { ... x } ) { } ) ; 
0 ( await => 0 ) ; 
0 ( x ) ; let x ; 
0 * async function * ( ... { ... x } ) { } . x ; 
0 ** await `` ; 
0 + { [ Symbol . toPrimitive ] : x => await => 0 } ; 
0 , 0 ( ) [ await => 0 ] ; 
0 . x &&= await ; 
0 . x ( ) ; await : ; 
0 . x ( ) [ await => 0 ] ; 
0 . x -- ; await : ; 
0 . x . x [ await => 0 ] ; 
0 . x = 0 && await ; 
0 . x = 0 ?? await ; 
0 . x = x ; let x ; 
0 . x == async function ( ... { ... x } ) { } ; 
0 . x ?. x ( ) ( ) ; 
0 . x [ x ] ; let x ; 
0 < { async * 0 ( ... { ... x } ) { } , x } ; 
0 <= Symbol . toPrimitive ; await : ; 
0 == 0 ^ 1 ? await : 0 ; 
0 == 0 ^ true ? await : 0 ; 
0 ? await : 0 ( ) ; 
0 ? await : 0 ; 
0 ? await => 0 : x ; 
0 ?? await ; 
0 [ 0 ] [ 0 ] [ await => 0 ] ; 
0 ^ 1n ? await : 0 ; 
0 ^ Symbol . toPrimitive ? await : 0 ; 
0 in await `` ; 
0 in x ; let x ; 
0 instanceof [ ] ; await : ; 
0 instanceof function ( ... { ... x } ) { } ; 
0 instanceof x ; let x ; 
1 ? 0 ( ) : await ; 
1 ? 0 : await ; 
1 ? x : await => 0 ; 
1 || await ; 
1n * `${ await => { } , 0 }` ; 
1n * { [ 0 ] : await => 0 } ; 
AggregateError ( await => 0 ) ; 
Array ( 0 ( ) , await , 0 ) ; 
Array ( 0 . x = 0 , await , 0 ) ; 
Array ( [ ... 0 , ] , await , 0 ) ; 
Array ( [ ... 0 ] , await , 0 ) ; 
Array ( async function ( ... { ... x } ) { } ) ; 
Array ( class extends 0 { } , x => await ) ; 
Array ( x => await , 0 . x = 0 ) ; 
Array . from ( ) ; await : ; 
Array . from ( 0 , 0 , x => await ) ; 
Array . from ( await => 0 , 0 ) ; 
Array . from ( { [ Symbol . iterator ] : await => 0 } ) ; 
Array . from . call ( await => 0 ) ; 
Array . from . call ( x => x => 0 , `` ) ; 
Array . prototype . concat ( function * ( ... { ... x } ) { } ) ; 
Array . prototype . every ( async function * ( ... { ... x } ) { } ) ; 
Array . prototype . every . call ( 0 , async function ( ... { ... x } ) { } ) ; 
Array . prototype . every . call ( `${ 0 }` , x => class x extends { x , } { } ) ; 
Array . prototype . filter . call ( 0 , function ( ... { ... x } ) { } ) ; 
Array . prototype . includes ( function ( ... { ... x } ) { } ) ; 
Array . prototype . lastIndexOf ( function * ( ... { ... x } ) { } ) ; 
Array . prototype . map ( function ( ... { ... x } ) { } ) ; 
BigInt ( ) ; await : ; 
BigInt . asUintN ( { [ Symbol . toPrimitive ] : await => 0 } ) ; 
BigInt . call ( await => 0 ) ; 
Function . apply . call ( ) ; await : ; 
Function . apply . call ( async function * ( [ ] ) { } ) ; 
Function . apply . call ( function * ( [ ] ) { } ) ; 
Function . call ( function * ( ... { ... x } ) { } ) ; 
Map ( async function * ( ... { ... x } ) { } ) ; 
Map ( await => 0 ) ; 
Map ( function ( ) { await : ; } ) ; 
Map ( function * ( ) { await : ; } ) ; 
Map . prototype . size ; await : ; 
Number ( { [ Symbol . toPrimitive ] : 0 ? await : 0 } ) ; 
Object ( { set 0 ( x ) { } } ) ; let x ; 
Object . create ( ) ; await : ; 
Object . create ( 0 , await => 0 ) ; 
Object . create ( await => 0 , [ 0 ] ) ; 
Object . defineProperties ( ) ; await : ; 
Object . defineProperties ( await => 0 ) ; 
Object . defineProperty ( ) ; await : ; 
Object . defineProperty ( await => 0 ) ; 
Object . entries . call ( await => 0 ) ; 
Object . fromEntries ( await => 0 ) ; 
Object . getOwnPropertyDescriptor ( await => 0 , { [ Symbol . toPrimitive ] : 0 } ) ; 
Object . getOwnPropertyDescriptor . call ( await => 0 ) ; 
Object . getOwnPropertyDescriptors ( ) ; await : ; 
Object . getOwnPropertyDescriptors . call ( await => 0 ) ; 
Object . getOwnPropertySymbols ( ) ; await : ; 
Object . getOwnPropertySymbols . call ( await => 0 ) ; 
Object . getPrototypeOf . call ( await => 0 ) ; 
Object . hasOwn . call ( await => 0 ) ; 
Object . isPrototypeOf . call ( null , await => 0 ) ; 
Object . keys . call ( await => 0 ) ; 
Object . setPrototypeOf ( await => 0 ) ; 
Object . values ( ) ; await : ; 
Object . values . call ( await => 0 ) ; 
Promise ( await => 0 ) ; 
Promise . all ( async function * ( ... { ... x } ) { } ) ; 
Promise . allSettled ( function * ( ... { ... x } ) { } ) ; 
Promise . any ( function ( ... { ... x } ) { } ) ; 
Set ( await => 0 ) ; 
String ( { [ Symbol . toPrimitive ] : 0 ?? await } ) ; 
String ( { [ null . split ] : await } ) ; 
String . prototype . normalize ( { [ Symbol . toPrimitive ] : await => 0 } ) ; 
String . raw ( await => 0 ) ; 
Symbol ( { [ Symbol . toPrimitive ] : 0 ?? await } ) ; 
Symbol . keyFor ( await => 0 ) ; 
Symbol . toPrimitive & 0 ; await : ; 
Symbol . toPrimitive + 0 ; await : ; 
Symbol . toPrimitive < 0 ; await : ; 
Symbol [ function * ( ... { ... x } ) { } . toPrimitive ] ( ) ; 
WeakMap ( await => 0 ) ; 
WeakSet ( await => 0 ) ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { class x { } yield * x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { function * x ( ) { } yield * x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { throw yield * x => 0 ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * x ; let x ; } } ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * x => 0 ; } } ; 
[ ... 0 , await => 0 , ] ; 
[ ... 0 , await => 0 ] ; 
[ ... async function ( ... { ... x } ) { } ] ; 
[ ... await => 0 , ] ; 
[ ... await => 0 ] ; 
[ ... function ( ) { await : ; } ] ; 
[ ... x ] ; let x ; 
[ 0 , ... await => 0 ] ; 
[ 0 , ] instanceof async function ( ) { } ; 
[ 0 ] [ 0 ] ??= await ; 
[ 0 ] instanceof async function ( ) { } ; 
[ ] ( x => await ) ; 
[ ] . __proto__ = function * ( ... { ... x } ) { } ; 
[ ] . toString ( async function ( ... { ... x } ) { } ) ; 
[ ] . x = async function * ( ... { ... x } ) { } ; 
[ ] = await => 0 ; 
[ ] = function ( ... { ... x } ) { } ; 
[ ] = x ; let x ; 
[ ] = { [ Symbol . iterator ] : async function ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function ( ... [ ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { for await ( 0 [ yield ] of [ ] ) var { ... x } = 0 ; } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { for await ( x of /a/ ) ; } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... [ ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... [ x ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... x ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... { 0 : x } ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... { x } ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ... { } ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( [ ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( [ x , ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( x ) { } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( x , ... [ ] ) { } } ; 
[ ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ ] = { [ Symbol . iterator ] : async x => { } } ; 
[ ] = { [ Symbol . iterator ] : function * ( ) { class x extends 0 { } } } ; 
[ ] = { [ Symbol . iterator ] : function * ( ) { for ( var x ; ; ) ; } } ; 
[ ] = { [ Symbol . iterator ] : function * ( ) { x ; } } ; 
[ ] = { [ Symbol . iterator ] : function * x ( ) { yield * x ( ) ; } } ; 
[ ] = { [ Symbol . iterator ] : x => [ 0 , ] } ; 
[ ] = { [ Symbol . iterator ] : x => [ 0 ] } ; 
[ ] = { [ Symbol . iterator ] : x => [ ] } ; 
[ ] = { [ Symbol . iterator ] : x => async function * ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : x => class { } } ; 
[ ] = { [ Symbol . iterator ] : x => function ( ) { } } ; 
[ ] = { [ Symbol . iterator ] : x => this } ; 
[ ] = { [ Symbol . iterator ] : x => x => 0 } ; 
[ ] = { [ Symbol . iterator ] : x } ; async function x ( [ ] , ) { } 
[ ] = { [ x ] : async function * ( ) { for await ( 0 [ yield ] of [ ] ) ; } } ; 
[ ] = { [ { await , } ] : async function * ( ) { for await ( 0 [ yield ] of [ ] ) ; } } ; 
[ ] = { [ { x } ] : async function * ( ) { for await ( 0 [ yield ] of [ ] ) ; } } ; 
[ ] == async function * ( ... { ... x } ) { } ; 
[ ] instanceof async function ( ) { } ; 
[ await ( 0 ) ] ; 
[ await = 0 ] = 0 ; 
[ await => 0 , ... 0 , ] ; 
[ await => 0 , x ] ; 
[ await => 0 , { x } ] ; 
[ await => 0 ] ( ) ; 
[ await `` ] ; 
[ class extends async function * ( ) { } { } ] ; 
[ function ( ... { ... x } ) { } ( ) ] ; 
[ function ( ... { ... x } ) { } ] ; 
[ function ( { } ) { } ( ) ] ; 
[ function * ( ... { ... x } ) { } ( ) ] ; 
[ x , ... 0 ] ; let x ; 
[ x , await => 0 ] ; 
[ x . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ x ] = await => 0 ; 
[ { [ Symbol . toPrimitive ] : await } ] ; 
[ { x , } . x ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
[ { x , } . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ { x , } = await => 0 ] ; 
[ { x , } ] ; let x ; 
[ { x = 0 } = await => 0 ] ; 
[ { x } . x ] = { [ Symbol . iterator ] : async x => 0 } ; 
[ { x } = await => 0 ] ; 
[ { } = null ] ; 
[ { } ] = [ null ] ; 
[ { } ] = `` ; 
`${ 0 }${ x }${ await => 0 }` ; 
`${ { [ Symbol . toPrimitive ] : function ( ... { ... x } ) { } } }` ; 
`` ( x ) ; let x ; 
`` + await `` ; 
async function * await ( ) { } 
async function * x ( ) { } 
async function * x ( ) { } [ ] = { [ Symbol . iterator ] : x } ; 
async function * x ( ) { } new x ; 
async function * x ( ... x ) { } 
async function * x ( x ) { } 
async function * x ( x , ... [ ] ) { } 
async function await ( ) { } 
async function x ( ) { } 
async function x ( ) { } new x ; 
async function x ( ... x ) { } 
async function x ( x ) { } 
async function x ( x , ... [ ] ) { } 
async x => { await async function * ( ... { ... x } ) { } ( ) ; } ; 
await ( ) ; 
await ** 0 ; 
await ++ ; 
await . x ; 
await : 0 . x = 0 ; 
await : ; 
await : ; ( x => { x ( ) ; } ) ( ) ; 
await : ; ++ 0 . x ; 
await : ; - class extends 0 { } ; 
await : ; 0 . x ++ ; 
await : ; 0 . x . x ; 
await : ; 0 . x [ 0 ] ; 
await : ; 0 instanceof 0 ; 
await : ; Array . pop ( ) ; 
await : ; BigInt ( { } ) ; 
await : ; Function . apply ( 0 , 0 ) ; 
await : ; Map ( ) ; 
await : ; Object . assign ( ) ; 
await : ; Object . fromEntries ( ) ; 
await : ; Object . getOwnPropertyDescriptor ( ) ; 
await : ; Object . getOwnPropertyNames ( ) ; 
await : ; Object . hasOwn ( ) ; 
await : ; Object . setPrototypeOf ( ) ; 
await : ; Promise ( ) ; 
await : ; Set ( ) ; 
await : ; WeakMap ( ) ; 
await : ; [ ] = 0 ; 
await : ; [ { x , } = null ] ; 
await : ; [ { x , } ] ; 
await : ; class x { [ x ] ; } 
await : ; class x { static 0 = new 0 ; } 
await : ; eval ( typeof 0 ) ; 
await : ; new 0 ; 
await : ; new Function ( Symbol . toPrimitive ) ; 
await : ; new function ( x , ... [ ] ) { x ( ) ; } ; 
await : ; var x ; x ( ) ; 
await : ; x ; 
await : ; { x } ; 
await : ; ~ class { } ( ) ; 
await : for ( let x of 0 ) ; 
await : for ( var x of 0 ) ; 
await : throw 0 ; 
await : var [ ] = 0 ; 
await : var x ; x ( ) ; 
await ; 
await ; function await ( ) { } 
await = 0 ( ) ; 
await = 0 . x -- ; 
await = 0 . x = 0 ; 
await = 0 [ 0 ] -- ; 
await = 0 in 0 ; 
await = 0 instanceof 0 ; 
await = Symbol . toPrimitive & 0 ; 
await = Symbol . toPrimitive < 0 ; 
await = Symbol . toPrimitive <= 0 ; 
await = [ ... 0 , ] ; 
await = [ ... 0 ] ; 
await = [ 0 , ... 0 ] ; 
await = class extends 0 { } ; 
await = new '' ( ) ; 
await = new 0 ( ) ; 
await = new 0 ; 
await = new `` ( ) ; 
await = new this ( ) ; 
await = new true ( ) ; 
await = new { } ( ) ; 
await = { [ Symbol . toPrimitive ] : 0 } != 0 ; 
await = { [ Symbol . toPrimitive ] : `` } != 0 ; 
await => 0 , x ; 
await => 0 ; 
await => 0 ; for ( var await of 0 ) ; 
await => 0 ; for ( var { } of 0 ) ; 
await => 0 ; x ; 
await => { } , 0 ( ) ; 
class await { } 
class await { } await ; 
class x extends ( x => 0 ) { } 
class x extends 0 ( ) [ await => 0 ] { } 
class x extends 0 ( ) `${ await => 0 }` { } 
class x extends 0 { async * [ 0 ] ( ... { ... x } ) { } } 
class x extends 0 { } await ; 
class x extends [ 0 , ... await => 0 ] { } 
class x extends [ await => 0 , ] { } 
class x extends [ await => 0 ] { } 
class x extends async function ( ) { } { } 
class x extends async function * ( ) { } { } 
class x extends await { [ 0 ( ) ] ; } 
class x extends function ( ... { ... x } ) { } { } 
class x extends function * ( ) { } { } 
class x extends new 0 ( ) [ await => 0 ] { } 
class x extends null { [ x = 0 ] ; } new x ( ) ; 
class x extends this . x { #x ( ) { } } 
class x extends x { [ 0 ( ) ] ; } 
class x extends { x , } { [ 0 ( ) ] ; } 
class x extends { x } { [ 0 ( ) ] ; } 
class x { #x ( ... { ... x } ) { } } 
class x { * 0 ( ... { ... x } ) { } } 
class x { * [ 0 ( ) [ await => 0 ] ] ( ) { } } 
class x { * [ 0 . x = x ] ( ) { } } 
class x { * [ this . x ] ( ) { } } 
class x { * [ x ] ( ) { } } 
class x { * [ { x } ] ( ) { } } 
class x { 0 ( ... { ... x } ) { } } 
class x { 0 = await ; } 
class x { [ 0 ( ) ] = await ; } 
class x { [ 0 == 0 ? 0 : await => 0 ] ; } 
class x { [ 0 ? await => 0 : 0 ] ; } 
class x { [ 0 [ 0 ] = 0 ] = await ; } 
class x { [ 0 [ { x , } ] = 0 ] ; } 
class x { [ 0 [ { x } ] = 0 ] ; } 
class x { [ [ ... 0 , ] ] ; } 
class x { [ [ ... 0 ] ] ; } 
class x { [ await ( ) ] ; } 
class x { [ await . toPrimitive ] ; } 
class x { [ await = 0 ] ; } 
class x { [ new async function ( ) { } ( ) ] ; } 
class x { [ new async function * ( ) { } ] ; } 
class x { [ new function ( ... { ... x } ) { } ( ) ] ; } 
class x { [ x ( ) ] ; } 
class x { [ x = 0 ] ; } 
class x { [ x = Symbol ] ; } 
class x { [ x = this ] ; } 
class x { [ x = x => { } ] ; } 
class x { [ x ] ( ) { } } 
class x { [ x ] ; } 
class x { [ x ] = await ; } 
class x { [ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : 0 } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : [ ] } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function ( ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function ( x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function * ( ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async function * ( x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : async x => { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : await } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : class { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : function * ( ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : function * ( ... x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : function * ( x ) { } } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : this } ] ; } 
class x { [ { [ Symbol . toPrimitive ] : { * 0 ( ) { } , } } ] ; } 
class x { [ { x , } ] ; } 
class x { [ { x } ( ) ] ; } 
class x { [ { x } . x [ 0 ] ] ; } 
class x { [ { x } ] ( ) { } } 
class x { [ { x } ] ; } 
class x { async #x ( ... { ... x } ) { } } 
class x { async * 0 ( ... { ... x } ) { } } 
class x { async * [ 0 ? await : 0 ( ) ] ( ) { } } 
class x { async * [ await ? 0 : 0 ( ) ] ( ) { } } 
class x { async * [ this ? 0 : 0 ( ) ] ( ) { } } 
class x { async * [ x ] ( ) { } } 
class x { async * [ { x } ] ( ) { } } 
class x { async 0 ( ... { ... x } ) { } } 
class x { get 0 ( ) { await : ; } } x ( ) ; 
class x { get [ this . x ] ( ) { } } 
class x { get [ x ] ( ) { } } 
class x { get [ { x } ] ( ) { } } 
class x { static #x ( ... { ... x } ) { } } 
class x { static 0 = new ( x => 0 ) ; } 
class x { static 0 = new function * ( ) { } ( ) ; } 
class x { static 0 = super . x = super . x ??= 0 ; } 
class x { static 0 = super . x = super [ 0 ] ??= 0 ; } 
class x { static 0 = super [ new super . x ( ) ] = 0 ; } 
class x { static 0 = super [ super . x [ 0 ] ] = 0 ; } 
class x { static 0 = super [ super . x ] = 0 ; } 
class x { static 0 = super [ super [ 0 ] . x ] = 0 ; } 
class x { static 0 = super [ super [ 0 ] ] = 0 ; } 
class x { static 0 = x = 0 ; } 
class x { static 0 = x => await ; } 
class x { static 0 = { x , } = 0 ; } 
class x { static 0 = { x } = 0 ; } 
class x { static [ 0 . x = { x , } ] ; } 
class x { static [ 0 . x = { x } ] ; } 
class x { static [ this . x ] ( ) { } } 
class x { static [ x ] ( ) { } } 
class x { static [ x ] ; } 
class x { static [ { x , } ] = new 0 ; } 
class x { static async #x ( ... { ... x } ) { } } 
class x { static async * #x ( ... { ... x } ) { } } 
class x { static { class x extends super [ 0 ] { } } } 
class x { static { const x = super [ 0 ] ; } } 
class x { static { new super . x ; } } 
class x { static { new super [ 0 ] ; } } 
class x { static { super . x . x ; } } 
class x { static { super . x ; } } 
class x { static { super [ 0 ] ( ) ; } } 
class x { static { super [ 0 ] ; } } 
class x { static { throw super . x ; } } 
class x { static { var x = super [ 0 ] ; } } 
class x { static { var x = super [ 1n ] ; } } 
class x { static { var x = super [ `` ] ; } } 
class x { static { var x = super [ null ] ; } } 
class x { static { var x = super [ x ] ; } } 
class x { static { var x = super [ { x } ] ; } } 
class x { static { x ( ) ; } } await : ; 
class x { } 
class x { } switch ( 0 ) { case x : let x ; default : x ( ) ; } 
class x { } x = x => 0 ; new x ( ) ; 
class x { } x ||= await ; 
const await = 0 ; 
const x = '' ; x -- ; 
const x = 0 ( ) ; x -- ; 
const x = 0 ; x -- ; 
const x = 0 ; x = '' ; 
const x = 0 ; x = 0 ; 
const x = 0 ; x = Symbol ; 
const x = 0 ; x = [ ] ; 
const x = 0 ; x = `` ; 
const x = 0 ; x = false ; 
const x = 0 ; x = function ( ) { } ; 
const x = 0 ; x = this ; 
const x = 0 ; x = true ; 
const x = 0 ; x = x ; 
const x = 0 ; x = { x , } ; 
const x = 0 ; x = { x } ; 
const x = 0 ; x = { } ; 
const x = 1n ; x -- ; 
const x = Symbol . split ; x -- ; 
const x = Symbol ; x = 0 ; 
const x = [ ] ; x -- ; 
const x = `` ; x -- ; 
const x = false ; x -- ; 
const x = function ( ) { } ; x = 0 ; 
const x = null ; x -- ; 
const x = this ; x -- ; 
const x = true ; x -- ; 
const x = x ; 
const x = { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; x -- ; 
const x = { } ; x -- ; 
const { x } = 0 ; x -- ; 
delete `${ 0 }` [ await => 0 , 0 ] ; 
delete async function ( ... { ... x } ) { } ; 
delete async function * ( ... { ... x } ) { } ; 
delete await `` ; 
delete function ( ... { ... x } ) { } ; 
delete function * ( ... { ... x } ) { } ; 
do ; while ( new async function * ( ) { } ( ) ) ; 
do ; while ( new function * ( ) { } ) ; 
do await : ; while ( x ) ; 
do break ; while ( await = 0 ) ; 
do x ; while ( await => 0 ) ; 
eval ( 0 , ... await => 0 ) ; 
eval ( await => 0 , ... 0 ) ; 
eval ( await `` ) ; 
eval ( typeof async function ( ... { ... x } ) { } ) ; 
eval ( typeof async function * ( ... { ... x } ) { } ) ; 
eval ( typeof function ( ... { ... x } ) { } ) ; 
eval ( typeof new function * ( ) { } ( ) ) ; 
eval ( typeof new function * ( ) { } ) ; 
eval . call ( 0 , `${ { } }` ) ; await : ; 
for ( '' . x in [ 0 ] ) ; 
for ( '' [ 0 ] in [ 0 ] ) ; 
for ( 0 ( ) . x in [ 0 ] ) ; 
for ( 0 ( ) . x of [ , ] ) await : ; 
for ( 0 ( ) [ 0 ] in [ 0 ] ) ; 
for ( 0 . x in [ 0 ] ) ; 
for ( 0 . x in { has : this } ) ; 
for ( 0 . x of [ , ] ) for ( var { x , ... x } in 0 ) ; 
for ( 0 [ 0 ] in [ 0 ] ) ; 
for ( 1n . x in [ 0 ] ) ; 
for ( ; ; await . x ) break ; 
for ( ; new async function ( x , ) { } ( ) ; ) ; 
for ( ; new function * ( ) { } ; ) ; 
for ( ; x ; ) await : ; 
for ( ; x ; await => 0 ) ; 
for ( [ 0 , ] . x in [ 0 ] ) ; 
for ( [ 0 , ] [ 0 ] in [ 0 ] ) ; 
for ( [ 0 ] . x in [ 0 ] ) ; 
for ( [ ] in [ 0 ] ) ; 
for ( `` . x in [ 0 ] ) ; 
for ( `` [ 0 ] in [ 0 ] ) ; 
for ( async function ( ) { } . x in [ 0 ] ) ; 
for ( async function ( ) { } [ 0 ] in [ 0 ] ) ; 
for ( async function * ( ) { } [ 0 ] in [ 0 ] ) ; 
for ( async function * ( ... { ... x } ) { } ; ; ) break ; 
for ( await ( ) . x of '' ) ; 
for ( await => 0 ; x ; ) ; 
for ( await in 0 ) ; 
for ( await in 1n ) ; 
for ( await in [ 0 ] ) ; 
for ( await in null ) ; 
for ( await in x ) ; 
for ( await of '' ) ; 
for ( await of 0 ) ; 
for ( await of [ , ] ) ; 
for ( await of `` ) ; 
for ( class { } . x in [ 0 ] ) ; 
for ( const [ ... x ] = 0n ; ; ) ; 
for ( const [ ... x ] = Symbol ; ; ) ; 
for ( const [ ... x ] = this ; ; ) ; 
for ( const [ ] = [ ] ; `` ; ) ; 
for ( const x = 0 ; ; ) break ; let x ; 
for ( const x = x ; 0 ; ) ; 
for ( const x = x ; ; ) break ; 
for ( const x in [ 0 ] ) ; let x ; 
for ( const { x , } = x ; ; ) ; 
for ( const { } = x ; 0 ; ) ; 
for ( function ( ) { } ( ) . x in [ 0 ] ) ; 
for ( function ( ) { } . x in [ 0 ] ) ; 
for ( function ( ) { } [ 0 ] in [ 0 ] ) ; 
for ( function * ( ) { } ( ) . x in [ 0 ] ) ; 
for ( function * ( ) { } . x in [ 0 ] ) ; 
for ( let [ ... x ] = 0 ; ; ) ; 
for ( let [ ] = 0 ; ; ) await : ; 
for ( let [ ] = 0 ; ; ) await => 0 ; 
for ( let [ ] = 0 ; ; await , 0 ) ; 
for ( let [ ] = [ ] ; 0 ; ) ; 
for ( let [ ] = [ ] ; ; 0 ( ) ) ; 
for ( let [ ] = await ; ; ) ; 
for ( let x ; ; 0 . x = 0 ) await : ; 
for ( let x ; ; [ ] = 0 ) await : ; 
for ( let x ; ; [ ] = 0 ) await => 0 ; 
for ( let x ; ; await `` ) break ; 
for ( let x ; new 0 ; ) await : ; 
for ( let x ; new async function * ( x ) { } ( ) ; ) ; 
for ( let x ; new function * ( ) { } ; ) ; 
for ( let x ; { } = x ; ) ; 
for ( let x in 0 ) ; let x = 0 ; 
for ( let x in [ 0 ] ) ; let x ; 
for ( let x in function * ( ... { ... x } ) { } ) ; 
for ( let x in x ) ; 
for ( let x in x ) await : ; 
for ( let x in x ** 0 ) ; 
for ( let x in { x , } ) ; 
for ( let x in { x , } ** 0 ) ; 
for ( let x in { x } ) ; 
for ( let x in { x } ** 0 ) ; 
for ( let x of 0 ) ; await ; 
for ( let x of 0 ) await : ; 
for ( let x of Symbol ) ; await : ; 
for ( let x of await => 0 ) ; 
for ( let x of function ( { ... x } ) { } ) ; 
for ( let x of x ) ; 
for ( let x of { x , } ) ; 
for ( let x of { x } ) ; 
for ( let { } in function ( ... { ... x } ) { } ) ; 
for ( null . x in [ 0 ] ) ; 
for ( this . x in [ 0 ] ) ; 
for ( true . x in [ 0 ] ) ; 
for ( var [ ... x ] = 0 ; ; ) ; 
for ( var [ ] = 0 ; ; ) await : ; 
for ( var [ ] = 0 ; ; await , 0 ) ; 
for ( var [ ] = 0 ; await ; ) ; 
for ( var [ ] = [ ] ; 0 ; ) ; 
for ( var [ ] in 0 ) for ( var [ x , ] in 0 ) ; 
for ( var await = 0 ; 0 ; ) ; 
for ( var await = 0 ; ; ) break ; 
for ( var x ; new 0 ; ) await : ; 
for ( var x ; new 0 ; await => 0 ) ; 
for ( var x ; new function * ( ) { } ; ) ; 
for ( var x = x => 0 ; 0 ; ) ; 
for ( var x = x => 0 ; ; ) break ; 
for ( var x in 0 ) ; x = x => 0 ; 
for ( var x in async function ( ... { ... x } ) { } ) ; 
for ( var x in async function * ( ... { ... x } ) { } ) ; 
for ( var x in function * ( { ... x } , ... [ ] ) { } ) ; 
for ( var x in { set 0 ( x ) { } } ) ; 
for ( var x in { x } ) for ( var { x } in 0 ) ; 
for ( var x of 0 ) await : ; 
for ( var x of [ x => 0 , ] ) ; 
for ( var x of async function ( ... { ... x } ) { } ) ; 
for ( var x of await => 0 ) ; 
for ( var x of { set x ( { ... x } ) { } } ) ; 
for ( var x of { x } ) await : ; 
for ( var { ... await } = 0 ; ; ) break ; 
for ( x . x of [ , ] ) ; let x ; 
for ( x . x of [ , ] ) var { x , ... x } = 0 ; 
for ( x ; ; ) ; let x ; 
for ( x ; ; ) await : ; 
for ( x ; ; await => 0 ) ; 
for ( x ; await => 0 ; ) ; 
for ( x in 0 ) for ( let [ ] in 0 ) ; 
for ( x in 0 ) for ( var [ x ] in 0 ) ; 
for ( x in [ 0 ] ) ; const x = 0 ; 
for ( x in [ 0 ] ) ; let x ; 
for ( x in async function ( ... { ... x } ) { } ) ; 
for ( x in async function * ( ) { } ( ) ) ; 
for ( x in async function * ( { ... x } , ) { } ) ; 
for ( x in await `` ) ; 
for ( x in function ( { ... x } ) { } ) ; 
for ( x in function * ( ... { ... x } ) { } ) ; 
for ( x in new function * ( ) { } ( ) ) ; 
for ( x in new function * ( ) { } ) ; 
for ( x in x ) await : ; 
for ( x of [ , ] ) ; let x ; 
for ( x of [ , ] ) await : ; 
for ( x of [ , ] ) await `` ; 
for ( x of [ , ] ) var { ... await } = 0 ; 
for ( x of async function ( { ... x } ) { } ) ; 
for ( x of await => 0 ) ; 
for ( x of function ( { ... x } ) { } ) ; 
for ( { x , } in [ 0 ] ) for ( var [ x , ] of 0 ) ; 
for ( { x , } in [ 0 ] ) var x ; 
for ( { x , } in [ await => 0 ] ) ; 
for ( { x = 0 ( ) } in [ 0 ] ) ; 
for ( { x = 0 } in [ 0 ] ) for ( var x in 0 ) ; 
for ( { x = 0 } in [ 0 ] ) var x , [ ] = 0 ; 
for ( { x = 0 } in [ 0 ] ) var x ; 
for ( { x = [ ... 0 ] } in [ 0 ] ) ; 
for ( { x = async function * ( x ) { } } in [ 0 ] ) var x ; 
for ( { x = await => 0 } in [ 0 ] ) ; 
for ( { x = class extends '' { } } in [ 0 ] ) ; 
for ( { x = class extends 0 { } } in [ 0 ] ) ; 
for ( { x = class extends `` { } } in [ 0 ] ) ; 
for ( { x = class extends false { } } in [ 0 ] ) ; 
for ( { x = class extends this { } } in [ 0 ] ) ; 
for ( { x = class extends true { } } in [ 0 ] ) ; 
for ( { x = class extends { index : null } { } } in [ 0 ] ) ; 
for ( { x = class { } } in [ 0 ] ) var x ; 
for ( { x = function * ( ) { } } in [ 0 ] ) var x ; 
for ( { x = this } in [ 0 ] ) var x ; 
for ( { x = true } in [ 0 ] ) var x ; 
for ( { x = x } in [ 0 ] ) var x ; 
for ( { x } in [ 0 ] ) await : ; 
for ( { x } in [ 0 ] ) var x ; 
for ( { } in 0 ) for ( var { x } in 0 ) ; 
for ( { } in [ '' ] ) ; 
for ( { } in [ 0 , ] ) ; 
for ( { } in [ 0 ] ) 0 ( ) ; 
for ( { } in [ 0 ] ) 0 . x . x ; 
for ( { } in [ 0 ] ) 0 in 0 ; 
for ( { } in [ 0 ] ) ; 
for ( { } in [ 0 ] ) ; throw 0 ; 
for ( { } in [ 0 ] ) for ( let x of 0 ) ; 
for ( { } in [ 0 ] ) for ( var [ ] = 0 ; ; ) ; 
for ( { } in [ 0 ] ) for ( var x of 0 ) ; 
for ( { } in [ 0 ] ) new null ; 
for ( { } in [ 0 ] ) new this ; 
for ( { } in [ 0 ] ) throw 0 ; 
for ( { } in [ 0 ] ) var [ ] = 0 ; 
for ( { } in [ Symbol ] ) ; 
for ( { } in [ [ ] ] ) ; 
for ( { } in [ `` ] ) ; 
for ( { } in [ await => 0 ] ) x ; 
for ( { } in [ false ] ) ; 
for ( { } in [ new async function ( ) { } ] ) ; 
for ( { } in [ this ] ) ; 
for ( { } in [ true ] ) ; 
for ( { } in [ { } ] ) ; 
for ( { } in { 0 : 0 , } ) ; 
for ( { } in { 0 : 0 } ) ; 
for ( { } in { 0 : true } ) ; 
for ( { } in { 1 : '' } ) ; 
for ( { } in { 1 : false } ) ; 
for ( { } in { 1 : null } ) ; 
for ( { } in { get : 0 } ) ; 
for ( { } of [ , ] ) ; 
function * await ( ) { } 
function * x ( ) { } 
function * x ( ) { } new x ; 
function * x ( ... x ) { } 
function * x ( [ ] ) { } 
function * x ( [ ] ) { } x ( ) ; 
function * x ( x ) { } 
function * x ( x , ... [ ] ) { } 
function * x ( { x , } ) { } x ( ) ; 
function * x ( { } ) { } x ( ) ; 
function await ( ) { } 
function await ( ) { } ; 
function await ( ... x ) { } 
function await ( [ ] , ... x ) { } 
function await ( x ) { } 
function x ( [ ] = await , x ) { } 
function x ( [ ] = await => { } , ) { } 
if ( 0 ( ) ) await : ; 
if ( 0 ) await : ; else throw 0 ; 
if ( 0 ) for ( var x ; ; ) ; else ; x = x => 0 ; 
if ( async function ( ... { ... x } ) { } ) ; else ; 
if ( await => 0 ) throw 0 ; 
if ( x ) ; else await : ; 
if ( x ) await : ; 
isFinite . call ( await => 0 , 1n ) ; 
let [ , [ ] ] = [ 0 , , ] ; 
let [ , { } ] = [ 0 ] ; 
let [ ... [ x , ] ] = 0 ; 
let [ ... await ] = 0 ; 
let [ ... await ] = `` ; 
let [ ... x ] = 0 ; 
let [ ... x ] = Symbol ; 
let [ ... x ] = [ , 0 , ] ; 
let [ ... x ] = [ , 0 ] ; 
let [ ... x ] = [ , ] ; 
let [ ... x ] = [ 0 , , 0 ] ; 
let [ ... x ] = [ 0 , , ] ; 
let [ ... x ] = [ function await ( ) { } ] ; 
let [ ... x ] = [ { async * 0 ( ) { } , } ] ; 
let [ ... x ] = async function ( ) { } ; 
let [ ... x ] = async function * ( ) { } ; 
let [ ... x ] = async x => { } ; 
let [ ... x ] = class { } ; 
let [ ... x ] = false ; 
let [ ... x ] = function ( ) { } ; 
let [ ... x ] = function * ( ) { } ; 
let [ ... x ] = this ; 
let [ ... x ] = true ; 
let [ ... x ] = { 1 : '' } ; 
let [ ... x ] = { [ Symbol . iterator ] : { x , } } ; 
let [ ... x ] = { [ Symbol . iterator ] : { x } } ; 
let [ ... x ] = { } ; 
let [ ... { ... x } ] = [ 0 ] ; 
let [ ... { ... x } ] = `` ; 
let [ ... { 0 : [ ] , ... x } ] = 0 ; 
let [ ... { await , ... x } ] = `` ; 
let [ ... { } ] = 0 ; 
let [ [ ] , ... x ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let [ [ ] , x ] = [ , , ] ; 
let [ [ ] ] = [ , ] ; 
let [ [ x , ... [ ] ] ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let [ [ x , ] ] = [ , ] ; 
let [ [ x ] ] = [ , ] ; 
let [ [ { ... x } = 0 , ] = function * ( ) { } ( ) ] = `` ; 
let [ ] = [ ] ; 
let [ ] = await ; 
let [ ] = await => 0 ; 
let [ ] = function * ( ) { let [ ] = 0 ; } ( ) ; 
let [ ] = function * ( ) { x ; } ( ) ; 
let [ ] = function * ( x , ) { x ( ) ; } ( ) ; 
let [ ] = new function * ( ) { } ( ) ; 
let [ ] = new function * ( ) { } ; 
let [ ] = x , x ; 
let [ ] = { 0 : await => 0 , } ; 
let [ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
let [ ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let [ ] = { [ Symbol . iterator ] : async function * ( [ ] ) { } } ; 
let [ ] = { x } , x ; 
let [ x , ... [ ] ] = 0 ; 
let [ x , ... await ] = `` ; 
let [ x , ] = x ; 
let [ x = await => 0 ] = Symbol ; 
let [ x = function ( ) { } ] = [ ] ; 
let [ x = function ( ) { } ] = `` ; 
let [ x ] = [ async function ( ) { } ] ; 
let [ x ] = [ async function * ( ) { } ] ; 
let [ x ] = [ async x => 0 ] ; 
let [ x ] = [ class { } ] ; 
let [ x ] = [ function * ( ) { } ] ; 
let [ x ] = [ x => 0 , ] ; 
let [ x ] = [ x => 0 ] ; 
let [ x ] = [ x ] ; 
let [ x ] = [ { x } ] ; 
let [ x ] = function * ( ) { do ; while ( { x , } ) ; } ( ) ; 
let [ x ] = function * ( ) { do ; while ( { x } ) ; } ( ) ; 
let [ x ] = function * ( ) { throw ( ... await ) => 0 ; } ( ) ; 
let [ x ] = function * ( ) { throw x ; } ( ) ; 
let [ x ] = function * ( ) { throw { x , } ; } ( ) ; 
let [ x ] = function * ( ) { throw { x } ; } ( ) ; 
let [ x ] = function * ( ) { x ; } ( ) ; 
let [ x ] = function * ( ) { yield * Symbol ; } ( ) ; 
let [ x ] = function * ( ) { yield * [ , ] ; x ( ) ; } ( ) ; 
let [ x ] = function * ( ) { yield * async function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * async function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * async x => 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield * class { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield * x => 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield * { length : 0 } ; } ( ) ; 
let [ x ] = function * ( ) { yield [ , ] ; } ( ) ; 
let [ x ] = function * ( ) { yield [ 0 , , 0 ] ; } ( ) ; 
let [ x ] = function * ( ) { yield [ 0 , , ] ; } ( ) ; 
let [ x ] = function * ( ) { yield async function ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield async function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield async x => 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield class { } ; } ( ) ; 
let [ x ] = function * ( ) { yield function * ( ) { } ; } ( ) ; 
let [ x ] = function * ( ) { yield x => 0 ; } ( ) ; 
let [ x ] = function * ( ) { yield { [ Symbol . species ] : function ( x ) { } } ; } ( ) ; 
let [ x ] = function * ( ) { yield { x , } ; } ( ) ; 
let [ x ] = function * ( ) { { x } ; } ( ) ; 
let [ x ] = x ; 
let [ x ] = { x , } ; 
let [ x ] = { x } ; 
let [ { ... await } ] = `` ; 
let [ { ... x } ] = `` ; 
let [ { 0 : x } ] = [ , ] ; 
let [ { await } ] = [ , ] ; 
let [ { x } ] = [ , ] ; 
let [ { } , ] = '' ; 
let [ { } , ] = [ ] ; 
let [ { } = await , ] = [ 0 ] ; 
let [ { } ] = `` ; 
let [ { } ] = { [ Symbol . iterator ] : async function * ( ) { } } ; 
let await ; 
let x ; [ { set 0 ( x ) { } } ] ; 
let x ; [ { x = function ( ) { } } = 0 ] ; 
let x ; for ( { x , } in [ 0 ] ) ; 
let x ; for ( { x , } in [ 0 ] ) ; x ( ) ; 
let x ; for ( { x , } in [ x ] ) ; 
let x ; for ( { x = 0 } in [ 0 ] ) ; 
let x ; for ( { x } in [ 0 ] ) ; 
let x ; switch ( 0 ) { case 0 : default : x ; case 0 : let x ; } 
let x ; var { } = x ; 
let x ; x = function * ( ) { } ; 
let x ; x = x => 0 ; 
let x ; ~ { set 0 ( x ) { } } ; 
let x = 0 ( ) [ 0 ] = await ; 
let x = 0 ( ) [ await => 0 ] ; 
let x = async function ( ) { } ; 
let x = async function * ( ) { } ; 
let x = async function * ( [ ] ) { } ( ) ; 
let x = async x => 0 ; 
let x = await ( ) ; 
let x = await ; 
let x = await `` ; 
let x = class extends x { } ; 
let x = class extends { x , } { } ; 
let x = class extends { x } { } ; 
let x = class { } ; 
let x = function ( ) { } ( ) [ 0 ] = await => 0 ; 
let x = function ( ) { } ( ) [ 0 ] = x ; 
let x = function ( ) { } ( ) [ 0 ] = { x } ; 
let x = function ( ) { } ( ) [ x ] ; 
let x = function ( ) { } ( ) [ { x , } ] ; 
let x = function ( ) { } ( ) [ { x } ] ; 
let x = function ( ... x ) { } ( ) [ x ] ; 
let x = function * ( ) { } ; 
let x = function await ( ) { } ; 
let x = function await ( ... x ) { } ; 
let x = function await ( x , ) { } ; 
let x = new 0 ( await => 0 ) ; 
let x = new function * ( ) { } ( ) ; 
let x = new function * ( ) { } ; 
let x = new x ( ) ; 
let x = new x ; 
let x = new { x , } ( ) ; 
let x = new { x , } ; 
let x = new { x } ( ) ; 
let x = new { x } ; 
let x = x ( ) ; 
let x = x . x ; 
let x = x ; 
let x = x ; x ( ) ; 
let x = x => 0 ; 
let x = x => 0 ; new x ( ) ; 
let x = { 0 ( ) { } , } ; 
let x = { 0 ( ) { } } ; 
let x = { [ 0 ] ( ) { } } ; 
let x = { async '' ( ) { } , } ; 
let x = { x , } ( ) ; 
let x = { x , } ; 
let x = { x } ( ) ; 
let x = { x } ; 
let { ... await } = 0 ; 
let { ... x } = 0 ( ) [ await => 0 ] ; 
let { ... x } = 0 . x ; 
let { ... x } = 0 [ 0 ] ; 
let { ... x } = [ x => 0 , ] ; 
let { ... x } = async function * ( ) { } . x ; 
let { ... x } = null ; 
let { ... x } = x ; 
let { ... x } = { * '' ( ) { } , } ; 
let { 0 : [ ... x ] } = [ 0 ] ; 
let { 0 : x , ... await } = function * ( ) { } ; 
let { 0 : { } } = 0 ; 
let { 0n : [ ] } = `` ; 
let { x , ... await } = 0 ; 
let { x , } = x = 0 ; 
let { x : { } , } = 0 ; 
let { x = 0 ( ) } = await => 0 ; 
let { x = 0 ( ) } = { x } ; 
let { x = class extends 0 { } } = await => 0 ; 
let { x = function ( ) { } } = 0 ; 
let { x = x } = await => 0 ; 
let { x } = await => 0 ; 
let { x } = x ; 
let { x } = { x , } = 0 ; 
let { } = await => 0 ; 
let { } = x ; 
new ( async x => 0 ) ; 
new ( x => 0 ) ( ) ; 
new ( x => 0 ) ; 
new 0 ( await => 0 ) ; 
new 0 ( x ) ; let x ; 
new 0 >> await ; 
new 0 ? 0 : await ; 
new 0 [ 0 ? await => { } : 0 ] ( ) ; 
new AggregateError ( ) ; await : ; 
new AggregateError ( 0 , 0 , await => 0 ) ; 
new AggregateError ( await => 0 ) ; 
new AggregateError ; await : ; 
new Error ( Symbol . toPrimitive , await => 0 ) ; 
new Map ( await => 0 ) ; 
new Promise ( function ( ... { ... x } ) { } ) ; 
new Set ( await => 0 ) ; 
new WeakSet ( await => 0 ) ; 
new async function ( ) { } ( ) ; 
new async function ( ) { } / 1n ; 
new async function ( ) { } ; 
new async function ( ... x ) { } ; 
new async function ( x ) { } ; 
new async function ( x , ... [ ] ) { } ; 
new async function * ( ) { } ( ) ; 
new async function * ( ) { } ; 
new async function * ( ... x ) { } ; 
new async function * ( x ) { } ; 
new async function * ( x , ... [ ] ) { } ; 
new function ( ... [ x = x , ] ) { } ; 
new function ( ... [ x = { x } , ] ) { } ; 
new function ( ... [ { ... x } , ] ) { } ; 
new function ( ... x ) { async function x ( ) { } x ( ) ; throw 0 ; } ; 
new function ( ... x ) { async function x ( ) { } x ( ) ; } ; 
new function ( ... x ) { if ( 0 ) await ; else ; x ( ) ; } ; 
new function ( ... x ) { switch ( 0 ) { case 0 : async function * x ( x , ) { } default : } function x ( ) { } } ; 
new function ( ... x ) { switch ( 0 ) { case 0 : async function x ( ) { } default : } x ( ) ; var x ; } ; 
new function ( ... x ) { x ( ) ; async function x ( ) { } } ; 
new function ( ... x ) { x ( ) ; async function x ( ... x ) { } } ; 
new function ( ... x ) { x ( ) ; return function ( ... { ... x } ) { } ; } ; 
new function ( ... { ... x } ) { } ; 
new function ( ... { 0n : [ ] } ) { } ; 
new function ( ... { await , ... x } ) { } ; 
new function ( [ ... x ] = 0 ) { } ; 
new function ( [ [ ] , ... x ] = 0 , ) { } ; 
new function ( [ ] = await => 0 ) { } ; 
new function ( [ x = await , ] , ) { } ; 
new function ( await , x = await , ) { } ; 
new function ( x ) { ( ... await ) => 0 ; } ; 
new function ( x ) { await : ; x ( ) ; } ; 
new function ( x ) { for ( ; 0 ; await ) ; x ( ) ; } ; 
new function ( x ) { for ( var x ; 0 ; await ) ; x ( ) ; } ; 
new function ( x ) { switch ( 0 ) { case 0 : case await : } x ( ) ; } ; 
new function ( x ) { switch ( 0 ) { case 0 : default : case await : } x ( ) ; } ; 
new function ( x ) { switch ( 0 ) { case 0 : x ; default : let x ; } } ; 
new function ( x ) { switch ( 0 ) { case 0 ?? 0 : default : } x ( ) ; } ; 
new function ( x ) { switch ( 0 ) { case 0 ?? 0 : } x ( ) ; } ; 
new function ( x ) { switch ( 0 ) { default : case 0 ?? 0 : } x ( ) ; } ; 
new function ( x = await , ) { } ( 0 ) ; 
new function ( x = x ) { } ; 
new function ( x = x , ... [ ] ) { } ; 
new function ( x = { x , } ) { } ; 
new function ( x = { x } ) { } ; 
new function ( x = { x } , ... [ ] ) { } ; 
new function ( { ... x } ) { } ; 
new function ( { ... x } , ... [ ] ) { } ; 
new function ( { 1n : x } ) { } ; 
new function ( { [ x ] : x } ) { } ; 
new function ( { } ) { } ( ) ; 
new function ( { } ) { } ; 
new function ( { } , ... [ ] ) { } ; 
new function ( { } , ... x ) { } ; 
new function * ( ) { } ( ) ; 
new function * ( ) { } ; 
new function * ( ... x ) { } ; 
new function * ( x ) { } ; 
new function * ( x , ... [ ] ) { } ; 
new null ( await => 0 , ) ; 
new x ( ) ; for ( var x ; ; ) ; function * x ( ) { } 
new x ( ) ; let x ; 
new x ( ) ; var { } = x ; 
new x ; function * x ( ) { } 
new x ; let x ; 
new { x } ( ) ; let x ; 
new { x } ; let x ; 
null ( ... x ) ; 
null ( 0 , ... x ) ; 
null ( x , ... 0 ) ; 
null . x %= await ; 
null . x = await => { } ; 
switch ( 0 ) { case 0 , 0 ?? 0 : default : } 
switch ( 0 ) { case 0 . x ??= 0 : default : } 
switch ( 0 ) { case 0 . x ??= 0 : } 
switch ( 0 ) { case 0 : async function * x ( ) { } case 0 : new x ( ) ; } 
switch ( 0 ) { case 0 : async function * x ( ) { } } let x ; 
switch ( 0 ) { case 0 : async function x ( ) { } } let x ; 
switch ( 0 ) { case 0 : await : ; default : x ; } 
switch ( 0 ) { case 0 : case await : default : } 
switch ( 0 ) { case 0 : case await : } 
switch ( 0 ) { case 0 : class x { } } let x ; 
switch ( 0 ) { case 0 : default : case await : new 0 ; } 
switch ( 0 ) { case 0 : default : case await : } 
switch ( 0 ) { case 0 : function * x ( ) { } } let x ; 
switch ( 0 ) { case 0 : function x ( ) { } } var x ; 
switch ( 0 ) { case 0 : let x ; } const x = 0 ; 
switch ( 0 ) { case 0 : throw 0 ; default : await : ; } 
switch ( 0 ) { case 0 : x ; async function x ( ) { } } function x ( ) { } 
switch ( 0 ) { case 0 : x ; default : case 0 : function x ( ) { } new 0 ; } 
switch ( 0 ) { case 0 : x ; default : case await => 0 : } 
switch ( 0 ) { case 0 : x ; default : class await extends 0 { } case 0 : async function x ( ) { } } 
switch ( 0 ) { case 0 : x ; default : function * x ( [ ] ) { } x ( ) ; } 
switch ( 0 ) { case 0 : x ; default : function x ( ) { } } 
switch ( 0 ) { case 0 : x ; default : throw 0 ; } let x ; 
switch ( 0 ) { case 0 : x ; default : throw function ( ) { } ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : x ; default : throw this ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : x ; let x ; default : x ( ) ; } 
switch ( 0 ) { case 0 ?? 0 : default : case 0 : new 0 ; } 
switch ( 0 ) { case 0 ?? 0 : default : throw 0 ; } 
switch ( 0 ) { case 0 ?? 0 : default : } 
switch ( 0 ) { case 0 ?? 0 : } 
switch ( 0 ) { case 0 ?? 0 ? 0 : 0 ( ) : default : } 
switch ( 0 ) { case 0 [ 0 ?? 0 ] = 0 : default : } 
switch ( 0 ) { case 1 : let x ; default : case 0 : x ; } 
switch ( 0 ) { case async function ( ... { ... x } ) { } : default : } 
switch ( 0 ) { case async function ( ... { ... x } ) { } : } 
switch ( 0 ) { case await => 0 : default : x ; } 
switch ( 0 ) { case await `` : default : } 
switch ( 0 ) { case class { } [ 0 ] ??= 0 : default : } 
switch ( 0 ) { case function ( ... { ... x } ) { } : default : case 0 : x ; } 
switch ( 0 ) { case function * ( ... { ... x } ) { } : default : } 
switch ( 0 ) { case new function * ( ) { } : default : case 0 : x ; } 
switch ( 0 ) { case x : default : case 0 : function x ( ) { } } 
switch ( 0 ) { case x : default : case await => 0 : } 
switch ( 0 ) { case x : function * x ( ) { } default : } 
switch ( 0 ) { default : async function * x ( ) { } } let x ; 
switch ( 0 ) { default : async function x ( ) { } } let x ; 
switch ( 0 ) { default : case 0 , 0 ?? 0 : } 
switch ( 0 ) { default : case 0 . x ??= 0 : } 
switch ( 0 ) { default : case 0 : case await : } 
switch ( 0 ) { default : case 0 : x ; case 0 : function * x ( ) { } } 
switch ( 0 ) { default : case 0 ?? 0 : } 
switch ( 0 ) { default : case async function ( ... { ... x } ) { } : } 
switch ( 0 ) { default : case await => 0 : x ; } 
switch ( 0 ) { default : case new 0 ( ... 0 ?? 0 , ) : } 
switch ( 0 ) { default : case x : async function * x ( ) { } } 
switch ( 0 ) { default : class x { } } let x ; 
switch ( 0 ) { default : function * x ( ) { } } let x ; 
switch ( 0 ) { default : function x ( ) { } case 0 : x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : new x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : x ; throw 0 ; } 
switch ( 0 ) { default : let x ; case 0 : x ; } 
switch ( 0 ) { default : let x ; case x : } 
switch ( 0 ) { default : let x ; case x : } throw 0 ; 
switch ( 0 ) { default : x ; case 1 : function * x ( ) { } } 
switch ( 0 ) { default : x ; case 1 : throw 0 ; } let x ; 
switch ( 0 ) { default : x ; case await => 0 : } 
switch ( 0 ) { default : x ; case function * ( ... { ... x } ) { } : } 
switch ( 0 ) { default : x ; let x ; case 1 : x ( ) ; } 
switch ( 0 ) { default : x ; throw 0 ; case 1 : function x ( x , ) { } } 
switch ( 0 ? await => 0 : 0 ) { case 0 : x ; default : } 
switch ( 1 ) { case 0 : let x ; default : case 0 : new x ( ) ; } 
switch ( 1 ) { case 0 : let x ; default : x ( ) ; } 
switch ( 1 ) { case 0 ?? 0 : default : } 
switch ( 1 ) { case 0 ?? 0 : } 
switch ( 1 ) { case await => 0 : default : case x : } 
switch ( 1 ) { default : case 0 ?? 0 : } 
switch ( 1 ) { default : case new async function ( ) { } : x ; } 
switch ( 1 ) { default : function x ( ) { } } let x ; 
switch ( async function ( ... { ... x } ) { } ) { } 
switch ( async function * ( ... { ... x } ) { } ) { } 
switch ( await => 0 ) { case new 0 : } 
switch ( await => 0 ) { case x : default : } 
switch ( await => 0 ) { default : case 0 : x ; } 
switch ( await => 0 ) { default : case x : } 
switch ( await => 0 ) { default : x ; } 
switch ( function ( ... { ... x } ) { } ) { default : } 
switch ( function ( ... { ... x } ) { } ) { } 
switch ( function * ( ... { ... x } ) { } ) { default : x ; } 
this ( x => await ) ; 
this . x = async function ( ) { } ; 
this . x = async function * ( ) { } ; 
this . x = async x => 0 ; 
this . x = class { } ; 
this . x = function * ( ) { } ; 
this . x = x => 0 ; 
this [ 0 ] = x => 0 ; 
this instanceof async function ( ) { } ; 
throw 0 ; await ; 
throw async function * ( [ x ] ) { } ( ) ; 
throw await => 0 ; 
throw x ; let x ; 
true ( x => await ) ; 
try { await ( 0 ) ; } catch { } finally { } 
try { await ; } catch { } 
try { let [ ] = 0 ; } catch ( [ ... x ] ) { } 
try { let [ ] = 0 ; } catch ( [ x , ... [ ] ] ) { } 
try { let [ ] = await ; } catch ( [ ] ) { } 
try { let [ ] = await ; } catch ( x ) { throw 0 ; } 
try { let [ ] = await ; } catch ( x ) { } 
try { throw 0 ; } finally { new x ( ) ; } function * x ( ) { } 
try { throw await => 0 ; } catch { x ; } 
try { } catch ( x ) { } finally { } for ( x of [ , ] ) for ( var x of 0 ) ; 
try { } catch ( x ) { } finally { } for ( x of [ , ] ) var [ x ] = 0 ; 
try { } catch ( x ) { } finally { } let x ; 
try { } catch ( x ) { } let x ; 
try { } catch { } finally { async function x ( ) { } } let x ; 
try { } catch { } finally { class x { } } let x ; 
try { } finally { await ( 0 ) ; } 
try { } finally { class x { } } let x ; 
try { } finally { function * x ( ) { } } let x ; 
typeof await ; 
typeof function ( ... { ... x } ) { } ; 
typeof function * ( ... { ... x } ) { } ; 
var [ ... [ ] ] = 0 ; 
var [ ... [ x ] ] = 0 ; 
var [ ... await ] = `` ; 
var [ ... x ] = 0 ; 
var [ ... x ] = 0n ; 
var [ ... x ] = [ , 0 ] ; 
var [ ... x ] = [ , ] ; 
var [ ... x ] = [ 0 , , 0 , ] ; 
var [ ... x ] = [ 0 , , ] ; 
var [ ... x ] = async function ( ) { } ; 
var [ ... x ] = async function * ( ) { } ; 
var [ ... x ] = async x => { } ; 
var [ ... x ] = class { } ; 
var [ ... x ] = false ; 
var [ ... x ] = function ( ) { } ; 
var [ ... x ] = function * ( ) { } ; 
var [ ... x ] = this ; 
var [ ... x ] = true ; 
var [ ... x ] = { set 0 ( [ ] ) { } } ; 
var [ ... x ] = { x , } ; 
var [ ... x ] = { x } ; 
var [ ... x ] = { } ; 
var [ ... { 0 : [ ] , ... x } ] = '' ; 
var [ ... { x , ... x } ] = 0 ; 
var [ ... { x } ] = 0n ; 
var [ [ ] , ... x ] = { [ Symbol . iterator ] : async function * ( x ) { } } ; 
var [ [ ] ] = [ , ] ; 
var [ ] = [ ] ; 
var [ ] = await ; 
var [ ] = await => 0 ; 
var [ ] = { [ Symbol . iterator ] : async function ( x ) { } } ; 
var [ ] = { [ Symbol . iterator ] : async function * ( x ) { } } ; 
var [ x , ... [ x , ] ] = 0n ; 
var [ x , ... await ] = '' ; 
var [ x , ... await ] = 0 ; 
var [ x , ... x ] = 0 ; 
var [ x , ... x ] = [ , , ] ; 
var [ x , ... x ] = [ 0 , , 0 , ] ; 
var [ x , ... { ... x } ] = '' ; 
var [ x , ... { x , ... x } ] = '' ; 
var [ x , ... { x } ] = 0 ; 
var [ x , [ ] ] = [ 0 , , ] ; 
var [ x , ] = [ x => 0 , ] ; 
var [ x , x ] = [ 0 , , ] ; 
var [ x = function ( ) { } ] = '' ; 
var [ x ] = await ++ ; 
var [ x ] = await ; 
var [ { ... x } = 0 , ... x ] = '' ; 
var [ { x , ... x } = 0 , ... x ] = '' ; 
var [ { } , ] = '' ; 
var await = 0 ; 
var x ; switch ( 0 ) { default : x ( ) ; case 1 : function * x ( x , ) { } } 
var x ; switch ( 0 ) { default : x ; case 1 : let x ; } 
var x ; x = async function ( ) { } ; 
var x ; x = async function * ( ) { } ; 
var x ; x = async x => 0 ; 
var x ; x = class { } ; 
var x ; x = x => 0 ; 
var x = ( ... { 0n : { x } } ) => 0 ; x ( ) ; 
var x = async function ( ) { } ; 
var x = async function * ( ) { } ; 
var x = async x => 0 ; 
var x = await ( ) ; 
var x = await ; 
var x = await `` ; 
var x = class extends function * ( ) { } { } ; 
var x = class { } ; 
var x = function ( ) { await : ; } ( ) ; x ( ) ; 
var x = function ( ... { ... x } ) { } ; 
var x = function * ( ) { } ; 
var x = x => 0 ; 
var x = x => new async function ( ) { } ( ) ; x ( ) ; 
var x = { * 0 ( ) { } } ; 
var x = { * 0 ( ... x ) { } } ; 
var x = { * 0 ( x ) { } } ; 
var x = { 0 ( ) { } , } ; 
var x = { 0 ( ) { } } ; 
var x = { 0 ( ... x ) { } } ; 
var x = { 0 ( x ) { } } ; 
var x = { [ Symbol . split ] : function ( x ) { } } ; 
var x = { async * 0 ( ) { } } ; 
var x = { async * 0 ( ... x ) { } } ; 
var x = { async * 0 ( x ) { } } ; 
var x = { async * x ( ) { } } ; 
var x = { async 0 ( ) { } } ; 
var x = { async 0 ( ... x ) { } } ; 
var x = { async 0 ( x ) { } } ; 
var x = { set 0 ( x ) { } } ; 
var x = { set [ 0 ] ( x ) { } , } ; 
var x = { throw : function ( x ) { } } ; 
var x = { } ; Object . setPrototypeOf ( x , async function ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , async function ( ) { } . prototype ) ; 
var x = { } ; Object . setPrototypeOf ( x , async function * ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , async x => 0 ) ; 
var x = { } ; Object . setPrototypeOf ( x , class { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , function * ( ) { } ) ; 
var x = { } ; Object . setPrototypeOf ( x , x => 0 ) ; 
var { '' : { x , ... x } } = 0 ; 
var { ... await } = 0 ; 
var { ... await } = 0n ; 
var { ... await } = [ ] ; 
var { ... x } = null ; 
var { ... x } = x ; 
var { ... x } = { [ Symbol . split ] : ( ) => { } } ; 
var { ... x } = { async [ 0 ] ( ) { } } ; 
var { 0 : x } = { * 0 ( x ) { } } ; 
var { 0 : { } , } = 0 ; 
var { 0 : { } = await } = [ 0 ] ; 
var { 0 : { } } = 0 ; 
var { 0n : [ ] = x } = 0 ; 
var { 0n : [ ] } = `${ 0 }` ; 
var { 0n : [ ] } = { set 0 ( x ) { } } ; 
var { 0n : { } } = [ 0 ] ; 
var { 1n : [ ] } = 0 ; 
var { 1n : x } = 0 ; 
var { 1n : { } = 0 } = 0 ; 
var { [ 0 . x = 0 ] : x } = ( ... { ... x } ) => 0 ; 
var { [ 0 ] : { } , } = 0 ; 
var { x , ... await } = 0 ; 
var { x , ... await } = 0n ; 
var { x , ... await } = [ ] ; 
var { x , ... x } = { 0 : x => { } } ; 
var { x , ... x } = { [ Symbol . split ] : ( ) => { } } ; 
var { x , } = async function * ( ... { ... x } ) { } ; 
var { x = 0 } = { set 0 ( x ) { } } ; 
var { x = await } = { x : 0 , } ; 
var { x = function ( ) { } } = 0 ; 
var { x } = await ; 
var { x } = { x , } = 0 ; 
var { x } = { x : async function ( ) { } , } ; 
var { x } = { x : async function * ( ) { } , } ; 
var { x } = { x : async x => 0 , } ; 
var { x } = { x : class { } , } ; 
var { x } = { x : function * ( ) { } , } ; 
var { x } = { x : x => 0 , } ; 
var { x } = { x : { return : function ( x ) { } } , } ; 
var { } = 0 . x ; 
var { } = 0 [ 0 ] ; 
var { } = new 0 ?? await ; 
var { } = new function * ( ) { } ; 
var { } = x ; 
var { } = x ; x ( ) ; 
void async function ( ... { ... x } ) { } ; 
void function ( ... { ... x } ) { } ; 
while ( async function ( ... { ... x } ) { } ) break ; 
while ( await => 0 ) throw 0 ; 
x ( ) ; let x ; 
x ( ) ; switch ( 0 ) { case 1 : try { } catch ( x ) { } finally { } default : case 0 : var x ; } 
x ( await => 0 ) ; 
x , await ; 
x - async function * ( ... { ... x } ) { } ; 
x . x ; let x ; 
x / `${ await => 0 }` ; 
x ; await : ; 
x ; for ( ; ; ) ; class x { } 
x ; let [ [ ] , x ] = `` ; 
x ; let [ x , ... { 0 : [ ] } ] = `` ; 
x ; let x ; 
x = 0 ; let x ; 
x = await => 0 ; 
x = await `` ; 
x = class extends function * ( ) { } { } ; 
x = function * ( [ x , ] , ) { } ( ) ; 
x = new function * ( ) { } ; 
x = this . x -- ; 
x = this . x = 0 ; 
x = x => 0 ; var x ; 
x = { [ Symbol . toPrimitive ] : 0 ?? await } <= 0 ; 
x = { } = null ; 
x == async function * ( ... { ... x } ) { } ; 
x === function ( ... { ... x } ) { } ; 
x ? 0 : await => 0 ; 
x [ 0 ] ; let x ; 
x [ await => 0 ] ; 
x `` ; let x ; 
x in 0 ; let x ; 
x in `${ await => 0 }` ; 
x instanceof 0 ; let x ; 
{ async function * x ( ) { } } let x ; 
{ async function x ( ) { } } let x ; 
{ await } ; 
{ class x { } } var x ; 
{ const x = 0 ; } let x ; 
{ function * x ( ) { } } let x ; 
{ function x ( ) { } } let x ; 
{ let x ; } let x = 0 ; 
{ x } ; await : ; 
{ x } ; let x ; 
~ async function ( ... { ... x } ) { } ( ) ; 
~ async function * ( [ ] ) { } ( ) ; 
~ async function * ( [ ] , ... x ) { } ( ) ; 
~ async function * ( [ x ] ) { } ( ) ; 
~ await `` ; 
~ function ( ... { ... x } ) { } ( ) ; 
~ function * ( [ ] ) { } ( ) ; 
~ function * ( [ ] , ... x ) { } ( ) ; 
