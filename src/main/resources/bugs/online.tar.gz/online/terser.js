! class extends 0 { } ; 
! { async [ { } instanceof 0 ] ( ) { } } ; 
"use strict";
'' != { [ Symbol . toPrimitive ] : 0 } ; 
'' ( await => 0 ) ; 
'' < Symbol . toPrimitive ; 
'' < class extends 0 { } ; 
'' <= Symbol . toPrimitive ; 
'' == class extends 0 { } ; 
'' == { [ Symbol . toPrimitive ] : async function ( ... x ) { } } ; 
'' == { [ Symbol . toPrimitive ] : x => ( ... [ ] ) => 0 } ; 
'' > Symbol . toPrimitive ; 
'' >= Symbol . toPrimitive ; 
'' [ class extends 0 { } ] ; 
'' instanceof 0 ; 
( ( ) => class extends 0 { } ) ( ) ; 
( ( ... x ) => class extends 0 { } ) ( ) ; 
( ( ... x ) => class { static { } } ) ( ) ; 
( ... await ) => 0 ; 
( 0 ? await => 0 : 0 ) ( ) ; 
( async x => 0 ) ( class extends 0 { } ) ; 
( async x => { for await ( var { x } of 0 ) if ( 0 ) ; else do return ; while ( 0 ) ; } ) ( ) ; 
( await => 0 ( ) ) ( ) ; 
( await => 0 ) ( ) ( ) ; 
( await => 0 , 0 ) * 1n ; 
( await => 0 , 0 ) . x ++ ; 
( await => 0 . x = 0 ) ( ) ; 
( await => 0 in 0 ) ( ) ; 
( await => [ ... 0 , ] ) ( ) ; 
( await => await ( ) ) ( ) ; 
( await => class { } ( ) ) ( ) ; 
( await => function ( ) { } ( ) . x ) ( ) ; 
( await => this ( ) ) ( ) ; 
( await => x ( ) ) ( ) ; 
( await => x ) ( ) ; 
( await => { [ ... 0 ] ; } ) ( ) ; 
( await => { for ( let x of 0 ) ; } ) ( ) ; 
( await => { throw 0 ; } ) ( ) ; 
( await => { x ; } ) ( ) ; 
( class extends 0 { } ) ; 
( class { } ? 0 : 0 ( ) ) ; 
( class { } ? [ ] : 0 ( ) ) ; 
( class { } ? async function ( ) { } : 0 ( ) ) ; 
( class { } ? async function * ( ) { } : 0 ( ) ) ; 
( class { } ? function ( ) { } : 0 ( ) ) ; 
( class { } ? function * ( ) { } : 0 ( ) ) ; 
( class { } ? this : 0 ( ) ) ; 
( class { } ? { } : 0 ( ) ) ; 
( function ( [ ] , ... x ) { } ) ( ) ; 
( x => 0 ) ( ... 0 ) ; 
( x => 0 ) ( 0 , ... 0 ) ; 
( x => 0 ) ( class extends 0 { } ) ; 
( x => [ ... 0 ] ) ( ) ; 
( x => class extends 0 { } ) ( ) ; 
( x => class extends function ( ) { } ( ) { } ) ( ) ; 
( x => class extends function * ( ) { } ( ) { } ) ( ) ; 
( x => class extends function * ( x , ) { } ( ) { } ) ( ) ; 
( x => function ( [ ] , ) { } ( ) ) ( ) ; 
( x => { return class extends 0 { } ; } ) ( ) ; 
( x => { x ( ) ; if ( 0 ) var [ ] = 0 ; else ; } ) ( ) ; 
( x => { x ( ) ; if ( class { } ) ; else ; } ) ( ) ; 
( x => { x ( ) ; if ( class { } ) ; } ) ( ) ; 
+ 1n ; 
+ 1n ; for ( let x ; ; ) ; 
+ 1n ; throw 0 ; 
+ 1n ; x ; 
+ Symbol . toPrimitive ; 
+ class extends 0 { } ; 
+ { 0 : 0 in 0 , x } ; 
+ { 0 : await => 0 , x } ; 
+ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
++ 0 . x ; await => 0 ; 
- Symbol . split ; 
- class extends '' { } ; 
- class extends 0 . x { } ; 
- class extends 0 { } ; 
- class extends [ ] { } ; 
- class extends `` { } ; 
- class extends async function ( ) { } { } ; 
- class extends async function * ( ) { } { } ; 
- class extends false { } ; 
- class extends function * ( ) { } { } ; 
- class extends this { } ; 
- class extends true { } ; 
- class extends { * 0 ( ) { } , } { } ; 
- class extends { 0 : null } { } ; 
- class extends { } { } ; 
- class x extends x { } ; 
- class x extends { x , } { } ; 
- class x extends { x } { } ; 
- class { } . x * 1n ; 
- { ... [ 0 , ... 0 , ] , x } ; 
- { ... await => 0 , x } ; 
- { ... class extends 0 { } , x } ; 
- { [ Symbol . toPrimitive ] : ( ) => x } ; 
- { [ Symbol . toPrimitive ] : ( ) => { x ; } } ; 
- { [ Symbol . toPrimitive ] : ( ... [ x ] ) => await } ; 
- { [ Symbol . toPrimitive ] : ( ... x ) => await } ; 
- { [ Symbol . toPrimitive ] : 0 ? await => 0 : 0 } ; 
- { [ Symbol . toPrimitive ] : await => [ 0 , ] } ; 
- { [ Symbol . toPrimitive ] : await => [ 0 ] } ; 
- { [ Symbol . toPrimitive ] : await => async function * ( ) { } } ; 
- { [ Symbol . toPrimitive ] : await => async x => 0 } ; 
- { [ Symbol . toPrimitive ] : await => function * ( ) { } } ; 
- { [ Symbol . toPrimitive ] : await => this } ; 
- { [ Symbol . toPrimitive ] : await => { x ; } } ; 
- { [ Symbol . toPrimitive ] : x => await } ; 
- { [ null . toPrimitive ] : await => 0 } ; 
- { [ x ] : await => 0 } ; 
- { [ { [ Symbol . toPrimitive ] : '' } ] : { x } } ; 
- { x , } ; let x ; 
0 != class extends 0 { } ; 
0 != { [ Symbol . toPrimitive ] : 0 } ; 
0 != { [ Symbol . toPrimitive ] : [ ] } ; 
0 != { [ Symbol . toPrimitive ] : `` } ; 
0 != { [ Symbol . toPrimitive ] : async function ( ) { } } ; 
0 != { [ Symbol . toPrimitive ] : async function ( x , ... [ ] ) { } } ; 
0 != { [ Symbol . toPrimitive ] : async function ( { } ) { } } ; 
0 != { [ Symbol . toPrimitive ] : async function * ( ) { } } ; 
0 != { [ Symbol . toPrimitive ] : async function * ( ... [ ] ) { } } ; 
0 != { [ Symbol . toPrimitive ] : async function * ( ... x ) { } } ; 
0 != { [ Symbol . toPrimitive ] : async function * ( x , ... [ ] ) { } } ; 
0 != { [ Symbol . toPrimitive ] : class { } } ; 
0 != { [ Symbol . toPrimitive ] : function * ( ) { } } ; 
0 != { [ Symbol . toPrimitive ] : function * ( ... x ) { } } ; 
0 != { [ Symbol . toPrimitive ] : function * ( ... { ... x } ) { } } ; 
0 != { [ Symbol . toPrimitive ] : function * ( x ) { } } ; 
0 != { [ Symbol . toPrimitive ] : this } ; 
0 != { [ Symbol . toPrimitive ] : x => await } ; 
0 != { [ Symbol . toPrimitive ] : x => function ( ) { } } ; 
0 != { [ Symbol . toPrimitive ] : x => x => 0 } ; 
0 != { [ Symbol . toPrimitive ] : { } } ; 
0 !== class extends 0 { } ; 
0 % class extends 0 { } ** 0 ; 
0 & 0n ; 
0 & Symbol . toPrimitive ; 
0 & class extends 0 { } ; 
0 && await ; 
0 ( ) . x = await ; 
0 ( ) ; await ; 
0 ( ) [ 0 ] = await ; 
0 ( ) [ await ] ; 
0 ( ) `${ await => 0 }` ; 
0 ( ... await => 0 ) ; 
0 ( ... x ) ; let x ; 
0 ( 0 ?? await ) ; 
0 ( await => 0 ) ; 
0 ( x ) ; let x ; 
0 ( x , ... await => 0 ) ; 
0 ** 0n ; 
0 ** class extends 0 { } ; 
0 ** class extends { } . x { } ; 
0 ** { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 + 0n ; 
0 + Symbol . toPrimitive ; 
0 + class extends 0 { } ; 
0 + { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 + { [ Symbol . toPrimitive ] : x => await } ; 
0 , 0 ( ) [ await => 0 ] ; 
0 , 0 in 0 ; 
0 , 0 instanceof 0 ; 
0 , class extends 0 { } ; 
0 - 0n ; 
0 - Symbol . toPrimitive ; 
0 - class extends 0 { } ** 0 ; 
0 - class extends 0 { } ; 
0 - { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 . x &&= await ; 
0 . x ( ) [ await ] ; 
0 . x ( await => 0 ) ; 
0 . x + 0n ; 
0 . x ++ ; await => { } ; 
0 . x -- ; if ( 0 ) var [ ] = 0 ; 
0 . x . x [ await ] ; 
0 . x / 1n ; 
0 . x = 0 && await ; 
0 . x = 0 ?? await ; 
0 . x = x ; let x ; 
0 . x [ 0 ] [ await ] ; 
0 . x [ x ] ; let x ; 
0 . x instanceof [ ] ; 
0 / 1n ; 
0 / class extends 0 { } ; 
0 / { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 < Symbol . toPrimitive ; 
0 < class extends 0 { } ** 0 ; 
0 < class extends 0 { } ; 
0 < { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ** 0 ; 
0 < { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 << 1n ; 
0 <= Symbol . toPrimitive ; 
0 <= class extends 0 { } ; 
0 == 0 ^ 1 ? await : 0 ; 
0 == 0 ^ true ? await : 0 ; 
0 == class extends 0 { } ; 
0 == { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 == { [ Symbol . toPrimitive ] : 0 } ; 
0 == { [ Symbol . toPrimitive ] : Symbol . split } ; 
0 == { [ Symbol . toPrimitive ] : async function ( x ) { } } ; 
0 == { [ Symbol . toPrimitive ] : async function * ( ) { } } ; 
0 == { [ Symbol . toPrimitive ] : async function * ( x ) { } } ; 
0 == { [ Symbol . toPrimitive ] : async x => { } } ; 
0 == { [ Symbol . toPrimitive ] : class { } } ; 
0 == { [ Symbol . toPrimitive ] : false } ; 
0 == { [ Symbol . toPrimitive ] : function * ( ) { } } ; 
0 == { [ Symbol . toPrimitive ] : function * ( ... [ ] ) { } } ; 
0 == { [ Symbol . toPrimitive ] : { done : null } } ; 
0 == { [ Symbol . toPrimitive ] : { } } ; 
0 === class extends 0 { } ; 
0 > Symbol . toPrimitive ; 
0 > class extends 0 { } ; 
0 > { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 >= Symbol . toPrimitive ; 
0 >= class extends 0 { } ; 
0 >> 1n ; 
0 >> Symbol . toPrimitive ; 
0 >> class extends 0 { } ; 
0 >>> 0n ; 
0 >>> class extends 0 { } ; 
0 >>> { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
0 ? await : 0 ; 
0 ? await => 0 : x ; 
0 ?? await ; 
0 [ 0 ] = await => 0 ; 
0 [ 0 ] [ 0 ] [ await => 0 ] ; 
0 [ class extends 0 { } ] ; 
0 [ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ] ; 
0 [ { [ Symbol . toPrimitive ] : 0 } ] ; 
0 [ { [ Symbol . toPrimitive ] : [ ] } ] ; 
0 [ { [ Symbol . toPrimitive ] : async function * ( ) { } } ] ; 
0 [ { [ Symbol . toPrimitive ] : async x => { } } ] ; 
0 [ { [ Symbol . toPrimitive ] : class { } } ] ; 
0 [ { [ Symbol . toPrimitive ] : function * ( ) { } } ] ; 
0 [ { [ Symbol . toPrimitive ] : function * ( [ ] ) { } } ] ; 
0 [ { [ Symbol . toPrimitive ] : x => await } ] ; 
0 [ { [ Symbol . toPrimitive ] : x => x => 0 } ] ; 
0 ^ 1n ; 
0 ^ 1n ? await : 0 ; 
0 ^ Symbol . toPrimitive ; 
0 ^ Symbol . toPrimitive ? await : 0 ; 
0 ^ class extends 0 { } ; 
0 in '' ; 
0 in 0 . x ; 
0 in 0 ; 
0 in `` ; 
0 in this . x ; 
0 in true ; 
0 in x ; var x ; 
0 instanceof 0 . x ; 
0 instanceof 0 ; 
0 instanceof 0 || await ; 
0 instanceof Symbol . split ; 
0 instanceof [ ] ; 
0 instanceof `` ; 
0 instanceof false ; 
0 instanceof new function ( ) { } ( ) ; 
0 instanceof null ; 
0 instanceof true ; 
0 instanceof { * 0 ( ) { } , } ; 
0 instanceof { 0 ( ) { } } ; 
0 instanceof { [ Symbol . hasInstance ] : ( ) => { throw 0 ; } } ; 
0 instanceof { [ Symbol . hasInstance ] : function ( ) { throw 0 ; } } ; 
0 instanceof { } ; 
0 | 1n ; 
0 | Symbol . toPrimitive ; 
0 | class extends 0 { } ; 
0 || class extends 0 { } ; 
0n & 0 ; 
0n ** 0 ; 
0n - 0 ; 
0n < Symbol . toPrimitive ; 
0n >= Symbol . toPrimitive ; 
0n >> 0 ; 
0n ^ 0 ; 
1 && class extends 0 { } ; 
1 ** Symbol . toPrimitive ; 
1 ** class extends 0 { } ** 0 ; 
1 ** { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ** 0 ; 
1 <= { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
1 ? 0 : await ; 
1 ? x : await => 0 ; 
1 || await ; 
1n % 0n ; 
1n * '' . x ; 
1n * Symbol . match ; 
1n * [ ] . x ; 
1n * `${ await => { } , 0 }` ; 
1n * `` . x ; 
1n * async function ( ) { } ( ) ; 
1n * async function ( ) { } . x ; 
1n * async function * ( ) { } ( ) ; 
1n * async function * ( ) { } . x ; 
1n * class { } . x ; 
1n * false ; 
1n * function ( ) { } ( ) ; 
1n * function ( ) { } . x ; 
1n * function ( ... [ x , ] ) { } ( ) ; 
1n * function * ( ) { } ( ) ; 
1n * function * ( ) { } . x ; 
1n * new class { } ( ) ; 
1n * new function ( ... x ) { } ( ) ; 
1n * null ?. x ; 
1n * { * 0 ( ) { } , } ; 
1n * { * 0 ( ) { } } ; 
1n * { * 0 ( x , ) { } } ; 
1n * { ... x => { } } ; 
1n * { 0 ( ) { } } ; 
1n * { 0 ( [ ] ) { } , } ; 
1n * { 0 ( x , ) { } } ; 
1n * { 0 : ( ) => { } } ; 
1n * { 0 : async function ( x ) { } } ; 
1n * { 0 : async function * ( x ) { } } ; 
1n * { 0 : function * ( x ) { } } ; 
1n * { 1 : function ( x ) { } } ; 
1n * { [ 0 ] : await => 0 } ; 
1n * { async * 0 ( ) { } } ; 
1n * { async 0 ( ) { } } ; 
1n * { async 0 ( ... { } ) { } } ; 
1n * { get 0 ( ) { } } ; 
1n * { set 0 ( x ) { } } ; 
1n * { set x ( x ) { } , } ; 
1n * { } . x ; 
1n * { } ; 
1n ** { } ; 
1n + 0 ; 
1n - '' ; 
1n - { } ; 
1n / '' ; 
1n / 0 . x ; 
1n / 0 ; 
1n / 0n ; 
1n / [ ] ; 
1n / `` ; 
1n / null ; 
1n / this ; 
1n / true ; 
1n / { async 0 ( x , ) { } , } ; 
1n << 0 ; 
1n >>> 0 ; 
AggregateError ( await => 0 ) ; 
Array ( class { } ? 0 : 0 ( ) ) ; 
Array . from ( await => 0 , 0 ) ; 
Array . from ( { [ Symbol . iterator ] : await => 0 } ) ; 
Array . from . call ( await => 0 ) ; 
Array . map ( await => 0 ) ; 
BigInt . asUintN ( { [ Symbol . toPrimitive ] : await => 0 } ) ; 
BigInt . call ( await => 0 ) ; 
Function . apply ( ( ... await ) => 0 , [ this ] ) ; 
Map ( await => 0 ) ; 
Number ( { [ Symbol . toPrimitive ] : 0 ? await : 0 } ) ; 
Object . create ( 0 , await => 0 ) ; 
Object . create ( await => 0 , [ 0 ] ) ; 
Object . defineProperties ( await => 0 ) ; 
Object . defineProperty ( await => 0 ) ; 
Object . entries . call ( await => 0 ) ; 
Object . fromEntries ( await => 0 ) ; 
Object . getOwnPropertyDescriptor ( await => 0 , { [ Symbol . toPrimitive ] : 0 } ) ; 
Object . getOwnPropertyDescriptor . call ( await => 0 ) ; 
Object . getOwnPropertyDescriptors . call ( await => 0 ) ; 
Object . getOwnPropertySymbols . call ( await => 0 ) ; 
Object . getPrototypeOf . call ( await => 0 ) ; 
Object . hasOwn ( ( ... await ) => 0 , { [ Symbol . toPrimitive ] : '' } ) ; 
Object . hasOwn . call ( await => 0 ) ; 
Object . isPrototypeOf . call ( null , await => 0 ) ; 
Object . keys . call ( await => 0 ) ; 
Object . setPrototypeOf ( await => 0 ) ; 
Object . values . call ( await => 0 ) ; 
Promise ( await => 0 ) ; 
Set ( await => 0 ) ; 
String ( { [ Symbol . toPrimitive ] : 0 ?? await } ) ; 
String ( { [ Symbol . toPrimitive ] : class { } ? 0 : 0 } ) ; 
String . prototype . normalize ( { [ Symbol . toPrimitive ] : await => 0 } ) ; 
String . raw ( await => 0 ) ; 
Symbol ( { [ Symbol . toPrimitive ] : 0 ?? await } ) ; 
Symbol . keyFor ( await => 0 ) ; 
Symbol . toPrimitive ** 0 ; 
Symbol . toPrimitive + '' ; 
Symbol . toPrimitive + 0 ; 
Symbol . toPrimitive + false ; 
Symbol . toPrimitive + this ; 
Symbol . toPrimitive + typeof Symbol ; 
Symbol . toPrimitive + typeof async function ( ) { } ; 
Symbol . toPrimitive + typeof async function * ( ) { } ; 
Symbol . toPrimitive + typeof class { } ; 
Symbol . toPrimitive + typeof function ( ) { } ; 
Symbol . toPrimitive + typeof function * ( ) { } ; 
Symbol . toPrimitive + typeof x ; 
Symbol . toPrimitive + { raw : ( ) => { } } ; 
Symbol . toPrimitive + { } ; 
Symbol . toPrimitive / 1 ; 
Symbol . toPrimitive < 0 ; 
Symbol . toPrimitive > 0 ; 
WeakMap ( await => 0 ) ; 
WeakSet ( await => 0 ) ; 
[ '' , ... 0 ] ; 
[ , ] = { [ Symbol . iterator ] : function * ( ) { yield * x ; let x ; } } ; 
[ ... ( ) => { } ] ; 
[ ... 0 , ... await ] ; 
[ ... 0 , ] !== x ; 
[ ... 0 , ] ** 0 ; 
[ ... 0 , ] , x ; 
[ ... 0 , ] ; 
[ ... 0 , ] < x ; 
[ ... 0 , ] <= x ; 
[ ... 0 , ] == x ; 
[ ... 0 , ] >= x ; 
[ ... 0 , ] >>> x ; 
[ ... 0 , ] ? x : 0 ; 
[ ... 0 , ] [ x ] ; 
[ ... 0 , ] ^ x ; 
[ ... 0 , ] in x ; 
[ ... 0 , ] instanceof x ; 
[ ... 0 , ] | x ; 
[ ... 0 , await => 0 , ] ; 
[ ... 0 , x ] ; 
[ ... 0 ] && x ; 
[ ... 0 ] ** 0 ; 
[ ... 0 ] / x ; 
[ ... 0 ] ; 
[ ... 0 ] ; for ( ; ; ) ; 
[ ... 0 ] < x ; 
[ ... 0 ] <= x ; 
[ ... 0 ] == x ; 
[ ... 0 ] === x ; 
[ ... 0 ] ? x : 0 ; 
[ ... 0 ] [ x ] ; 
[ ... 0 ] in x ; 
[ ... 0 ] instanceof x ; 
[ ... 0 ] | x ; 
[ ... 1n ] ; 
[ ... Symbol ] ; 
[ ... [ ] . x ] ; 
[ ... `` . x ] ; 
[ ... async function ( ) { } ] ; 
[ ... async function ( ... x ) { } ] ; 
[ ... async function ( x ) { } ] ; 
[ ... async function ( x , ... [ ] ) { } ] ; 
[ ... async function * ( ) { } ] ; 
[ ... async function * ( ... x ) { } ] ; 
[ ... async function * ( [ ] , ... x ) { } ] ; 
[ ... async function * ( x ) { } ] ; 
[ ... async x => { } ] ; 
[ ... class { } ] ; 
[ ... false ] ; 
[ ... function ( ) { } ] ; 
[ ... function ( ... x ) { } ] ; 
[ ... function ( x ) { } ] ; 
[ ... function * ( ) { } ] ; 
[ ... function * ( ... x ) { } ] ; 
[ ... function * ( [ ] , ... x ) { } ] ; 
[ ... function * ( x ) { } ] ; 
[ ... null ] ; 
[ ... this ] ; 
[ ... true ] ; 
[ ... x => { } ] ; 
[ ... { * 0 ( ) { } , } ] ; 
[ ... { 0 : '' } ] ; 
[ ... { [ Symbol . iterator ] : ( ) => { throw 0 ; } } ] ; 
[ ... { async * 0 ( ... x ) { } , } ] ; 
[ ... { set 0 ( { ... x } ) { } , } ] ; 
[ ... { set : '' } ] ; 
[ ... { } ] ; 
[ 0 , ... 0 , ] != x ; 
[ 0 , ... 0 , ] / x ; 
[ 0 , ... 0 , ] ; 
[ 0 , ... 0 , ] === x ; 
[ 0 , ... 0 , ] > x ; 
[ 0 , ... 0 , x ] ; 
[ 0 , ... 0 ] != x ; 
[ 0 , ... 0 ] , x ; 
[ 0 , ... 0 ] ; 
[ 0 , ... 0 ] > x ; 
[ 0 , ... 0 ] >>> x ; 
[ 0 , ... 0n ] ; 
[ 0 , ... Symbol ] ; 
[ 0 , ... null ] ; 
[ 0 , ... true ] ; 
[ 0 , ... { } ] ; 
[ 0 , ] . x %= 1n ; 
[ 0 , ] instanceof async function ( ) { } ; 
[ 0 ] . x %= 1n ; 
[ 0 ] [ 0 ] ??= await ; 
[ 0 ] instanceof async function ( ) { } ; 
[ 0 in 0 ] ; 
[ Symbol , ... 0 ] ; 
[ [ , ] [ 0 ] ] = `` ; 
[ [ 0 , ] [ 0 ] ] = [ ] ; 
[ [ ] , ... 0 ] ; 
[ ] + Symbol . toPrimitive ; 
[ ] - Symbol . toPrimitive ; 
[ ] . x %= 1n ; 
[ ] . x %= Symbol . toPrimitive ; 
[ ] . x &= 0n ; 
[ ] . x * 1n ; 
[ ] . x = class extends 0 { } ; 
[ ] . x ^= 1n ; 
[ ] / 1n ; 
[ ] < Symbol . toPrimitive ; 
[ ] <= Symbol . toPrimitive ; 
[ ] = await => 0 ; 
[ ] = x ; let x ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { `${ yield }` ; } } ; 
[ ] = { [ Symbol . iterator ] : async function * ( ) { for await ( [ 0 ] [ 0 ] of [ ] ) ; } } ; 
[ ] = { [ Symbol . iterator ] : function * ( ) { `${ yield }` ; } } ; 
[ ] == class extends 0 { } ; 
[ ] > Symbol . toPrimitive ; 
[ ] >= Symbol . toPrimitive ; 
[ ] [ { [ Symbol . toPrimitive ] : 0 } ] ; 
[ ] ^ 0n ; 
[ ] in 0 ; 
[ ] instanceof async function ( ) { } ; 
[ ] instanceof { get '' ( ) { } , } ; 
[ `` , ... 0 ] ; 
[ async function ( ) { } , ... 0 ] ; 
[ async function * ( ) { } , ... 0 ] ; 
[ async x => { } , ... 0 ] ; 
[ await => 0 , x ] ; 
[ await => 0 , { x } ] ; 
[ await => 0 ] ( ) ; 
[ await ] = 0 ; 
[ await ] = Symbol ; 
[ await ] = class { } ; 
[ await ] = function ( ) { } ; 
[ await ] = function * ( ) { } ; 
[ await ] = this ; 
[ class extends 0 { } , ] ; 
[ class extends 0 { } , x ] ; 
[ class extends 0 { } ] ; 
[ class { } , ... 0 ] ; 
[ false , ... 0 ] ; 
[ function ( ) { } , ... 0 ] ; 
[ function ( [ ] ) { } ( ) ] ; 
[ function ( { } ) { } ( ) ] ; 
[ function * ( ) { } , ... 0 ] ; 
[ null , ... 0 ] ; 
[ this , ... 0 ] ; 
[ true , ... 0 ] ; 
[ x , await => 0 ] ; 
[ x => { } ] in 0 ; 
[ { * x ( ) { } , } , ... 0 ] ; 
[ { [ Symbol . toPrimitive ] : 0 } + async function ( ) { } ] ; 
[ { [ Symbol . toPrimitive ] : 0 } + async function * ( ) { } ] ; 
[ { [ Symbol . toPrimitive ] : 0 } + class { } ] ; 
[ { [ Symbol . toPrimitive ] : 0 } + function ( ) { } ] ; 
[ { [ Symbol . toPrimitive ] : 0 } + function * ( ) { } ] ; 
[ { x , } = await => 0 ] ; 
[ { x , } ] ; let x ; 
[ { x = 0 } = 0 instanceof 0 ? 0 : 0 ] ; 
[ { x = 0 } = await => 0 ] ; 
[ { x } = await => 0 ] ; 
[ { } , ... 0 ] ; 
[ { } = await ] = [ 0 ] ; 
`${ '' }${ Symbol . toPrimitive }` ; 
`${ 0 }${ Symbol . match }` ; 
`${ 0 }${ Symbol . toPrimitive }${ x }` ; 
`${ 0 }${ [ ... 0 ] }${ x }` ; 
`${ 0 }${ [ 0 , ... 0 , ] }${ x }` ; 
`${ 0 }${ class extends 0 { } }` ; 
`${ 0 }${ x }${ await => 0 }` ; 
`${ 0 }${ { [ Symbol . toPrimitive ] : x => { throw 0 ; } } }` ; 
`${ 0n }${ Symbol . toPrimitive }` ; 
`${ Symbol . toPrimitive }` ; 
`${ [ ... 0 , ] }${ x }` ; 
`${ [ ... 0 ] }${ x }` ; 
`${ [ ] }${ Symbol . toPrimitive }` ; 
`${ `` }${ Symbol . toPrimitive }` ; 
`${ class extends 0 { } }` ; 
`${ false }${ Symbol . toPrimitive }` ; 
`${ null }${ Symbol . toPrimitive }` ; 
`${ this }${ Symbol . toPrimitive }` ; 
`${ true }${ Symbol . toPrimitive }` ; 
`${ { [ Symbol . toPrimitive ] : x => await } }` ; 
`${ { } }${ Symbol . toPrimitive }` ; 
`` != { [ Symbol . toPrimitive ] : 0 } ; 
`` ( x ) ; let x ; 
`` + Symbol . toPrimitive ; 
`` + class extends 0 { } ; 
`` . x * 1n ; 
`` . x + 0n ; 
`` / 1n ; 
`` < Symbol . toPrimitive ; 
`` <= Symbol . toPrimitive ; 
`` == { [ Symbol . toPrimitive ] : 0 } ; 
`` === class extends 0 { } ; 
`` > Symbol . toPrimitive ; 
`` >= Symbol . toPrimitive ; 
`` [ { [ Symbol . toPrimitive ] : 0 } ] ; 
async function * await ( ) { } await ; 
async function * await ( x , ) { } await ; 
async function * x ( ) { } x in 0 ; 
await ( ) ; 
await ** 0 ; 
await + 0 ; 
await ++ ; 
await . x ; 
await ; 
await ; async function await ( ) { } 
await ; function await ( ) { } 
await = 0 ( ) ; 
await = 0 . x -- ; 
await = 0 . x = 0 ; 
await = 0 [ 0 ] -- ; 
await = 0 in 0 ; 
await = 0 instanceof 0 ; 
await = Symbol . toPrimitive & 0 ; 
await = Symbol . toPrimitive < 0 ; 
await = Symbol . toPrimitive <= 0 ; 
await = [ ... 0 , ] ; 
await = [ ... 0 ] ; 
await = class extends 0 { } ; 
await = new '' ( ) ; 
await = new 0 ( ) ; 
await = new 0 ; 
await = new `` ( ) ; 
await = new async function ( ) { } ( ) ; 
await = new async function * ( ) { } ( ) ; 
await = new function * ( ) { } ( ) ; 
await = new this ( ) ; 
await = new true ( ) ; 
await = new { } ( ) ; 
await = { [ Symbol . toPrimitive ] : 0 } != 0 ; 
await => 0 , x ; 
await => 0 ; 
await => 0 ; -- 0 . x ; 
await => 0 ; [ ] ( ) ; 
await => 0 ; for ( var x of 0 ) ; 
await => 0 ; null ( ) ; 
await => 0 ; this ( ) ; 
await => 0 ; true ( ) ; 
await => 0 ; var x ; new x ( ) ; 
await => 0 ; x ( ) ; var x ; 
await => 0 ; x ; 
await => { } , 0 ( ) ; 
await `` ; 
class await { } await ; 
class x extends '' { [ x ] ; } 
class x extends ( await => 0 ) { } 
class x extends 0 ( ) [ await => 0 ] { } 
class x extends 0 ( ) `${ await => 0 }` { } 
class x extends 0 . x { [ x ] ; } 
class x extends 0 { [ x ] ; } 
class x extends 0 { } await ; 
class x extends Symbol . match { [ x ] ; } 
class x extends [ 0 , ... await => 0 ] { } 
class x extends [ ] { [ x ] ; } 
class x extends [ await => 0 , ] { } 
class x extends [ await => 0 ] { } 
class x extends `` { [ x ] ; } 
class x extends async function ( ) { } { [ x ] ; } 
class x extends async function * ( ) { } { [ x ] ; } 
class x extends await ( ) { } 
class x extends await . x ( ) { } 
class x extends await . x { } 
class x extends await `` { } 
class x extends await { } 
class x extends false { [ x ] ; } 
class x extends function * ( ) { } { [ x ] ; } 
class x extends new 0 ( ) [ await => 0 ] { } 
class x extends this { [ x ] ; } 
class x extends true { [ x ] ; } 
class x extends { 0 ( ) { } , } { [ x ] ; } 
class x extends { 1 : null } { [ x ] ; } 
class x extends { x , 0 : 0 } [ 0 ] { } 
class x extends { } { [ x ] ; } 
class x { * [ 0 ( ) [ await => 0 ] ] ( ) { } } 
class x { * [ await ] ( ) { } } 
class x { 0 = await ; } 
class x { [ 0 ( ) [ 0 ] = await => 0 ] ( ) { } } 
class x { [ 0 ( ) [ 0 ] = await ] ; } 
class x { [ 0 ( ) ] = await ; } 
class x { [ 0 == 0 ? 0 : await => 0 ] ; } 
class x { [ 0 ? await => 0 : 0 ] ; } 
class x { [ 0 [ 0 ] = 0 ] = await ; } 
class x { [ 0 instanceof 0 ? 0 : 0 ] ; } 
class x { [ await ] ( ) { } } 
class x { [ await ] ; } 
class x { [ x = 0 instanceof 0 ? 0 : 0 ] ; } 
class x { [ x = await => 0 ] ; } 
class x { [ x ] ; } while ( 0 ) var [ ] = 0 ; 
class x { [ x ] = await ; } 
class x { [ { x } ] = await ; } 
class x { async * [ 0 ( ) [ await ] ] ( ) { } } 
class x { async * [ 0 ? await : 0 ( ) ] ( ) { } } 
class x { async * [ await ] ( ) { } } 
class x { async * [ class { } ? 0 : 0 ( ) ] ( ) { } } 
class x { async * [ { x , } ? 0 : 0 ( ) ] ( ) { } } 
class x { async * [ { x } ? 0 : 0 ( ) ] ( ) { } } 
class x { get [ 0 . x = await => 0 ] ( ) { } } 
class x { get [ await ] ( ) { } } 
class x { static 0 = 0 === 0 ? async x => 0 : 0 ; } 
class x { static 0 = 0 ? 0 : x => 0 ; } 
class x { static 0 = 0 in 0 ? 0 : 0 ; } 
class x { static [ await ] ( ) { } } 
class x { static [ await ] ; } 
class x { static { class x extends 0 { } } } 
class x { static { const x = 0 instanceof 0 ; } } 
class x { static { const x = [ ... 0 , ] ; } } 
class x { static { const x = [ ... 0 ] ; } } 
class x { static { const x = x ; } } 
class x { } x = 0 ? 0 : x => 0 ; 
class x { } x in 0 ; 
class x { } x ||= await ; 
const x = 0 ; x = x ; 
const x = await ; 
delete `${ 0 }` [ await => 0 , 0 ] ; 
delete class extends 0 { } ; 
do ; while ( [ ... 0 , ] ) ; 
do ; while ( [ ... 0 ] ) ; 
do break ; while ( await ) ; 
do continue ; while ( delete 0 ( ) ) ; 
do continue ; while ( typeof 0 ( ) ) ; 
do continue ; while ( { 0 : 0 , x , } ) ; 
do continue ; while ( { await , } ) ; 
do continue ; while ( { await } ) ; 
do continue ; while ( { get 0 ( ) { } , x , } ) ; 
do continue ; while ( { x , x , } ) ; 
do continue ; while ( { x , x } ) ; 
do x ; while ( await => 0 ) ; 
eval ( ... await => 0 ) ; 
eval ( 0 + typeof await ) ; 
eval ( 0 , ... await => 0 ) ; 
eval ( typeof 0 ) ; await => 0 ; 
for ( 0 . x in [ ( ... await ) => 0 ] ) ; 
for ( 0 . x instanceof 0 ; ; ) ; 
for ( 0 instanceof 0 . x ; ; ) ; 
for ( 0 instanceof 0 ; ; ) ; 
for ( 0 instanceof Symbol . match ; ; ) ; 
for ( 0 instanceof [ ] ; ; ) ; 
for ( ; 0 ; ) var [ ] = 0 ; 
for ( ; 0 ; await ) ; 
for ( ; ; ) 0 instanceof 0 ; 
for ( ; ; await ) break ; 
for ( ; [ ... 0 , ] ; ) ; 
for ( ; [ ... 0 ] ; ) ; 
for ( ; x ; await => 0 ) ; 
for ( Symbol instanceof 0 ; ; ) ; 
for ( [ , ] [ 0 ] in 0 ) ; 
for ( [ ... 0 , ] ; ; ) ; 
for ( [ ... 0 ] ; ; ) ; 
for ( [ ... 0 ] ; ; ) throw 0 ; 
for ( [ ... 0 ] ; x ; ) ; 
for ( [ 0 , ... 0 , ] ; x ; ) ; 
for ( [ 0 ] [ 0 ] of [ , ] ) for ( var x of 0 ) ; 
for ( async function * ( ) { } instanceof 0 ; ; ) ; 
for ( await ( ) . x in 0 ) ; 
for ( await ( ) . x of '' ) ; 
for ( await => 0 ; x ; ) ; 
for ( await in 0 ) ; 
for ( await in 1n ) ; 
for ( await in [ 0 ] ) ; 
for ( await in null ) ; 
for ( await in x ) ; 
for ( await in { has : true } ) ; 
for ( await of '' ) ; 
for ( await of 0 ) ; 
for ( await of [ , ] ) ; 
for ( await of `` ) ; 
for ( class extends 0 { } ; 0 ; ) ; 
for ( class extends 0 { } ; ; ) break ; 
for ( class { } instanceof 0 ; ; ) ; 
for ( const x = 0 ; 0 ; await ) ; 
for ( const x = 0 ; ; await ) break ; 
for ( const x = 0 ; [ ... 0 ] ; ) ; 
for ( const x = class extends 0 { } ; ; ) break ; 
for ( const x = x ; 0 ; ) ; 
for ( const x = x ; ; ) break ; 
for ( const { ... x } = 0 ; ; await ) break ; 
for ( function ( ) { } instanceof 0 ; ; ) ; 
for ( function * ( ) { } instanceof 0 ; ; ) ; 
for ( let [ ] = 0 ; ; ) await => 0 ; 
for ( let [ ] = 0 ; ; ) if ( 0 ) var [ ] = 0 ; else ; 
for ( let [ ] = 0 ; ; ) while ( 0 ) for ( var [ ] = 0 ; ; ) ; 
for ( let [ ] = 0 ; ; await ) ; 
for ( let [ ] = await ; ; ) ; 
for ( let x ; 0 ; await ) ; 
for ( let x ; ; 0 in 0 ? 0 : 0 ) ; 
for ( let x ; ; [ ] = 0 ) await => 0 ; 
for ( let x ; ; await ) break ; 
for ( let x ; [ ... 0 , ] ; ) ; 
for ( let x ; [ ... 0 ] ; ) ; 
for ( let x ; new 0 ; ) if ( 0 ) var [ ] = 0 ; else ; 
for ( let x ; new 0 ; await ) ; 
for ( let x of 0 ) ; await ; 
for ( let x of await => 0 ) ; 
for ( var [ ] = 0 ; ; await ) ; 
for ( var [ ] = 0 ; await ; ) ; 
for ( var [ ] = await => 0 ; ; ) ; 
for ( var x ; 0 ; await ) ; 
for ( var x ; ; await ) break ; 
for ( var x ; [ ... 0 , ] ; ) ; 
for ( var x ; [ ... 0 ] ; ) ; 
for ( var x ; new 0 ; await ) ; 
for ( var x of await => 0 ) ; 
for ( x ; 0 ; ) var [ ] = 0 ; 
for ( x ; ; ) ; let x ; 
for ( x ; ; await => 0 ) ; 
for ( x ; await => 0 ; ) ; 
for ( x in [ 0 ] ) if ( 0 ) for ( var [ ] = 0 ; ; ) ; 
for ( x in [ 0 in 0 ? 0 : 0 ] ) ; 
for ( x of await ) ; 
for ( x of await => 0 ) ; 
for ( { x , } in [ await => 0 ] ) ; 
for ( { x = await => 0 } in [ 0 ] ) ; 
for ( { } in [ await => 0 ] ) x ; 
function * await ( ) { } await ; 
function * x ( ) { } x in 0 ; 
function * x ( ... [ ] ) { } [ ... x ] ; 
function x ( ) { } x in 0 ; 
function x ( ... x ) { } x in 0 ; 
if ( 0 ) for ( var [ ] = 0 ; ; ) ; 
if ( 0 ) for ( var [ ] = 0 ; ; ) ; else ; 
if ( 0 ) for ( var [ ] in 0 ) ; 
if ( 0 ) for ( var { } of 0 ) ; 
if ( 0 ) var [ ] = 0 ; 
if ( 0 ) var [ ] = 0 ; else ; 
if ( 0 ) var [ ] = 0 ; else ; x ; 
if ( 0 ) var [ ] = 0 ; else throw 0 ; 
if ( 0 ) var [ ] = 0 ; x ; 
if ( 0 ) var { } = 0 ; 
if ( 1 ) ; else var [ ] = 0 ; 
if ( await => 0 ) throw 0 ; 
if ( class extends 0 { } ) ; 
if ( class extends 0 { } ) ; else ; 
if ( class { } ) ; 
if ( class { } ) ; else ; 
if ( class { } ) throw 0 ; 
if ( x , 0 ) var [ ] = 0 ; 
isFinite . call ( await => 0 , 1n ) ; 
let [ [ ] ] = [ ] ; await => 0 ; 
let [ ] = 0 ; await ; 
let [ ] = 0 ? await : 0 ; 
let [ ] = [ 0 in 0 ? 0 : 0 ] ; 
let [ ] = [ 0 instanceof 0 && 0 || 0 ] ; 
let [ ] = [ await => 0 ] ; 
let [ ] = await ( ) ; 
let [ ] = await ; 
let [ ] = await => 0 ; 
let [ ] = x , x ; 
let [ ] = x ; let x ; 
let [ ] = { 0 : await => 0 , } ; 
let [ ] = { x , } , x ; 
let [ ] = { x } , x ; 
let [ x , ] = await ; 
let [ x = await ] = Symbol ; 
let [ x = await ] = [ 0 ] ; 
let [ x ] = [ await => 0 ] ; 
let [ x ] = await ; 
let [ x ] = function * ( ) { `${ yield }${ 0 }` ; } ( ) ; 
let [ x ] = function * ( ) { class x extends 0 { } } ( ) ; 
let [ x ] = function * ( ) { do ; while ( { x } ) ; } ( ) ; 
let [ { } = await , ] = [ 0 ] ; 
let [ { } ] = await => 0 ; 
let x ; 0 in x ; 
let x ; 0 instanceof x ; 
let x ; [ ... x ] ; 
let x ; [ x , ... 0 ] ; 
let x ; for ( let x ; 0 . x = 0 ; ) ; 
let x ; for ( let x ; ; ) throw 0 ; 
let x ; for ( let x ; ; 0 . x = 0 ) ; 
let x ; for ( let x ; ; [ ] = 0 ) ; 
let x ; for ( let x ; new 0 ; ) ; 
let x ; x in 0 ; 
let x ; x instanceof 0 ; 
let x = ( 0 , x => 0 ) ; 
let x = 0 ( ) [ 0 ] = await ; 
let x = 0 ( ) [ await ] ; 
let x = 0 ? 0 : x => 0 ; 
let x = 0 in 0 ? 0 : 0 ; 
let x = 0 instanceof 0 && 0 || 0 ; 
let x = await ; 
let x = await => 0 ; 
let x = await `` ; 
let x = class { } ( ) [ await ] ; 
let x = function ( ) { throw x => { } ; } ( ) [ await ] ; 
let x = function ( ) { } ( ) [ 0 ] = await => 0 ; 
let x = new 0 ( await => 0 ) ; 
let x = { } ( ) [ await ] ; 
let { ... x } = 0 ( ) [ await => 0 ] ; 
let { ... x } = await ; 
let { ... x } = await => 0 ; 
let { x = 0 ( ) } = await => 0 ; 
let { x = class extends 0 { } } = await => 0 ; 
let { x = x } = await => 0 ; 
let { x } = 0 in 0 ? 0 : 0 ; 
let { x } = await ; 
let { x } = await => 0 ; 
let { } = await ; 
let { } = await => 0 ; 
new ( await => 0 ) ( ) ; 
new ( await => 0 ) ; 
new 0 ( await => 0 ) ; 
new 0 ( x ) ; let x ; 
new 0 >> await ; 
new 0 ? 0 : await ; 
new 0 [ 0 ? await => { } : 0 ] ( ) ; 
new AggregateError ( 0 , 0 , await => 0 ) ; 
new AggregateError ( await => 0 ) ; 
new Error ( Symbol . toPrimitive , await => 0 ) ; 
new Map ( await => 0 ) ; 
new Set ( await => 0 ) ; 
new WeakSet ( await => 0 ) ; 
new class { } * 1n ; 
new function ( ) { class x extends 0 { } } ; 
new function ( ) { } ( ) * 1n ; 
new function ( ) { } * 1n ; 
new function ( ... [ ] ) { } * 1n ; 
new function ( ... x ) { async function * x ( ) { } switch ( 0 ) { default : var x ; } x ( ) ; } ; 
new function ( ... x ) { function x ( ) { } x ( ) ; for ( var x ; 0 ; ) ; } ; 
new function ( ... x ) { function x ( x ) { } for ( var x in 0 ) ; x ( ) ; } ; 
new function ( ... x ) { if ( 0 ) var [ ] = 0 ; x ( ) ; } ; 
new function ( ... x ) { return class extends 0 { } ? 0 : 0 ; } ; 
new function ( ... x ) { return class { } ? 0 ( ) : 0 ; } ; 
new function ( ... x ) { return class { } ? 0 : 0 ; } ; 
new function ( ... x ) { return class { } ? new 0 ( ) : 0 ; } ; 
new function ( ... x ) { return function ( [ ] ) { } ( ) ; } ; 
new function ( ... x ) { switch ( 0 ) { case 0 : async function x ( ) { } default : case 0 : x ( ) ; } x ; } ; 
new function ( ... x ) { switch ( 0 ) { default : case 0 : return ; } var [ ] = 0 ; } ; 
new function ( ... x ) { x ( ) ; for ( let x ; ; class { } ? 0 : 0 ) ; } ; 
new function ( ... x ) { x ( ) ; return class { } ? 0 : 0 ; } ; 
new function ( ... x ) { x ( ) ; return class { } ? 0 : new . target ; } ; 
new function ( x ) { class await extends 0 { } } ; 
new function ( x ) { for ( ; 0 ; ) var [ ] = 0 ; x ( ) ; } ; 
new function ( x ) { if ( class { } ) ; else ; x ( ) ; } ; 
new function ( x ) { if ( class { } ) ; x ( ) ; } ; 
new null ( await => 0 , ) ; 
new x ( ) ; let x ; 
new x ; let x ; 
new { x } ( ) ; let x ; 
new { x } ; let x ; 
null + 0n ; 
null . x %= await ; 
null . x = await => { } ; 
null / 1n ; 
null < Symbol . toPrimitive ; 
null <= Symbol . toPrimitive ; 
null == class extends 0 { } ; 
null > Symbol . toPrimitive ; 
null >= Symbol . toPrimitive ; 
null ?? async function ( ) { } in 0 ; 
null ?? async function * ( ) { } in 0 ; 
null ?? class extends 0 { } ; 
null ?? class { } in 0 ; 
null ?? function ( ) { } in 0 ; 
null ?? function * ( ) { } in 0 ; 
null ?? { } in 0 ; 
null in 0 ; 
switch ( 0 ) { case 0 ( ) , 0 : default : } 
switch ( 0 ) { case 0 ( ) , 0 : } 
switch ( 0 ) { case 0 : case await : default : } 
switch ( 0 ) { case 0 : case await : } 
switch ( 0 ) { case 0 : class x extends 0 { } } 
switch ( 0 ) { case 0 : default : case await : new 0 ; } 
switch ( 0 ) { case 0 : default : case await : } 
switch ( 0 ) { case 0 : default : x ( ) ; throw 0 ; case 0 : function * x ( ) { } } 
switch ( 0 ) { case 0 : default : x ; case 0 : let x ; } 
switch ( 0 ) { case 0 : new x ( ) ; default : break ; case 0 : function x ( ) { } } 
switch ( 0 ) { case 0 : var x ; } x ( ) ; 
switch ( 0 ) { case 0 : x ( ) ; case 0 : let x ; } 
switch ( 0 ) { case 0 : x ( ) ; default : throw 0 ; case 0 : async function x ( ) { } } 
switch ( 0 ) { case 0 : x ; default : case 0 : let x ; } 
switch ( 0 ) { case 0 : x ; default : let x ; x ( ) ; } 
switch ( 0 ) { case 0 : x ; default : let x ; } 
switch ( 0 ) { case 0 : x ; default : throw 0 ; } let x ; 
switch ( 0 ) { case 0 : x ; let x ; default : x ( ) ; } 
switch ( 0 ) { case 0 in 0 : default : case 0 : x ; } 
switch ( 0 ) { case 0 in 0 : default : x ; } 
switch ( 0 ) { case 0 in 0 ? 0 : 0 : x ; default : } 
switch ( 0 ) { case 0 instanceof 0 : default : case 0 : x ; } 
switch ( 0 ) { case 0 instanceof 0 : default : x ; } 
switch ( 0 ) { case 0 instanceof 0 ? 0 : 0 : x ; } 
switch ( 0 ) { case 1 : let x ; default : case 0 : x ; } 
switch ( 0 ) { case [ ... 0 , ] : default : case 0 : x ; } 
switch ( 0 ) { case [ ... 0 , ] : default : x ; } 
switch ( 0 ) { case [ ... 0 ] : default : case 0 : x ; } 
switch ( 0 ) { case [ ... 0 ] : default : x ; } 
switch ( 0 ) { case await => 0 : default : x ; } 
switch ( 0 ) { case class extends 0 { } : default : case 0 : x ; } 
switch ( 0 ) { case class extends 0 { } : default : } 
switch ( 0 ) { case class extends 0 { } : } 
switch ( 0 ) { case x : class x { } } 
switch ( 0 ) { case x : default : case await => 0 : } 
switch ( 0 ) { case x : default : throw 0 ; case 0 : function x ( ) { } } 
switch ( 0 ) { case x : function * x ( ) { } default : x ( ) ; } 
switch ( 0 ) { case x : let x ; default : } 
switch ( 0 ) { case x : new x ( ) ; default : function * x ( ) { } } 
switch ( 0 ) { case x : var x ; default : new x ( ) ; } 
switch ( 0 ) { case x : var x ; default : x ( ) ; } 
switch ( 0 ) { default : async function * x ( ) { } case 0 : x ( ) ; } 
switch ( 0 ) { default : async function x ( ) { } case 0 : new x ( ) ; } 
switch ( 0 ) { default : async function x ( ) { } case 0 : x ( ) ; } 
switch ( 0 ) { default : case 0 ( ) , 0 : } 
switch ( 0 ) { default : case 0 . x = 0 , 0 : } 
switch ( 0 ) { default : case 0 : case await : } 
switch ( 0 ) { default : case 0 in 0 : x ; } 
switch ( 0 ) { default : case [ ... 0 , ] : x ; } 
switch ( 0 ) { default : case await => 0 : x ; } 
switch ( 0 ) { default : case class extends 0 { } : } 
switch ( 0 ) { default : class x extends 0 { } } 
switch ( 0 ) { default : class x extends 0 { } } x ; 
switch ( 0 ) { default : function * x ( ) { } case 0 : x ( ) ; } 
switch ( 0 ) { default : let x ; case 0 : x ; throw 0 ; } 
switch ( 0 ) { default : let x ; case 0 : x ; } 
switch ( 0 ) { default : let x ; case x : } 
switch ( 0 ) { default : new x ( ) ; case 1 : let x ; } 
switch ( 0 ) { default : var x ; } x ( ) ; 
switch ( 0 ) { default : while ( 0 ) for ( var x of 0 ) ; } x = 0 ; 
switch ( 0 ) { default : x ( ) ; break ; case 1 : async function * x ( ) { } } 
switch ( 0 ) { default : x ( ) ; case 1 : let x ; } 
switch ( 0 ) { default : x ( ) ; case x : async function * x ( ) { } } 
switch ( 0 ) { default : x ; case 1 : let x ; } 
switch ( 0 ) { default : x ; case 1 : throw 0 ; } let x ; 
switch ( 0 ) { default : x ; let x ; case 1 : x ( ) ; } 
switch ( 0 ? await => 0 : 0 ) { case 0 : x ; default : } 
switch ( 0 in 0 ) { default : x ; } 
switch ( 0 instanceof 0 ) { default : x ; } 
switch ( 1 ) { case 0 : let x ; default : case 0 : x ; } 
switch ( 1 ) { case 0 : let x ; default : x ; } 
switch ( 1 ) { case await => 0 : default : case x : } 
switch ( 1 ) { default : case 0 instanceof 0 : x ; } 
switch ( 1 ) { default : case [ ... 0 ] : x ; } 
switch ( [ ... 0 , ] ) { case x : } 
switch ( [ 0 , ... 0 ] ) { case x : } 
switch ( await => 0 ) { case new 0 : } 
switch ( await => 0 ) { case x : default : } 
switch ( await => 0 ) { default : case 0 : new 0 ; } 
switch ( await => 0 ) { default : case 0 : x ; } 
switch ( await => 0 ) { default : case x : } 
switch ( await => 0 ) { default : x ; } 
switch ( class extends 0 { } ) { default : } 
switch ( class extends 0 { } ) { } 
this ** 1n ; 
this - Symbol . toPrimitive ; 
this . x * 1n ; 
this < Symbol . toPrimitive ; 
this < class extends 0 { } ; 
this <= Symbol . toPrimitive ; 
this == class extends 0 { } ; 
this > Symbol . toPrimitive ; 
this > class extends 0 { } ; 
this >= Symbol . toPrimitive ; 
this ^ 0n ; 
this in 0 ; 
this instanceof 0 ; 
throw 0 ; await ; 
throw 0 in 0 && 0 || 0 ; 
throw 0 instanceof 0 , 0 ; 
throw 0 instanceof 0 ? 0 : 0 ; 
throw await => 0 ; 
true !== class extends 0 { } ; 
true + 0n ; 
true - Symbol . toPrimitive ; 
true . x * 1n ; 
true / 1n ; 
true < Symbol . toPrimitive ; 
true <= Symbol . toPrimitive ; 
true > Symbol . toPrimitive ; 
true >= Symbol . toPrimitive ; 
true [ { [ Symbol . toPrimitive ] : 0 } ] ; 
try { await ( ) ; } catch { } finally { } 
try { await ; } catch { } 
try { await ; } catch { } finally { } 
try { class x extends 0 { } } catch { x ; } 
try { class x extends 0 { } } finally { } 
try { class x extends await { } } catch ( x ) { } 
try { let [ ] = await ; } catch ( [ ] ) { } 
try { let [ ] = await ; } catch ( x ) { throw 0 ; } 
try { let [ ] = await ; } catch ( x ) { } 
try { throw 0 ; } catch { class x extends 0 { } } 
try { throw await => 0 ; } catch { x ; } 
try { } catch { } finally { class x extends 0 { } } 
typeof await ; 
typeof class extends 0 { } ; 
var [ [ ] = await ] = 0 ; 
var [ ] = 0 ; await ; 
var [ ] = await ; 
var [ ] = await => 0 ; 
var [ x , ] = await ; 
var [ x ] = await ++ ; 
var x ; 0 instanceof x ; 
var x ; x in 0 ; 
var x = ( 0 , x => 0 ) ; 
var x = 0 <= 0 ? x => 0 : 0 ; 
var x = 0 == 0 ? x => { } : 0 ; 
var x = 0 ? 0 : async x => 0 ; 
var x = 0 ? 0 : x => 0 ; 
var x = await ; 
var x = await => 0 ; new x ( ) ; 
var x = x => 0 instanceof 0 ? 0 : 0 ; x ( ) ; 
var x = { } ; Object . setPrototypeOf ( x , { prototype : async function ( x ) { } } . prototype ) ; 
var { ... x } = await ; 
var { 0 : [ ] = x } = await => 0 ; 
var { 0 : { } = await } = [ 0 ] ; 
var { [ await ] : x } = 0 ; 
var { x = await } = { x : 0 , } ; 
var { x } = await ; 
var { x } = { x : 0 ? 0 : x => 0 , } ; 
var { } = new 0 ?? await ; 
void async function ( ) { } * 1n ; 
void class extends 0 { } ; 
while ( 0 ) for ( var [ ] = 0 ; ; ) ; 
while ( 0 ) var [ ] = 0 ; 
while ( [ ... 0 , ] ) ; 
while ( [ ... 0 ] ) ; 
while ( await => 0 ) throw 0 ; 
x ( ) ; let x ; 
x ( ) ; switch ( 0 ) { case 0 : if ( 0 ) for ( var x ; ; ) ; else ; } 
x ( ) ; switch ( 0 ) { default : var x ; } 
x ( await => 0 ) ; 
x , await ; 
x . x ; let x ; 
x / `${ await => 0 }` ; 
x : for ( ; ; await ) break x ; 
x ; await => 0 ; 
x ; class x { } 
x ; let [ ... x ] = 0 ; 
x ; let x ; 
x = ! [ 0 , ... 0 ] ; 
x = 0 ; let x ; 
x = 0 in 0 ? 0 : 0 ; 
x = 0 instanceof 0 && 0 || 0 ; 
x = 0 instanceof 0 ? 0 : 0 ; 
x = [ 0 , ... 0 ] [ 0 ] ; 
x = await => 0 ; 
x = class { } ? 0 : 0 ; 
x = delete [ ... 0 ] ; 
x = delete [ 0 , ... 0 , ] ; 
x = this . x -- ; 
x = this . x = 0 ; 
x = void [ ... 0 , ] ; 
x = void [ 0 , ... 0 ] ; 
x = { [ Symbol . toPrimitive ] : 0 ?? await } <= 0 ; 
x ? 0 : await => 0 ; 
x [ 0 ] ; let x ; 
x [ await => 0 ] ; 
x `` ; let x ; 
x in 0 ; async function x ( ) { } 
x in 0 ; for ( var x ; ; ) ; 
x in 0 ; function * x ( x ) { } 
x in 0 ; var x ; 
x in `${ await => 0 }` ; 
x instanceof 0 ; for ( var x in 0 ) ; 
x instanceof 0 ; var x ; 
{ class await extends 0 { } x ; } 
{ class x extends 0 { } } 
{ class x extends 0 { } } x ; 
{ const x = x ; } 
{ const x = { x , } ; } 
{ const x = { x } ; } 
{ function x ( [ ] , ) { } x ( ) ; } 
{ x } ; let x ; 
~ Symbol . toPrimitive ; 
~ class extends 0 { } ; 
~ function ( [ ] ) { } ( ) ; 
~ function ( [ ] , ... x ) { } ( ) ; 
~ function ( [ x ] ) { } ( ) ; 
~ function ( { x } ) { } ( ) ; 
~ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ; 
