"use strict";
new class { static #x = #x in 0n % ! 0 ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got transpile-failure */
