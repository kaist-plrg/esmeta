"use strict";
[ ... { [ Symbol . iterator ] : function * ( ) { return 0 . x [ 0 ] ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:ReturnStatement[1,0].Evaluation) but got normal */
