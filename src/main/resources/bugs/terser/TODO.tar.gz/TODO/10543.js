"use strict";
for ( { [ Symbol . toPrimitive ] : async x => 0 } - 0 ; ; ) ; 

/* TAG: NEW-TIMEOUT
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:AdditiveExpression[2,0].Evaluation) but got timeout */
