"use strict";
new class { static #x = new super [ #x in { [ Symbol . toPrimitive ] : { } } >> super . x ] . #x . #x ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:ShiftExpression[2,0].Evaluation) but got transpile-failure */
