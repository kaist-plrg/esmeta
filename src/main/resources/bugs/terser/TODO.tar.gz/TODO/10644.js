"use strict";
let [ ] = ~ - function * ( ) { } ( ) [ x <= 0 >> 0 == x ] ( ) < x , x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:RelationalExpression[3,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: (intermediate value)(...)[((x <= 0) == x)] is not a function) */
