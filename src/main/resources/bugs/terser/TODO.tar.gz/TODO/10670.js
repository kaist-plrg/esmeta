"use strict";
new class { static #x = 0 != #x in [ 0 . #x = 0 || #x in 0 . #x , ] ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(PrivateGet ((step 2, 3:35-65))<SYNTAX>:RelationalExpression[7,0].Evaluation) but got transpile-failure */
