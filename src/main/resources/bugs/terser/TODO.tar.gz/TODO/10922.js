"use strict";
new class { static #x = #x in super [ 0 ?. [ new 0 . #x ] . #x ] ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(PrivateGet ((step 2, 3:35-65))<SYNTAX>:NewExpression[1,0].Evaluation) but got transpile-failure */
