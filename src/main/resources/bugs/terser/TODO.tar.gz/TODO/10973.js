"use strict";
switch ( 0 ) { case { [ Symbol . toPrimitive ] : 0 } > 0 < 1n : default : } 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:RelationalExpression[2,0].Evaluation) but got normal */
