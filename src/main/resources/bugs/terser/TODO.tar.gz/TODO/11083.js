"use strict";
[ 0 , ... 0 != { [ Symbol . toPrimitive ] : function * ( x , { } ) { } } , ... 0 ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(RequireObjectCoercible<SYNTAX>:BindingPattern[0,0].BindingInitialization) but got normal */
