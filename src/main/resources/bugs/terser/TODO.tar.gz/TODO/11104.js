"use strict";
new class { static #x = #x in null . #x << 0 ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:ShiftExpression[1,0].Evaluation) but got transpile-failure */
