"use strict";
new class { static #x = 0 . #x = #x in x && 0 ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:RelationalExpression[7,0].Evaluation) but got transpile-failure */
