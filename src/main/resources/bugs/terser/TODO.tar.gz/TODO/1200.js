"use strict";
for ( `${ { [ Symbol . toPrimitive ] : x => this } }` ; ; ) throw 0 ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:SubstitutionTemplate[0,0].Evaluation) but got throw-value: "unnamed:3: 0
"use strict";for(Symbol.toPrimitive;;)throw 0;
                                      ^
" */
