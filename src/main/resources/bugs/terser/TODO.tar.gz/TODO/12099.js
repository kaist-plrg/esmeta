"use strict";
`` [ 0 ] < { [ Symbol . toPrimitive ] : ( ) => { throw 0 [ 0 ] . x ; } } > 0 ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:ThrowStatement[0,0].Evaluation) but got normal */
