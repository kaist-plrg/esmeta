"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { yield function ( ) { } ( ) ( ) ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(EvaluateCall ((step 4, 12:45-75))<SYNTAX>:CallExpression[3,0].Evaluation) but got normal */
