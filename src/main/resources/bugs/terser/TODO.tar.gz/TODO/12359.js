"use strict";
new class { static #x = #x in { } ?. x . #x ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:RelationalExpression[7,0].Evaluation) but got transpile-failure */
