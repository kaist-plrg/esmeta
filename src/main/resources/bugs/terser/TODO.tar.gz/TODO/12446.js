"use strict";
new class { static #x = #x in typeof 1n . #x `` ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(PrivateGet ((step 2, 3:35-65))<SYNTAX>:MemberExpression[3,0].Evaluation) but got transpile-failure */
