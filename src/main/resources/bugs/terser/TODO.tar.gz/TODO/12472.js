"use strict";
for ( var { } of { [ Symbol . iterator ] : async function * ( ) { for await ( let x of yield * `${ yield null . x ||= yield }` ) ; } } ) ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(RequireObjectCoercible<SYNTAX>:BindingPattern[0,0].BindingInitialization) but got transpile-failure */
