"use strict";
new class x { 0 = `${ super [ await ] }` ; } ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:SuperProperty[0,0].Evaluation) but got transpile-failure */
