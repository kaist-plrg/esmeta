"use strict";
[ 1n | 1 ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:BitwiseORExpression[1,0].Evaluation) but got normal */
