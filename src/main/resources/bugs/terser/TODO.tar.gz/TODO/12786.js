"use strict";
0 >= 0n >> 0 ?? 0 ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:ShiftExpression[2,0].Evaluation) but got normal */
