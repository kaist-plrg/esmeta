"use strict";
let x = 0 !== 0 / x - await <= 0 ; 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got transpile-failure */
