"use strict";
new class { static #x = #x in { 1 : '' } ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
