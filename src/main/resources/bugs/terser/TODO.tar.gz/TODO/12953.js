"use strict";
0 in { [ Symbol . toPrimitive ] : ( ) => { } } * 0n ; ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got normal */
