"use strict";
new class { static #x = #x in { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ** 0 ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-value: 0.0f but got transpile-failure */
