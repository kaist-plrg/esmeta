"use strict";
0n <= 1n && class extends 0 { } ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ClassTail[0,2].ClassDefinitionEvaluation ((step 8.g, 27:62-92))<SYNTAX>:ClassTail[0,2].ClassDefinitionEvaluation) but got normal */
