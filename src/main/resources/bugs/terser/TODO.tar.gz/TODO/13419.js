"use strict";
class x { static { if ( new x ( super [ x &&= x => 0 ] *= 0 ) ) ; else ; let x ; } } 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:MemberExpression[6,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: undefined is not a constructor) */
