"use strict";
[ , 0 | ! typeof 0 + 0n ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:AdditiveExpression[1,0].Evaluation) but got normal */
