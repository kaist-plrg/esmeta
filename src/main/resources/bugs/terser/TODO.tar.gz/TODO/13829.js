"use strict";
[ 0 , ... { [ Symbol . iterator ] : function ( ) { } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetIterator ((step 4, 12:47-77))<SYNTAX>:SpreadElement[0,0].ArrayAccumulation) but got normal */
