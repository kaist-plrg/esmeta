"use strict";
- 0 instanceof [ 0 , , ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(InstanceofOperator ((step 4, 6:86-116))<SYNTAX>:RelationalExpression[5,0].Evaluation) but got normal */
