"use strict";
`${ 0 }${ 0 ^ { [ Symbol . toPrimitive ] : false } }${ 0 }` ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:BitwiseXORExpression[1,0].Evaluation) but got normal */
