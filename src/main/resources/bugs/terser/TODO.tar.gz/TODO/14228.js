"use strict";
let [ ] = '' >= x , x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:RelationalExpression[4,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: boolean false is not iterable (cannot read property Symbol(Symbol.iterator))) */
