"use strict";
for ( 0n / 0n ; 0 ; 0 ) ; 

/* TAG: NEW-TRS-BIGINT-DIV-0
[Exit Tag Mismatch]
 > Expected throw-error: RangeError(BigInt::divide ((step 1, 2:43-74))<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got normal */
