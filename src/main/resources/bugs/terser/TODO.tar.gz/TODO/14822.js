"use strict";
[ , ... function ( ) { } ( ) ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:SpreadElement[0,0].ArrayAccumulation) but got normal */
