"use strict";
let x = `${ 0 }` [ 0 ] &&= ~ void x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:UnaryExpression[2,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: Cannot assign to read only property '0' of string '0') */
