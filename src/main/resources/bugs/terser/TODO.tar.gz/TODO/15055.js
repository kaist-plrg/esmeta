"use strict";
0 & true ?. x >= { [ Symbol . toPrimitive ] : function * ( x ) { } } ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:RelationalExpression[4,0].Evaluation) but got normal */
