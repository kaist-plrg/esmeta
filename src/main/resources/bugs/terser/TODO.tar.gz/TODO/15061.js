"use strict";
new class { static #x = #x in + class extends super [ { [ Symbol . toPrimitive ] : function * ( ) { } } ] { ; } ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:SuperProperty[0,0].Evaluation) but got transpile-failure */
