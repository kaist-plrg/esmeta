"use strict";
for ( let x in [ 0 ] ) try { if ( await ) ; } catch { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected normal but got transpile-failure */
