"use strict";
{ x = function ( ) { } ( ) [ x ] ++ ?? 0 ; let x ; } ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:CallExpression[4,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: Cannot read properties of undefined (reading 'undefined')) */
