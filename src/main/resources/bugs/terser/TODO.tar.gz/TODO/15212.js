"use strict";
1n % 0n >> 1 ; 

/* TAG: NEW-TRS-BIGINT-DIV-0
[Exit Tag Mismatch]
 > Expected throw-error: RangeError(BigInt::remainder ((step 1, 2:43-74))<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got normal */
