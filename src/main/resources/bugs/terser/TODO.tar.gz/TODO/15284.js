"use strict";
var x ; for ( this . x instanceof 0 ; ; ) ; 

/* TAG: NEW-TIMEOUT
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(InstanceofOperator ((step 1, 2:45-75))<SYNTAX>:RelationalExpression[5,0].Evaluation) but got timeout */
