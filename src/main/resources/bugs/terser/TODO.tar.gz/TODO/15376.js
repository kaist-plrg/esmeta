"use strict";
new class { static #x = #x in `${ { [ Symbol . toPrimitive ] : { } } }` >= 0 ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:SubstitutionTemplate[0,0].Evaluation) but got transpile-failure */
