"use strict";
[ ... { [ Symbol . iterator ] : function * ( ) { yield 0 [ yield * [ ] . x -- ] ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:YieldExpression[2,0].Evaluation) but got normal */
