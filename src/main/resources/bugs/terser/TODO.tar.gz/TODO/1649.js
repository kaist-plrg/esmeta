"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { return yield * new 0 ( ... 0 ) ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:ArgumentList[1,0].ArgumentListEvaluation) but got normal */
