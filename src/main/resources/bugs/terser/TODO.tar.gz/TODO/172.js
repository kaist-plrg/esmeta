"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { yield * `` . x ?. x ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:YieldExpression[2,0].Evaluation) but got normal */
