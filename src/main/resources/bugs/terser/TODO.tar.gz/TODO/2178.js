"use strict";
[ 0 , , 0 !== x ] ; let x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:EqualityExpression[4,0].Evaluation) but got normal */
