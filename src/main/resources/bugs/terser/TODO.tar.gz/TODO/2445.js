"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { yield * 0 ?. ( ) . x ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(EvaluateCall ((step 4, 12:45-75))<SYNTAX>:OptionalChain[0,0].ChainEvaluation) but got normal */
