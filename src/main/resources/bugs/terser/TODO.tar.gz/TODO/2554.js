"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { switch ( yield * yield * { [ Symbol . iterator ] : function ( x ) { } } ) { } } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetIterator ((step 4, 12:47-77))<SYNTAX>:YieldExpression[2,0].Evaluation) but got normal */
