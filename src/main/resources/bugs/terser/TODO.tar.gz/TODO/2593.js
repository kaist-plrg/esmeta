"use strict";
1 < 0 instanceof 0 ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(InstanceofOperator ((step 1, 2:45-75))<SYNTAX>:RelationalExpression[5,0].Evaluation) but got normal */
