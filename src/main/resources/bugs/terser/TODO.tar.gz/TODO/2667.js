"use strict";
new class { static #x = #x in true . #x >>> 0 ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(PrivateGet ((step 2, 3:35-65))<SYNTAX>:ShiftExpression[3,0].Evaluation) but got transpile-failure */
