"use strict";
[ ... { [ Symbol . iterator ] : function * ( ) { yield void 0 . x . x ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:UnaryExpression[2,0].Evaluation) but got normal */
