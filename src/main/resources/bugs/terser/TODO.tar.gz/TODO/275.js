"use strict";
class x { static { if ( x ** 0 . x ) ; let x ; } } 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:ExponentiationExpression[1,0].Evaluation) but got normal */
