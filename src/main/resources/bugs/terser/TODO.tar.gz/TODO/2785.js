"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { yield [ ~ 0 ] [ 0 ] &&= yield * null ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:YieldExpression[2,0].Evaluation) but got normal */
