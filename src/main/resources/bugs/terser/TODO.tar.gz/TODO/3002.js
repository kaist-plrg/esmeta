"use strict";
[ ... { [ Symbol . iterator ] : function * ( ) { yield { x } == 0 ; } } ] ; 

/* TAG: NEW-YET-REMOVED-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:PropertyDefinition[0,0].PropertyDefinitionEvaluation) but got normal */
