"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { x ??= yield * new function x ( ) { } . x ( ) ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(EvaluateNew ((step 5, 7:60-90))<SYNTAX>:MemberExpression[6,0].Evaluation) but got normal */
