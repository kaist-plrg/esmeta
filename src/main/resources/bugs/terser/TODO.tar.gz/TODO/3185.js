"use strict";
{ [ , ] = { [ Symbol . iterator ] : await => class { } } ; } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:Elision[0,0].IteratorDestructuringAssignmentEvaluation) but got transpile-failure */
