"use strict";
new 0 ( 0 , ! x ) ; let x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:UnaryExpression[7,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: 0 is not a constructor) */
