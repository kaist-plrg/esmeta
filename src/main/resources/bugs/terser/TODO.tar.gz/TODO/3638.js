"use strict";
0 . x = async function * x ( ) { var x ; } / x ; let x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: Cannot create property 'x' on number '0') */
