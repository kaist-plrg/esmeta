"use strict";
[ ] < 0 + { [ Symbol . toPrimitive ] : '' } ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:AdditiveExpression[1,0].Evaluation) but got normal */
