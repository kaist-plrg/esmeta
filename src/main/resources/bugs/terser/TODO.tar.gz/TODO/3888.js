"use strict";
[ 0 <= 0 + { [ Symbol . toPrimitive ] : async x => { for await ( var x of async function * ( ) { x ; } ( ) ) ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:AdditiveExpression[1,0].Evaluation) but got normal */
