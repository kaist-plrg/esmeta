"use strict";
if ( { } . x %= { [ Symbol . toPrimitive ] : '' } ) if ( 0 ) ; else ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:AssignmentExpression[5,0].Evaluation) but got normal */
