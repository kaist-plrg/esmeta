"use strict";
for ( function ( [ ] ) { } ( ) ; ; ) ; 

/* TAG: NEW-TIMEOUT
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:BindingPattern[1,0].BindingInitialization) but got timeout */
