"use strict";
[ ... { [ Symbol . iterator ] : function * ( ) { throw `` ?. x ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-THROW
[Exit Tag Mismatch]
 > Expected throw-value: undefined but got normal */
