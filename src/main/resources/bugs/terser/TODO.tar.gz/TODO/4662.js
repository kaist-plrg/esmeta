"use strict";
switch ( 0 ) { case { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } + 0 : default : } 

/* TAG: NEW-YET-TRS-REMOVE-THROW
[Exit Tag Mismatch]
 > Expected throw-value: 0.0f but got normal */
