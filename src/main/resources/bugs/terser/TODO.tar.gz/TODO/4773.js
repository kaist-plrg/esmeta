"use strict";
let [ [ ] = x = 0 , , ] = '' ; let x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.SetMutableBinding<SYNTAX>:AssignmentExpression[4,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: x is not iterable) */
