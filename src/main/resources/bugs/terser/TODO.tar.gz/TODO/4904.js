"use strict";
let [ ] = 0 [ x ] , x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:MemberExpression[1,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: undefined is not iterable (cannot read property Symbol(Symbol.iterator))) */
