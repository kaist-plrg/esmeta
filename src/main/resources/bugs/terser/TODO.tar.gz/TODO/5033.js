"use strict";
switch ( 0 ) { case { x } . x : let x ; } 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:PropertyDefinition[0,0].PropertyDefinitionEvaluation) but got normal */
