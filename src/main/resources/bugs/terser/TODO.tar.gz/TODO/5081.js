"use strict";
switch ( 0 ) { case x + 0 : let x ; } 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:AdditiveExpression[1,0].Evaluation) but got normal */
