"use strict";
1 << 0 < class x extends 0 { } ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ClassTail[0,2].ClassDefinitionEvaluation ((step 8.g, 27:62-92))<SYNTAX>:ClassTail[0,2].ClassDefinitionEvaluation) but got normal */
