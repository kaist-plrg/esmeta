"use strict";
[ ... { [ Symbol . iterator ] : function * ( ) { yield 0 [ 0 ] ??= x => 0 ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(PutValue ((step 5.d, 15:72-102))<SYNTAX>:AssignmentExpression[8,0].Evaluation) but got normal */
