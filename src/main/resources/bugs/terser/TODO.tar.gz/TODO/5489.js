"use strict";
x : switch ( `` >> { [ Symbol . toPrimitive ] : 0 } ) { } 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(GetMethod ((step 3, 4:46-76))<SYNTAX>:ShiftExpression[2,0].Evaluation) but got normal */
