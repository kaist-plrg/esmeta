"use strict";
switch ( 1 ) { case 0 : default : case 0n ** 0 : } 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:ExponentiationExpression[1,0].Evaluation) but got normal */
