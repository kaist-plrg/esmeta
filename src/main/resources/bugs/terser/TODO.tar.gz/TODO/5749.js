"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { switch ( yield 0 ? 0 : yield null . x ) { } } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:YieldExpression[1,0].Evaluation) but got normal */
