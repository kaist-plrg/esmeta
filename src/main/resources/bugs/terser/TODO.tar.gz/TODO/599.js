"use strict";
for ( 0 & 0n ; ; ) break ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:BitwiseANDExpression[1,0].Evaluation) but got normal */
