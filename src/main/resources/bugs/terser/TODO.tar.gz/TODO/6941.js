"use strict";
for ( let x of { x } ? 0 : 0 ) ; 

/* TAG: NEW-YET-REMOVED-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:PropertyDefinition[0,0].PropertyDefinitionEvaluation) but got throw-error: TypeError(unnamed:3: TypeError: 0 is not iterable) */
