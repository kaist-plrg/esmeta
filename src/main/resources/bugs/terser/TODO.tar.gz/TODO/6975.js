"use strict";
class x { static { if ( super [ x <= x ] ) ; let x ; } } 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:RelationalExpression[3,0].Evaluation) but got normal */
