"use strict";
[ , 0 , , ... { [ Symbol . iterator ] : function * ( x ) { if ( `` ?. x ( ) [ 0 ] ) ; } } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(EvaluateCall ((step 4, 12:45-75))<SYNTAX>:OptionalChain[5,0].ChainEvaluation) but got normal */
