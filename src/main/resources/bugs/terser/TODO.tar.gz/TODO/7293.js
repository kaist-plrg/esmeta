"use strict";
switch ( 0 ) { default : case { [ Symbol . toPrimitive ] : x => this } & 0 : } 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:BitwiseANDExpression[1,0].Evaluation) but got normal */
