"use strict";
typeof - { [ Symbol . toPrimitive ] : async x => 0 } ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:UnaryExpression[5,0].Evaluation) but got normal */
