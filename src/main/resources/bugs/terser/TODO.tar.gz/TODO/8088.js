"use strict";
new class { static #x = #x in 0 >> x ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(GetValue ((step 3, 4:57-92))<SYNTAX>:ShiftExpression[2,0].Evaluation) but got transpile-failure */
