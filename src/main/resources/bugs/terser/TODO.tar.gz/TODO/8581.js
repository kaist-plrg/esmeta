"use strict";
for ( 1n * 0 ; ; ) break ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ApplyStringOrNumericBinaryOperator ((step 5, 14:60-90))<SYNTAX>:MultiplicativeExpression[1,0].Evaluation) but got normal */
