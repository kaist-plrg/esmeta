"use strict";
new class { static #x = #x in super [ 0 ] . #x [ 0 ] . #x `` . #x ++ ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToObject<SYNTAX>:MemberExpression[1,0].Evaluation) but got transpile-failure */
