"use strict";
let [ ] = 0 >> 0 . x || 0 ^ 0 === 0 ? x : 0 , x ; 

/* TAG: NEW-YET-TRS-REMOVE-REF-ERR
[Exit Tag Mismatch]
 > Expected throw-error: ReferenceError(DeclarativeEnvironmentRecord.GetBindingValue<SYNTAX>:ConditionalExpression[1,0].Evaluation) but got throw-error: TypeError(unnamed:3: TypeError: x is not iterable) */
