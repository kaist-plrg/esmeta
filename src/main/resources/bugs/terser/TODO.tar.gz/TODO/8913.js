"use strict";
new class { static #x = #x in this ( ) ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ClassTail[0,1].ClassDefinitionEvaluation:clo0 ((step 14.a.ii, 40:45-75))<BUILTIN-CLO>:ClassTail[0,1].ClassDefinitionEvaluation:clo0) but got transpile-failure */
