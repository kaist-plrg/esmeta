"use strict";
new class { static #x = super . x [ super [ 0 , #x in new 0 , `` ] *= 0 ] . #x ; } ; 

/* TAG: NEW-PRIVATE-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(EvaluateNew ((step 5, 7:60-90))<SYNTAX>:NewExpression[1,0].Evaluation) but got transpile-failure */
