"use strict";
for ( [ 0 in 0 >> ! 1 in 0 ] <= `` ; 0 ; ) ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(RelationalExpression[6,0].Evaluation ((step 5, 6:43-73))<SYNTAX>:RelationalExpression[6,0].Evaluation) but got normal */
