"use strict";
[ { [ Symbol . toPrimitive ] : ( ) => { throw 0 ; } } ^ 0 in { } ] ; 

/* TAG: NEW-YET-TRS-REMOVE-THROW
[Exit Tag Mismatch]
 > Expected throw-value: 0.0f but got normal */
