"use strict";
[ ... 0 == 0 >= 0 ] ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(Call ((step 2, 3:43-73))<SYNTAX>:SpreadElement[0,0].ArrayAccumulation) but got normal */
