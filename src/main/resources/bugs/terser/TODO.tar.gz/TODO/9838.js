"use strict";
if ( { [ Symbol . toPrimitive ] : async function ( x ) { } } + 0 ) ; else ; 

/* TAG: NEW-YET-TRS-REMOVE-TYP-ERR
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(ToPrimitive ((step 1.b.vi, 12:16-46))<SYNTAX>:AdditiveExpression[1,0].Evaluation) but got normal */
