"use strict";
`${ 0 }${ 0 != await instanceof 0 }${ 0 }` ; function await ( ) { } 

/* TAG: NEW-AWAIT-FAIL
[Exit Tag Mismatch]
 > Expected throw-error: TypeError(InstanceofOperator ((step 1, 2:45-75))<SYNTAX>:RelationalExpression[5,0].Evaluation) but got transpile-failure */
